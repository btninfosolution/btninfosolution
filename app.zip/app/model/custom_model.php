<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use DateTime;
use DateTimeZone;
class custom_model extends Model {

	/* Decode velidator error message */
	function decode_validator_error($input)
	{
		$error_array = json_decode($input,true);
		$msg= "";
		foreach($error_array as $k=>$v){
			$msg .= $v[0];
		}
		return $msg;
	}

	/* Generate random string */

	function randomWord($limit = null) 
	{

        $limt = $limit != null ? $limit : 6;
        $word = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $random = str_shuffle($word);
        $random = substr($random, rand(0, 8), $limit);
        return $random;
	} 

	  
    
}
