<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminEventController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_event()
    {
        
        $data['page_title'] = "Event";
        $data['countOfArray'] = '';
        
        return view('admin.events.calender')->with($data);
    }
    
    
    
    /******** Products data import *********/
}
