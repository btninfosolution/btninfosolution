<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;

use PDF;
use Storage;


class AdminProposalController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_proposal()
    {
        
        $data['page_title'] = "Group"; 
        $left = array(
            array('tbl_leads AS b','a.lead_id','=','b.leads_id'),
            
        );
        $data['invoicelist'] =$this->common_model
        ->get_all($table = "tbl_invoices AS a", $select = array('a.*', 'b.name as name'), $where = array(array('a.is_deleted', '=', 0),array('a.is_invoice', '=', 2),array('a.lead_id', '!=', 0)), $join = array(), $left, $right = array(), $order = array(array('a.invoice_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.proposal.proposal_detail')->with($data);
    }
    public function add_proposal(Request $request){
        $data=array(
            'page_title'=>'Add Group',
        );
        $data['taglist'] =$this->common_model
      ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['stafflist'] =$this->common_model
      ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['leadlist'] =$this->common_model
      ->get_all($table = "tbl_leads", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('leads_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['itemlist'] =$this->common_model
      ->get_all($table = "tbl_items", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('item_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.proposal.proposal_add')->with($data);
    }
    public function proposal_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
            $postdata['taglist'] =$this->common_model
      ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $postdata['stafflist'] =$this->common_model
      ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $postdata['leadlist'] =$this->common_model
      ->get_all($table = "tbl_leads", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('leads_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $postdata['itemlist'] =$this->common_model
      ->get_all($table = "tbl_items", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('item_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
     
       $postdata['Editdata'] = DB::table('tbl_invoices')->where('invoice_id', $data)->first();
       $item_data=DB::table('tbl_invoice_items')->where('invoice_id', $data)->get();
       if(!empty($item_data)){
        $postdata['itemdata'] =$item_data;
        
       }
       return view('admin.proposal.proposal_edit')->with($postdata);
	  
    }
    public function customer_proposal_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
            $postdata['taglist'] =$this->common_model
      ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $postdata['stafflist'] =$this->common_model
      ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $postdata['leadlist'] =$this->common_model
      ->get_all($table = "users", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $postdata['itemlist'] =$this->common_model
      ->get_all($table = "tbl_items", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('item_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
     
       $postdata['Editdata'] = DB::table('tbl_invoices')->where('invoice_id', $data)->first();
       $item_data=DB::table('tbl_invoice_items')->where('invoice_id', $data)->get();
       if(!empty($item_data)){
        $postdata['itemdata'] =$item_data;
        
       }
       return view('admin.proposal.customer_proposal_edit')->with($postdata);
	  
    }
    
    
    
    public function save_proposal(Request $request)

{
     $rules = array(
         'start' => 'required',
       );
     $this->validate($request, $rules);
    // $fetaure = implode(',', $request->item_name);
    // print_r($fetaure);die;
     $save_data['tag_id'] =  $request->input('tag');
     $save_data['payment_type'] =  !empty($request->input('payment')) ?  $request->input('payment') : '';
     $save_data['agent_id'] =  !empty($request->input('agent')) ?  $request->input('agent') : 0;
     $save_data['recuring_invoice'] =  $request->input('recruit');
     $save_data['discount_type'] =  $request->input('dis_type');
     $save_data['admin_note'] =  $request->input('adminnote');
     $save_data['discount_percent'] =  $request->input('discount');
     $save_data['sub_total'] =  $request->input('sub_total');
     $save_data['discount'] =  $request->input('discount_total');
     $save_data['total_amount'] =  $request->input('overall_discount');
     $save_data['client_note'] =  $request->input('clientnote');
     $save_data['terms_condition'] =  $request->input('terms');
     $save_data['invoice_date'] =  $request->input('start');
     $save_data['due_date'] =  $request->input('expiry');
     $save_data['customer_id'] = 0;
     $save_data['is_invoice'] =  2;
     $save_data['lead_id'] =  $request->input('lead_id');
     $otp=rand(10000,99999);
     $save_data['invoice_number'] = 'PRO'.'-'.$otp;
     $save_data['created_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
     
    $result = $this->common_model->insert_data_get_id($table = "tbl_invoices", $data1 = $save_data);
    $last_id=DB::getPdo()->lastInsertId();
    //print_r($last_id);die;
    $item_name = implode(',', $request->item_name);
    $item_description = implode(',', $request->long_description);
    $quantity = implode(',', $request->quantity);
    $item_rate = implode(',', $request->item_rate);
    $name_array = explode(',', $item_name);
    $description_array = explode(',', $item_description);
    $quantity_array = explode(',', $quantity);
    $rate_array = explode(',', $item_rate);
    $counter = 0;
    if(!empty($name_array)){
    foreach ($name_array as $key => $value)
    {
        $category_data = array();
        $category_data = array(
            'item_name' => $value,
            'item_description' => $description_array[$key],
            'invoice_id' => $last_id,
            "quantity" => $quantity_array[$key],
            "item_rate" => $rate_array[$key],
            'is_blocked' => 0,
            'created_at' =>  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes')),
        );
        

        $insert_id = $this->common_model->insert_data_get_id($table = "tbl_invoice_items", $data = $category_data);
        $counter++;
    }
  }
  $leademail = DB::table('tbl_leads')->where('leads_id', $request->input('lead_id'))->first();
  $emaillead = $leademail->email;
  $namelead = $leademail->name;
    
  if($request->send_type ==1 && $emaillead !=''){
    $email=$emaillead;
    $proposaldata = DB::table('tbl_invoices')->where('invoice_id', $result)->first();
    $data['proposaldata']= $proposaldata;
    $lead_id=$proposaldata->lead_id;
    $leaddata = DB::table('tbl_leads')->where('leads_id', $lead_id)->first();
    $itemdata = DB::table('tbl_invoice_items')->where('invoice_id', $result)->get();
    $data['leaddata']= $leaddata;
    $data['itemdata']= $itemdata;
    $emailData['name'] =  $namelead;
     $pdf = PDF::loadView('pdf/proposal_pdf',$data);
    //$pdf = PDF::loadView('pdf/invoice_pdf');
  //  return $pdf->download('pdfview.pdf');
  try{
    Mail::send('email.proposal',$emailData,function($message) use($email,$pdf)
    {
        $message->from('btninfosolution@gmail.com', 'PROPOSAL');
        $message->subject('Proposal');
        $message->to($email);
        $message->attachData($pdf->output(),'proposal.pdf');
    });
    $data['success'] = trans('messages.393');
}
catch(\Exception $e){
   // dd($e);die;
   $data['danger'] = trans('messages.394');
}

  }
     if( $result){
     $data['success'] = trans('messages.393');
      }
       else{
     $data['danger'] = trans('messages.394');
      }
      return redirect('lead-proposal')->with($data); 
}

public function update_proposal(Request $request)

{
     $rules = array(
         'start' => 'required',
       );
     $this->validate($request, $rules);
     $invoiceid=$request->id;
    // print_r($fetaure);die;
     $save_data['tag_id'] =  $request->input('tag');
     $save_data['payment_type'] =  !empty($request->input('payment')) ?  $request->input('payment') : '';
     $save_data['agent_id'] =  !empty($request->input('agent')) ?  $request->input('agent') : 0;
     $save_data['recuring_invoice'] =  $request->input('recruit');
     $save_data['discount_type'] =  $request->input('dis_type');
     $save_data['admin_note'] =  $request->input('adminnote');
     $save_data['discount_percent'] =  $request->input('discount');
     $save_data['sub_total'] =  $request->input('sub_total');
     $save_data['discount'] =  $request->input('discount_total');
     $save_data['total_amount'] =  $request->input('overall_discount');
     $save_data['client_note'] =  $request->input('clientnote');
     $save_data['terms_condition'] =  $request->input('terms');
     $save_data['invoice_date'] =  $request->input('start');
     $save_data['due_date'] =  $request->input('expiry');
     $save_data['customer_id'] = 0;
     $save_data['is_invoice'] =  2;
     $save_data['lead_id'] =  $request->input('lead_id');
     $save_data['updated_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
    $result=DB::table('tbl_invoices')
        ->where('invoice_id',$invoiceid)
        ->update($save_data);
        DB::table('tbl_invoice_items')
        ->where('invoice_id', $invoiceid)
        ->delete();
    //print_r($last_id);die;
    $item_name = implode(',', $request->item_name);
    $item_description = implode(',', $request->long_description);
    $quantity = implode(',', $request->quantity);
    $item_rate = implode(',', $request->item_rate);
    $name_array = explode(',', $item_name);
    $description_array = explode(',', $item_description);
    $quantity_array = explode(',', $quantity);
    $rate_array = explode(',', $item_rate);
    $counter = 0;
    if(!empty($name_array)){
    foreach ($name_array as $key => $value)
    {
        $category_data = array();
        $category_data = array(
            'item_name' => $value,
            'item_description' => $description_array[$key],
            'invoice_id' => $invoiceid,
            "quantity" => $quantity_array[$key],
            "item_rate" => $rate_array[$key],
            'is_blocked' => 0,
            'created_at' =>  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes')),
        );
        

        $insert_id = $this->common_model->insert_data_get_id($table = "tbl_invoice_items", $data = $category_data);
        $counter++;
    }
  }
  $leademail = DB::table('tbl_leads')->where('leads_id', $request->input('lead_id'))->first();
  $emaillead = $leademail->email;
  $namelead = $leademail->name;
    
  if($request->send_type ==1 && $emaillead !=''){
    $email=$emaillead;
    $proposaldata = DB::table('tbl_invoices')->where('invoice_id', $result)->first();
    $data['proposaldata']= $proposaldata;
    $lead_id=$proposaldata->lead_id;
    $leaddata = DB::table('tbl_leads')->where('leads_id', $lead_id)->first();
    $itemdata = DB::table('tbl_invoice_items')->where('invoice_id', $result)->get();
    $data['leaddata']= $leaddata;
    $data['itemdata']= $itemdata;
    $emailData['name'] =  $namelead;
     $pdf = PDF::loadView('pdf/proposal_pdf',$data);
    //$pdf = PDF::loadView('pdf/invoice_pdf');
  //  return $pdf->download('pdfview.pdf');
  try{
    Mail::send('email.proposal',$emailData,function($message) use($email,$pdf)
    {
        $message->from('btninfosolution@gmail.com', 'PROPOSAL');
        $message->subject('Proposal');
        $message->to($email);
        $message->attachData($pdf->output(),'proposal.pdf');
    });
    $data['success'] = trans('messages.395');
}
catch(\Exception $e){
   // dd($e);die;
   $data['danger'] = trans('messages.396');
}

  }
     if( $result){
     $data['success'] = trans('messages.395');
      }
       else{
     $data['danger'] = trans('messages.396');
      }
      return redirect('lead-proposal')->with($data); 
}
public function admin_customer_proposal()
    {
        
        $data['page_title'] = "Group"; 
        $left = array(
            array('users AS b','a.customer_id','=','b.id'),
            
        );
        $data['invoicelist'] =$this->common_model
        ->get_all($table = "tbl_invoices AS a", $select = array('a.*', 'b.client_name as name'), $where = array(array('a.is_deleted', '=', 0),array('a.is_invoice', '=', 2),array('a.lead_id', '=', 0)), $join = array(), $left, $right = array(), $order = array(array('a.invoice_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.proposal.customer_proposal_detail')->with($data);
    }

    public function add_customer_proposal(Request $request){
        $data=array(
            'page_title'=>'Add Group',
        );
        $data['taglist'] =$this->common_model
      ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['stafflist'] =$this->common_model
      ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['customerlist'] =$this->common_model
      ->get_all($table = "users", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['itemlist'] =$this->common_model
      ->get_all($table = "tbl_items", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('item_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.proposal.customer_proposal_add')->with($data);
    }

    public function save_customer_proposal(Request $request)

    {
         $rules = array(
             'start' => 'required',
           );
         $this->validate($request, $rules);
        // $fetaure = implode(',', $request->item_name);
        // print_r($fetaure);die;
         $save_data['tag_id'] =  $request->input('tag');
         $save_data['payment_type'] =  !empty($request->input('payment')) ?  $request->input('payment') : '';
         $save_data['agent_id'] =  !empty($request->input('agent')) ?  $request->input('agent') : 0;
         $save_data['recuring_invoice'] =  $request->input('recruit');
         $save_data['discount_type'] =  $request->input('dis_type');
         $save_data['admin_note'] =  $request->input('adminnote');
         $save_data['discount_percent'] =  $request->input('discount');
         $save_data['sub_total'] =  $request->input('sub_total');
         $save_data['discount'] =  $request->input('discount_total');
         $save_data['total_amount'] =  $request->input('overall_discount');
         $save_data['client_note'] =  $request->input('clientnote');
         $save_data['terms_condition'] =  $request->input('terms');
         $save_data['invoice_date'] =  $request->input('start');
         $save_data['due_date'] =  $request->input('expiry');
         $save_data['customer_id'] = $request->input('lead_id');
         $save_data['is_invoice'] =  2;
         $save_data['lead_id'] =  0;
         $otp=rand(10000,99999);
         $save_data['invoice_number'] = 'CRM'.'-'.$otp;
         $save_data['created_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
         
        $result = $this->common_model->insert_data_get_id($table = "tbl_invoices", $data1 = $save_data);
        $last_id=DB::getPdo()->lastInsertId();
        //print_r($last_id);die;
        $item_name = implode(',', $request->item_name);
        $item_description = implode(',', $request->long_description);
        $quantity = implode(',', $request->quantity);
        $item_rate = implode(',', $request->item_rate);
        $name_array = explode(',', $item_name);
        $description_array = explode(',', $item_description);
        $quantity_array = explode(',', $quantity);
        $rate_array = explode(',', $item_rate);
        $counter = 0;
        if(!empty($name_array)){
        foreach ($name_array as $key => $value)
        {
            $category_data = array();
            $category_data = array(
                'item_name' => $value,
                'item_description' => $description_array[$key],
                'invoice_id' => $last_id,
                "quantity" => $quantity_array[$key],
                "item_rate" => $rate_array[$key],
                'is_blocked' => 0,
                'created_at' =>  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes')),
            );
            
    
            $insert_id = $this->common_model->insert_data_get_id($table = "tbl_invoice_items", $data = $category_data);
            $counter++;
        }
      }
      
        
        
         if( $result){
         $data['success'] = trans('messages.393');
          }
           else{
         $data['danger'] = trans('messages.394');
          }
          return redirect('customer-proposal')->with($data); 
    }

     public function image_upload1($image_file){
        $image = $image_file;
        $name = time().'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('/uploads/contact_image');
        $image->move($destinationPath, $name);
        $img_path = $name;
        return $img_path;
    
    }
    public function lead_proposal_download($id){
        //  $id=  $request->input('id');
           $proposaldata = DB::table('tbl_invoices')->where('invoice_id', $id)->first();
          $invoive_number=$proposaldata->invoice_number;
           $data['proposaldata']= $proposaldata;
           $lead_id=$proposaldata->lead_id;
           $leaddata = DB::table('tbl_leads')->where('leads_id', $lead_id)->first();
           $itemdata = DB::table('tbl_invoice_items')->where('invoice_id', $id)->get();
          // print_r($itemdata);die;
           $data['leaddata']= $leaddata;
           $data['itemdata']= $itemdata;
          
            $pdf = PDF::loadView('pdf/proposal_pdf',$data);
            return $pdf->stream();
            
       
    }
    public function customer_update_proposal(Request $request)

{
     $rules = array(
         'start' => 'required',
       );
     $this->validate($request, $rules);
     $invoiceid=$request->id;
    // print_r($fetaure);die;
     $save_data['tag_id'] =  $request->input('tag');
     $save_data['payment_type'] =  !empty($request->input('payment')) ?  $request->input('payment') : '';
     $save_data['agent_id'] =  !empty($request->input('agent')) ?  $request->input('agent') : 0;
     $save_data['recuring_invoice'] =  $request->input('recruit');
     $save_data['discount_type'] =  $request->input('dis_type');
     $save_data['admin_note'] =  $request->input('adminnote');
     $save_data['discount_percent'] =  $request->input('discount');
     $save_data['sub_total'] =  $request->input('sub_total');
     $save_data['discount'] =  $request->input('discount_total');
     $save_data['total_amount'] =  $request->input('overall_discount');
     $save_data['client_note'] =  $request->input('clientnote');
     $save_data['terms_condition'] =  $request->input('terms');
     $save_data['invoice_date'] =  $request->input('start');
     $save_data['due_date'] =  $request->input('expiry');
     $save_data['customer_id'] = $request->input('lead_id');
     $save_data['is_invoice'] =  2;
     $save_data['lead_id'] = 0;
     $save_data['updated_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
     
    $result=DB::table('tbl_invoices')
        ->where('invoice_id',$invoiceid)
        ->update($save_data);
        DB::table('tbl_invoice_items')
        ->where('invoice_id', $invoiceid)
        ->delete();
    //print_r($last_id);die;
    $item_name = implode(',', $request->item_name);
    $item_description = implode(',', $request->long_description);
    $quantity = implode(',', $request->quantity);
    $item_rate = implode(',', $request->item_rate);
    $name_array = explode(',', $item_name);
    $description_array = explode(',', $item_description);
    $quantity_array = explode(',', $quantity);
    $rate_array = explode(',', $item_rate);
    $counter = 0;
    if(!empty($name_array)){
    foreach ($name_array as $key => $value)
    {
        $category_data = array();
        $category_data = array(
            'item_name' => $value,
            'item_description' => $description_array[$key],
            'invoice_id' => $invoiceid,
            "quantity" => $quantity_array[$key],
            "item_rate" => $rate_array[$key],
            'is_blocked' => 0,
            'created_at' =>  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes')),
        );
        

        $insert_id = $this->common_model->insert_data_get_id($table = "tbl_invoice_items", $data = $category_data);
        $counter++;
    }
  }
  $leademail = DB::table('tbl_leads')->where('leads_id', $request->input('lead_id'))->first();
  $emaillead = $leademail->email;
  $namelead = $leademail->name;
    
  if($request->send_type ==1 && $emaillead !=''){
    $email=$emaillead;
    $proposaldata = DB::table('tbl_invoices')->where('invoice_id', $result)->first();
    $data['proposaldata']= $proposaldata;
    $lead_id=$proposaldata->lead_id;
    $leaddata = DB::table('tbl_leads')->where('leads_id', $lead_id)->first();
    $itemdata = DB::table('tbl_invoice_items')->where('invoice_id', $result)->get();
    $data['leaddata']= $leaddata;
    $data['itemdata']= $itemdata;
    $emailData['name'] =  $namelead;
     $pdf = PDF::loadView('pdf/proposal_pdf',$data);
    //$pdf = PDF::loadView('pdf/invoice_pdf');
  //  return $pdf->download('pdfview.pdf');
  try{
    Mail::send('email.proposal',$emailData,function($message) use($email,$pdf)
    {
        $message->from('btninfosolution@gmail.com', 'PROPOSAL');
        $message->subject('Proposal');
        $message->to($email);
        $message->attachData($pdf->output(),'proposal.pdf');
    });
    $data['success'] = trans('messages.395');
}
catch(\Exception $e){
   // dd($e);die;
   $data['danger'] = trans('messages.396');
}

  }
     if( $result){
     $data['success'] = trans('messages.395');
      }
       else{
     $data['danger'] = trans('messages.396');
      }
      return redirect('customer-proposal')->with($data); 
}


  



    
}
