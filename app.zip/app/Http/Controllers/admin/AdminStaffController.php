<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminStaffController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_staff()
    {
        
        $data['page_title'] = "Group"; 
        $stafflist =$this->common_model
      ->get_all('tbl_staff', $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_type', '=', 2)), $join = array(), $left = array() , $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['addpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_add', '=', 0),array('left_menu_title', '=', 5)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['editpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_edit', '=', 0),array('left_menu_title', '=', 5)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['deletepermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('delete_permisson', '=', 0),array('left_menu_title', '=', 5)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['globalpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('global_view', '=', 1),array('left_menu_title', '=', 5)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['ownpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('own_view', '=', 1),array('left_menu_title', '=', 5)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      if(!empty($data['globalpermission'])){
        $data['stafflist'] =$stafflist;
      }
      if(session('user_type') ==1){
        $data['stafflist'] =$stafflist;
      }
       if(!empty($data['ownpermission'])){
        $stafflist1 =$this->common_model
      ->get_all('tbl_staff', $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_type', '=', 2),array('staff_id', '=', session('id'))), $join = array(), $left = array() , $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['stafflist'] =$stafflist1;
    }
      return view('admin.staff.staff_view')->with($data);
    }
    public function add_staff(Request $request){
        $data=array(
            'page_title'=>'Add Staff',
        );
        
        return view('admin.staff.add_staff')->with($data);
    }
    public function image_upload1($image_file){
        $image = $image_file;
        $name = time().'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('/uploads/contact_image');
        $image->move($destinationPath, $name);
        $img_path = $name;
        return $img_path;
    
    }
    public function save_staff(Request $request)

       {  //  echo "Ddd";die;
            $rules = array(
                'phone' => 'required|unique:tbl_staff,phone,NULL,staff_id,is_deleted,0',
                'email' => 'required|unique:tbl_staff,email,NULL,staff_id,is_deleted,0',
              );
            $this->validate($request, $rules);
            $save_data['first_name'] =  $request->input('first_name');
            $save_data['last_name'] =  $request->input('last_name');
            $save_data['hourly_rate'] =  $request->input('hourly_rate');
            $save_data['phone'] =  $request->input('phone');
            $save_data['email'] =  $request->input('email');
            $save_data['password'] = md5($request->input('password'));
            $save_data['facebook'] =  $request->input('facebook');
            $save_data['linkln'] =  $request->input('linkln');
            $save_data['skype'] =  $request->input('skype');
            $save_data['skype'] =  $request->input('skype');
            $save_data['twitter'] =   $request->input('twitter');
            $save_data['birth_date'] =   $request->input('birth_date');
            $save_data['anniversary_date'] =   $request->input('anniversary');
            $save_data['joining_date'] =   $request->input('join_date');
            $save_data['resign_date'] =   $request->input('resign_date');
            if ($request->hasFile('profile_image')) {
                $image = $request->file('profile_image');
               $img_path = $this->image_upload1($image);   
               $save_data['profile_image'] = $img_path;            
            }
            if ($request->hasFile('cv')) {
                $image = $request->file('cv');
               $img_path = $this->image_upload1($image);   
               $save_data['cv'] = $img_path;            
            }
            $save_data['created_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
            $result = $this->common_model->insert_data_get_id($table = "tbl_staff", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.504');
             }
              else{
            $data['error'] = trans('messages.505');
             }
        return redirect('staff')->with($data);
     }
    
    
     public function staff_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
        $postdata['Editdata'] = DB::table('tbl_staff')->where('staff_id', $data)->first();
       // print_r($postdata['Editdata']);die;
        return view('admin.staff.staff_edit')->with($postdata);
    }
    public function staff_detail($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
        $postdata['Editdata'] = DB::table('tbl_staff')->where('staff_id', $data)->first();
        $postdata['permissiondata'] = DB::table('tbl_staff_permission')->where('staff_id', $data)->get();
       // print_r($postdata['Editdata']);die;
        return view('admin.staff.staff_detail')->with($postdata);
    }
    public function update_staff( Request $request){
        $staff_id=$request->id;
        $rules = array(
            'email' => 'required|unique:tbl_staff,email,'.$staff_id.',staff_id,is_deleted,0',
            'phone' => 'required|unique:tbl_staff,phone,'.$staff_id.',staff_id,is_deleted,0',
        );
        $this->validate($request, $rules);
       
        $postData = $request->all();
        $priceid=$request->id;
        $data['first_name'] =  $request->input('first_name');
        $data['last_name'] =  $request->input('last_name');
        $data['hourly_rate'] =  $request->input('hourly_rate');
        $data['phone'] =  $request->input('phone');
        $data['email'] =  $request->input('email');
        $data['facebook'] =  $request->input('facebook');
        $data['linkln'] =  $request->input('linkln');
        $data['skype'] =  $request->input('skype');
        $data['twitter'] =  $request->input('twitter');
        $data['birth_date'] =   $request->input('birth_date');
        $data['anniversary_date'] =   $request->input('anniversary');
        $data['joining_date'] =   $request->input('join_date');
        $data['resign_date'] =   $request->input('resign_date');
        if ($request->hasFile('profile_image')) {
            $image = $request->file('profile_image');
           $img_path = $this->image_upload1($image);   
           $data['profile_image'] = $img_path;            
        }
        if ($request->hasFile('cv')) {
            $image = $request->file('cv');
           $img_path = $this->image_upload1($image);   
           $data['cv'] = $img_path;            
        }
        if($request->input('password') != ''){
            $data['password'] =  md5($request->input('password'));
        }
         $data['updated_at']= date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
         $result=DB::table('tbl_staff')
        ->where('staff_id',$staff_id)
        ->update($data);
         if( $result){
          $data['success'] = trans('messages.506');
        }
      else{
        $data['danger'] = trans('messages.507');
        }
        return redirect('staff')->with($data);  
   }
   public function save_permission(Request $request)

   { 
    $check_exist = $this->common_model->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', $request->input('staff_id'))), $join = array(), $left = array(), $right = array(), $order = array(), $group = "", $limit = array(), $raw = "", $paging = "");
    if(!empty($check_exist))
    {
      
        $delete = $this->common_model->delete_data($table = "tbl_staff_permission", $where = array(array('staff_id', '=', $request->input('staff_id'))));
    }
       
       if( $request->input('contract')=='1'){
        $save_data['staff_id'] =  $request->input('staff_id');
        $save_data['left_menu_title'] =  1;
        $save_data['global_view'] =  $request->has('global1') ? $request->has('global1') : 0;
        $save_data['own_view'] =   $request->has('view_own1') ? $request->has('view_own1') : 0;
        $save_data['is_add'] =  $request->has('add1') ? $request->has('add1') : 0;
        $save_data['is_edit'] =  $request->has('edit1') ? $request->has('edit1') : 0;
        $save_data['delete_permisson'] =  $request->has('delete1') ? $request->has('delete1') : 0;;
        $result = $this->common_model->insert_data_get_id($table = "tbl_staff_permission", $data1 = $save_data);
       }
       if( $request->input('customer')=='2'){
        $save_data['staff_id'] =  $request->input('staff_id');
        $save_data['left_menu_title'] =  2;
        $save_data['global_view'] =  $request->has('global2') ? $request->has('global2') : 0;
        $save_data['own_view'] =  $request->has('view_own2') ? $request->has('view_own2') : 0;
        $save_data['is_add'] =  $request->has('add2') ? $request->has('add2') : 0;
        $save_data['is_edit'] =  $request->has('edit2') ? $request->has('edit2') : 0;
        $save_data['delete_permisson'] =  $request->has('delete2') ? $request->has('delete2') : 0;
        $result = $this->common_model->insert_data_get_id($table = "tbl_staff_permission", $data1 = $save_data);
       }
       if( $request->input('item')=='3'){
        $save_data['staff_id'] =  $request->input('staff_id');
        $save_data['left_menu_title'] =  3;
        $save_data['global_view'] =  $request->has('global3') ? $request->has('global3') : 0;
        $save_data['own_view'] =  $request->has('view_own3') ? $request->has('view_own3') : 0;
        $save_data['is_add'] =  $request->has('add3') ? $request->has('add3') : 0;
        $save_data['is_edit'] =  $request->has('edit3') ? $request->has('edit3') : 0;
        $save_data['delete_permisson'] =  $request->has('delete3') ? $request->has('delete3') : 0;
        $result = $this->common_model->insert_data_get_id($table = "tbl_staff_permission", $data1 = $save_data);
       }
       if( $request->input('lead')=='4'){
        $save_data['staff_id'] =  $request->input('staff_id');
        $save_data['left_menu_title'] =  4;
        $save_data['global_view'] =  $request->has('global4') ? $request->has('global4') : 0;
        $save_data['own_view'] =  $request->has('view_own4') ? $request->has('view_own4') : 0;
        $save_data['is_add'] =  $request->has('add4') ? $request->has('add4') : 0;
        $save_data['is_edit'] =  $request->has('edit4') ? $request->has('edit4') : 0;
        $save_data['delete_permisson'] =  $request->has('delete4') ? $request->has('delete4') : 0;
        $result = $this->common_model->insert_data_get_id($table = "tbl_staff_permission", $data1 = $save_data);
       }
       if( $request->input('staff')=='5'){
        $save_data['staff_id'] =  $request->input('staff_id');
        $save_data['left_menu_title'] =  5;
        $save_data['global_view'] =  $request->has('global5') ? $request->has('global5') : 0;
        $save_data['own_view'] =  $request->has('view_own5') ? $request->has('view_own5') : 0;
        $save_data['is_add'] =  $request->has('add5') ? $request->has('add5') : 0;
        $save_data['is_edit'] =  $request->has('edit5') ? $request->has('edit5') : 0;
        $save_data['delete_permisson'] =  $request->has('delete5') ? $request->has('delete5') : 0;
        $result = $this->common_model->insert_data_get_id($table = "tbl_staff_permission", $data1 = $save_data);
       }
       if( $request->input('task')=='6'){
        $save_data['staff_id'] =  $request->input('staff_id');
        $save_data['left_menu_title'] =  6;
        $save_data['global_view'] =  $request->has('global6') ? $request->has('global6') : 0;
        $save_data['own_view'] =  $request->has('view_own6') ? $request->has('view_own6') : 0;
        $save_data['is_add'] =  $request->has('add6') ? $request->has('add6') : 0;
        $save_data['is_edit'] =  $request->has('edit6') ? $request->has('edit6') : 0;
        $save_data['delete_permisson'] =  $request->has('delete6') ? $request->has('delete6') : 0;
        $result = $this->common_model->insert_data_get_id($table = "tbl_staff_permission", $data1 = $save_data);
       }
       if( $result){
        $data['success'] = 'Permission has been given successfully';
      }
    else{
      $data['danger'] = 'Permission has not  been given successfully';
      }
      return redirect('staff')->with($data);  
   }
  



    
}
