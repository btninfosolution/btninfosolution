<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
//use PHPExcel_IOFactory;
//use PHPExcel;
//use PHPExcel_Writer_Excel2007;
use DB;
use Excel;



class AdminLoginController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

    function decode_validator_error($input)
	{
		$error_array = json_decode($input,true);
		$msg= "";
		foreach($error_array as $k=>$v){
			$msg .= $v[0];
		}
		return $msg;
	}


    public function reset_password(Request $input, $user_data=false)
    {
        $data = array();
        if($user_data)
        {
            $data['page_title'] = "Forget Password";
            $data['user_data'] = $user_data;
        }
        else
        {
            $data['page_title'] = "Forget Password";
            $data['user_data'] = '';
        }
        return view('admin.login.forgot_password')->with($data);
    }

    public function reset_password_user(Request $request, $user_data=false)
    {
        $data = array();
        if($user_data)
        {
            $data['page_title'] = "Change password";
            $data['user_data'] = $user_data;
        }
        else
        {
            $data['page_title'] = "Change password";
            $data['user_data'] = '';
        }
        
        return view('admin.login.reset_password_user')->with($data);
    }

    public function reset_password_status(Request $input, $user_data=false)
    {
        $data = array();        
        return view('admin_view.login.reset_password_status')->with($data);
    }

    public function send_reset_password_link(Request $Request)
    {
        $email = $Request->input('email'); 
        if(!empty($email))
        {
            $eheck_email = $this->common_model->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('email', '=', $email)), $join = array(), $left = array(), $right = array(), $order = array(), $group = "", $limit = array(), $raw = "", $paging = "");
            if(empty($eheck_email))
            {
                $response_data = ['type'=>'danger','text'=>'Invalid email.'];
            }
            else
            {
                $url = time().'-'.$email.'-type=admin';
                $url = Crypt::encrypt($url);
                $redirect_url = url('resetpassword/'.$url); 
                //$res = file_get_contents($redirect_url);
                $emailData['redirect_url'] = $redirect_url;
                try{
                    Mail::send('email.reset_password',$emailData,function($message) use($email)
                    {
                        $message->from('btninfosolution@gmail.com', 'CRM');
                        $message->subject('Reset Password Link');
                        $message->to('sumit.das.ncrts@gmail.com');
                    });
                   
                    $response_data = ['type'=>'success','text'=>'Reset password link has been send to your mail.'];
              //   $response_data = ['type'=>'success','text'=>$this->message = trans('messages.328')];
                }
                catch(\Exception $e){
                    dd($e);die;
                   $response_data = ['type'=>'danger','text'=>'Reset password link has not  been send to your mail.'];
                }
            }
        }
        else
        {
            $password = $input->input('password');
            $confirm_password = $input->input('confirm_password');
            if($password && $confirm_password)
            {
                if($password==$confirm_password)
                {
                    $user_data = $input->input('user_data'); 
                    $user_data = Crypt::decrypt($user_data);
                    $user_data = explode('-', $user_data);
                    $time = $user_data[0];
                    $email = $user_data[1];
                    //validate time
                    $endTime = strtotime("+30 minutes", strtotime($time));
                    $vali_till = $time+$endTime; 
                    if($vali_till > time())
                    {
                        $admin_data['password'] = md5($password);
                        $update = $this->common_model->update_data('admin', array(array('email','=',$email)), $admin_data);
                        if($update)
                        {
                            $response_data=['type'=>'error','text'=>'Successfully updated.'];
                            return redirect('/admin-login')->with('message',$response_data);
                        }
                        else
                        {
                            $response_data=['type'=>'error','text'=>'Invalid reset link.'];
                            return redirect('/admin-login')->with('message',$response_data);
                        }
                    }
                    else
                    {
                        $response_data=['type'=>'error','text'=>'Invalid reset link.'];
                        return redirect('/admin-login')->with('message',$response_data);
                    }
                }
                else
                {
                    $response_data=['type'=>'error','text'=>'Password & confirm password not match.'];
                    return redirect('/reset-password/'.$user_data)->with('message',$response_data);
                }
            }
            else
            {
                $response_data=['type'=>'error','text'=>'Password & confirm password required.'];
                return redirect('/reset-password/'.$user_data)->with('message',$response_data);
            }
        }

        return redirect('/reset-password')->with('message',$response_data);
    }

    public function user_reset_password(Request $input)
    {
        $password = $input->input('password');
        $confirm_password = $input->input('confirm_password');
        if($password && $confirm_password)
        {
            if($password==$confirm_password)
            {
                $user_data = $input->input('user_data'); 
                $user_data = Crypt::decrypt($user_data);
                $user_data = explode('-', $user_data);
                $time = $user_data[0];
                $email = $user_data[1];
                $type = $user_data[2];
               // $admin_data['password'] = md5($password);
                if($type =='type=admin'){
                  $admin_data['password'] = md5($password);
                $update = $this->common_model->update_data('tbl_admin', array(array('email','=',$email)), $admin_data);
                }else{
                $admin_data['password'] = bcrypt($password);
                $update = $this->common_model->update_data('users', array(array('email','=',$email)), $admin_data);
                }
               // print_r($update);die;
                if($update)
                {
                    $response_data=['type'=>'success','text'=>$this->message = trans('messages.333')];
                    return redirect('/admin-login')->with('message',$response_data);
                }
                else
                {
                   // $response_data=['type'=>'error','text'=>$this->message = trans('messages.3')];
                   // return redirect('/resetpassword')->with('message',$response_data);
                   $response_data=['type'=>'error','text'=>$this->message = trans('messages.2')];
                   return redirect('/resetpassword/'.$input->input('user_data'))->with('message',$response_data);
                }

                //validate time
                /*$endTime = strtotime("+30 minutes", strtotime($time));
                $vali_till = $time+$endTime; 
                if($vali_till > time())
                {
                    
                }
                else
                {
                    $response_data=['type'=>'error','text'=>'Invalid reset link.'];
                    return redirect('/reset-password-status')->with('message',$response_data);
                }*/
            }
            else
            {
                $response_data=['type'=>'danger','text'=>$this->message = trans('messages.334')];
                return redirect('/resetpassword/'.$input->input('user_data'))->with('message',$response_data);
            }
        }
        else
        {
            $response_data=['type'=>'error','text'=>$this->message = trans('messages.4')];
            return redirect('/resetpassword/'.$input->input('user_data'))->with('message',$response_data);
        }

        return redirect('/resetpassword')->with('message',$response_data);
    }

    public function adminLogin()
    {
        
        $email = isset($_COOKIE['angel_email']) && $_COOKIE['angel_email'] ? $_COOKIE['angel_email'] : '';
        $password = isset($_COOKIE['angel_password']) && $_COOKIE['angel_password'] ? $_COOKIE['angel_password'] : '';
        if($email && $password)
        {
            $data['log_data'] = array('email' => $email, 'password' => $password);
        }
        else
        {
            $data['log_data'] = array('email' => '', 'password' => '');
        }
        $data['page_title'] = "Login";
        //echo $this->message = trans('messages.13'); die();
        return view('admin.login.loginn')->with($data);
    }
    

    public function admin_login_process(Request $data)
    {
        
       
      
         $email = $data->input('email') ;
        $password = $data->input('password') ;
      
     
        $status = $this->common_model->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('email', '=', $email), array('password', '=', md5($password))), $join = array(), $left = array(), $right = array(), $order = array(), $group = "", $limit = array(), $raw = "", $paging = "");
       
        if($status && !empty($status))
        {
            if ($status[0]->is_blocked == 0) {
                Session::put('id', $status[0]->staff_id);
                Session::put('name', $status[0]->first_name);
                Session::put('email', $status[0]->email);
                Session::put('user_type', $status[0]->user_type);
               // Session::put('image', $status[0]->image);
                $save_data['login_by'] = $status[0]->first_name.' '. $status[0]->last_name ;
              //  $save_data['browser'] =  $data->header('User-Agent'); 
                //$browser = get_browser(null, true);
                  $u_agent = $_SERVER['HTTP_USER_AGENT'];
                   $bname = 'Unknown';
                   $platform = 'Unknown';
                   if (preg_match('/linux/i', $u_agent)) {
                     $platform = 'linux';
                   }
                   elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
                       $platform = 'mac';
                    }
                  elseif (preg_match('/windows|win32/i', $u_agent)) {
                    $platform = 'windows';
                     }
                  if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent))
                   {
                      $bname = 'Internet Explorer';
                      $ub = "MSIE";
                    }
                    elseif(preg_match('/Firefox/i',$u_agent))
                     {
                       $bname = 'Mozilla Firefox';
                       $ub = "Firefox";
                     }
                    elseif(preg_match('/Chrome/i',$u_agent))
                    {
                        $bname = 'Google Chrome';
                        $ub = "Chrome";
                    }
                   elseif(preg_match('/Safari/i',$u_agent))
                    {
                       $bname = 'Apple Safari';
                       $ub = "Safari";
                    }
                 elseif(preg_match('/Opera/i',$u_agent))
                   {
                       $bname = 'Opera';
                       $ub = "Opera";
                    }
                 elseif(preg_match('/Netscape/i',$u_agent))
                   {
                      $bname = 'Netscape';
                      $ub = "Netscape";
                    }
                  $save_data['browser'] =  $bname;
                  $save_data['ip'] = $_SERVER["REMOTE_ADDR"];
                  $saved = $this->common_model->insert_data_get_id($table = "tbl_access_log", $data1 = $save_data);
                   if($data->input('is_remember')=='yes')
                     {   
                    
                    //Set email
                    $cookie_email_data = "angel_email";
                    $cookie_email_value = $email;
                    setcookie($cookie_email_data, $cookie_email_value, time() + (86400 * 90), "/"); 
                    //Set Passsword
                    $cookie_password_data = "angel_password";
                    $cookie_password_value = $password;
                    setcookie($cookie_password_data, $cookie_password_value, time() + (86400 * 90), "/");
                }
                else
                {
                    $cookie_email_data = "angel_email";
                    $cookie_email_value = '';
                    setcookie($cookie_email_data, $cookie_email_value, time() + (86400 * 90), "/");
                    $cookie_password_data = "angel_password";
                    $cookie_password_value = '';
                    setcookie($cookie_password_data, $cookie_password_value, time() + (86400 * 90), "/");

                }

              //  return redirect('customer');
              return redirect('admin-dashboard');
            } else {
                return redirect('/admin-login')->with('message',['type'=>'danger','text'=>'Account has been blocked']);
            }
        }
        else {
          //  $save_data['login_by'] =  $status[0]->first_name ;
            $save_data['browser'] =  $data->header('User-Agent');
            $save_data['status'] =  2;
            $save_data['ip'] = $_SERVER["REMOTE_ADDR"];
            $saved = $this->common_model->insert_data_get_id($table = "tbl_access_log", $data1 = $save_data);
            return redirect('/admin-login')->with('message',['type'=>'danger','text'=>$this->message = trans('messages.323')]);
        }
        return redirect('/admin-login')->with('message',['type'=>'danger','text'=>$this->message = trans('messages.323')]);
    }
    public function forgotPassword()
    {
        
        $data['page_title'] = "Forget password";
        //echo $this->message = trans('messages.13'); die();
        return view('admin.login.forgot_password')->with($data);
    }

    public function admin_logout()
    {
        Session::flush();
        //\Session::flash('flash_message', 'Successfully logged out');
        return redirect('/admin-login');
    }

    public function change_password()
    {
        return view('admin_view.dashboard.change_password');  
    }

    public function change_password_process(Request $data){
        $admin_id = session()->get('id');

        $validator = Validator::make($data->all(),['current_password' => 'required',
                                                    'new_password' => 'required',    
                                                    'confirm_password' => 'required',
                                                    ]);
        if($validator->fails()){
            return redirect('/admin-change-password')
                            ->withErrors($validator)
                            ->withInput();
         }

        $current_password = $data->input('current_password') ;
        $new_password = $data->input('new_password') ;
        $confirm_password = $data->input('confirm_password') ;
     
        $check_current_password = $this->common_model->get_all($table = "admin", $select = array('*'), $where = array(array('id', '=', $admin_id), array('password', '=', md5($current_password))), $join = array(), $left = array(), $right = array(), $order = array(), $group = "", $limit = array(), $raw = "", $paging = "");
        if($check_current_password && !empty($check_current_password))
        {
            if ($check_current_password[0]->status == 1) {
                $admin_data['password'] = md5($new_password);
                $this->common_model->update_data('admin', array(array('id','=',$admin_id)), $admin_data);

                return redirect('/admin-change-password')->with('message',['type'=>'success','text'=>'Password has been changed successfully.']);
            } else {
                return redirect('/admin-change-password')->with('message',['type'=>'danger','text'=>'Your account has been blocked.']);
            }
        }
        else {
            return redirect('/admin-change-password')->with('message',['type'=>'danger','text'=>'Current password does not matched.']);
        }
        
    }

    

    /******** Global Delete Start *********/
    public function delete_row(Request $request)
    {
        $masterwhere = array();
        $field = $request->input('field');
        $id = $request->input('id');
        $table = $request->input('table');
        array_push($masterwhere, array($field,'=',$id));
        $result = $this->common_model->delete_data($table, $masterwhere);
        if($result)
        {
            return "success";
        }
        else
        {
            return "error";
        }
        
    }
    
}
