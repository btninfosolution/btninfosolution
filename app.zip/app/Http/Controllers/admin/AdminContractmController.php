<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminContractmController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  //public function index(){
   
 //  $names = Users::pluck('name', 'id');
   
  // dd($names);
//}  
    public function admin_contractm()
    {
        
        $data['page_title'] = "Contract"; 
        $left = array(
            array('users AS b','a.customer_id','=','b.id'),
      ); 
       $contractmlist =$this->common_model
      ->get_all('tbl_contractm AS a', $select = array('a.*', 'b.client_name as client_name'), $where = array(array('a.is_deleted', '=', 0)), $join = array(), $left , $right = array(), $order = array(array('a.contractm_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['addpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_add', '=', 0),array('left_menu_title', '=', 1)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['editpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_edit', '=', 0),array('left_menu_title', '=', 1)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['deletepermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('delete_permisson', '=', 0),array('left_menu_title', '=', 1)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['globalpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('global_view', '=', 0),array('left_menu_title', '=', 1)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      if(!empty($data['globalpermission'])){
        $data['contractmlist'] ="";
      }else{
        $data['contractmlist'] = $contractmlist;
      }
    //  print_r($data['addpermission']);die;
        return view('admin.contractm.contractm_view')->with($data);
    }
	

    public function add_contractm(Request $request){
        // echo "ddd";die;
         $data=array(
             'page_title'=>'Add Expense',
         );
         $data['expense_catogorylist'] =$this->common_model
      ->get_all($table = "tbl_expense_catogory", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('expense_catogory_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['customerlist'] =$this->common_model
      ->get_all($table = "users", $select = array('*'), $where = array(array('is_deleted', '=', 0,),array('user_type', '=', 2,),array('is_blocked', '=', 0,)), $join = array(), $left = array(), $right = array(), $order = array(array('id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['contypelist'] =$this->common_model
      ->get_all($table = "tbl_contract", $select = array('*'), $where = array(array('is_deleted', '=', 0,),array('is_blocked', '=', 0,)), $join = array(), $left = array(), $right = array(), $order = array(array('contract_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
         return view('admin.contractm.add_contractm')->with($data);
     }
	   
   
    public function save_contractm(Request $request)

       {
		      
			$save_data['customer_id'] =  $request->input('customer_id');
            $save_data['contractm_subject'] =  $request->input('subject');
			$save_data['contractm_value'] =  $request->input('amount');
			$save_data['contractm_type'] =  $request->input('contype_id');
			$save_data['contractm_stdt'] =  $request->input('start');
			$save_data['contractm_enddt'] =  $request->input('expiry'); 
			$save_data['contractm_desc'] =  $request->input('description');
			$save_data['created_at'] = date('Y-m-d H:i:s');
			$result = $this->common_model->insert_data_get_id($table = "tbl_contractm", $data1 = $save_data);
            if( $result){
			 $data['success'] = trans('messages.380');
             }
              else{
            $data['danger'] = trans('messages.381');
             }
        return redirect('contractm')->with($data);
     }
    
    
     public function contractm_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('tbl_contractm')->where('contractm_id', $data)->first();
       $postdata['customerlist'] =$this->common_model
       ->get_all($table = "users", $select = array('*'), $where = array(array('is_deleted', '=', 0,),array('user_type', '=', 2,),array('is_blocked', '=', 0,)), $join = array(), $left = array(), $right = array(), $order = array(array('id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
       $postdata['contypelist'] =$this->common_model
       ->get_all($table = "tbl_contract", $select = array('*'), $where = array(array('is_deleted', '=', 0,),array('is_blocked', '=', 0,)), $join = array(), $left = array(), $right = array(), $order = array(array('contract_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
       return view('admin.contractm.contractm_edit')->with($postdata);
    }
    public function update_contractm( Request $request){
            $Contractid=$request->id;
             $postData = $request->all();
             $data['customer_id']=$postData["customer_id"];
             $data['contractm_subject']=$postData["subject"];
             $data['contractm_value']=$postData["amount"];
             $data['contractm_type']=$postData["contype_id"];
             $data['contractm_stdt']=$postData["start"];
             $data['contractm_enddt']=$postData["expiry"];
             $data['contractm_desc']=$postData["description"];
             $data['updated_at']=date('Y-m-d H:i:s');
             $result=DB::table('tbl_contractm')
            ->where('contractm_id',$Contractid)
            ->update($data);
             if( $result){
              $data['success'] = trans('messages.382');
            }
          else{
            $data['danger'] = trans('messages.383');
            }
            return redirect('contractm')->with($data);  
   }

  



    
}
