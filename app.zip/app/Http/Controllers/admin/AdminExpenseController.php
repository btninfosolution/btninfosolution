<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminExpenseController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_expense()
    {
        
        $data['page_title'] = "Expense"; 

        $left = array(
            array('tbl_expense_catogory AS b','a.expense_catogory_id','=','b.expense_catogory_id'),
            array('users AS c','a.customer_id','=','c.id'),
        ); 
       $data['expenselist'] =$this->common_model
      ->get_all('tbl_expense AS a', $select = array('a.*', 'b.expense_catogory_name as expense_catogory_name','c.client_name as company_name'), $where = array(array('a.is_deleted', '=', 0)), $join = array(), $left , $right = array(), $order = array(array('a.expense_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.expense.expense_view')->with($data);
    }
    public function add_expense(Request $request){
       // echo "ddd";die;
        $data=array(
            'page_title'=>'Add Expense',
        );
        $data['expense_catogorylist'] =$this->common_model
     ->get_all($table = "tbl_expense_catogory", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('expense_catogory_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
     $data['customerlist'] =$this->common_model
     ->get_all($table = "users", $select = array('*'), $where = array(array('is_deleted', '=', 0,),array('user_type', '=', 2,)), $join = array(), $left = array(), $right = array(), $order = array(array('id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.expense.add_expense')->with($data);
    }
    public function save_expense(Request $request)

       {  //  echo "Ddd";die;
            $rules = array(
                'name' => 'required',
              );
            $this->validate($request, $rules); 
            $save_data['name'] =  $request->input('name');
            $save_data['note'] =  $request->input('note');
            $save_data['expense_catogory_id'] =  $request->input('expense_catogory_id');
            $save_data['expence_date'] =  $request->input('expence_date');
            $save_data['amount'] =  $request->input('amount');
            $save_data['customer_id'] =  $request->input('customer_id');
            $save_data['currency'] =  $request->input('currency');
            $save_data['tax1'] =  $request->input('tax1');
            $save_data['tax2'] =  $request->input('tax2');
            $save_data['payment_mode'] =  $request->input('payment_mode');
            $save_data['reference'] =  $request->input('reference');
            $save_data['repeat_every'] =  "";
            $save_data['created_at'] = date('Y-m-d H:i:s');
            $result = $this->common_model->insert_data_get_id($table = "tbl_expense", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.358');
             }
              else{
            $data['danger'] = trans('messages.359');
             }
        return redirect('expense')->with($data);
     }
    
    
     public function expense_edit($id){
       try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
        $postdata['Editdata'] = DB::table('tbl_expense')->where('expense_id', $data)->first();
        $postdata['expense_catogorylist'] =$this->common_model
     ->get_all($table = "tbl_expense_catogory", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('expense_catogory_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
     $postdata['customerlist'] =$this->common_model
     ->get_all($table = "users", $select = array('*'), $where = array(array('is_deleted', '=', 0,),array('user_type', '=', 2,)), $join = array(), $left = array(), $right = array(), $order = array(array('id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
       // print_r($postdata['Editdata']);die;
        return view('admin.expense.expense_edit')->with($postdata);
    }
    public function update_expense( Request $request){
        $expense_id=$request->id;       
        $postData = $request->all();
        $rules = array(
            'name' => 'required',
          );
        $save_data['name'] =  $request->input('name');
        $save_data['note'] =  $request->input('note');
        $save_data['expense_catogory_id'] =  $request->input('expense_catogory_id');
        $save_data['expence_date'] =  $request->input('expence_date');
        $save_data['amount'] =  $request->input('amount');
        $save_data['customer_id'] =  $request->input('customer_id');
        $save_data['currency'] =  $request->input('currency');
        $save_data['tax1'] =  $request->input('tax1');
        $save_data['tax2'] =  $request->input('tax2');
        $save_data['payment_mode'] =  $request->input('payment_mode');
        $save_data['reference'] =  $request->input('reference');
        $save_data['repeat_every'] =  "";
        $data['updated_at']=date('Y-m-d H:i:s');
        $result=DB::table('tbl_expense')
        ->where('expense_id',$expense_id)
        ->update($save_data);
         if( $result){
          $data['success'] = trans('messages.360');
        }
      else{
        $data['danger'] = trans('messages.361');
        }
        return redirect('expense')->with($data);  
   }

  



    
}
