<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminItemController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_item()
    {
        
        $data['page_title'] = "Group"; 
        $itemlist =$this->common_model
      ->get_all('tbl_items', $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array() , $right = array(), $order = array(array('item_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['addpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_add', '=', 0),array('left_menu_title', '=', 3)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['editpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_edit', '=', 0),array('left_menu_title', '=', 3)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['deletepermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('delete_permisson', '=', 0),array('left_menu_title', '=', 3)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['globalpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('global_view', '=', 0),array('left_menu_title', '=', 3)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      if(!empty($data['globalpermission'])){
        $data['itemlist'] ="";
      }else{
        $data['itemlist'] = $itemlist;
      }
        return view('admin.items.item_view')->with($data);
    }
    public function add_item(Request $request){
        $data=array(
            'page_title'=>'Add Item',
        );
        return view('admin.items.add_item')->with($data);
    }
    public function save_item(Request $request)

       {
            $rules = array(
                'item_name' => 'required|unique:tbl_items,item_name,NULL,item_id,is_deleted,0',
                'rate' => 'required',
                'tax' => 'required',
                'unit' => 'required',
                'description' => 'required',
              );
            $this->validate($request, $rules);
            $save_data['item_name'] =  $request->input('item_name');
            $save_data['rate'] =  $request->input('rate');
            $save_data['tax'] =  $request->input('tax');
            $save_data['unit'] =  $request->input('unit');
            $save_data['description'] =  $request->input('description');
            $save_data['created_at'] = date('Y-m-d H:i:s');
           $result = $this->common_model->insert_data_get_id($table = "tbl_items", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.339');
             }
              else{
            $data['danger'] = trans('messages.340');
             }
        return redirect('item')->with($data);
     }
    
    
     public function item_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('tbl_items')->where('item_id', $data)->first();
       return view('admin.items.item_edit')->with($postdata);
    }
    public function update_item( Request $request){
        $itemid=$request->id;
        
            $rules = array(
            'item_name' => 'required|unique:tbl_items,item_name,'.$itemid.',item_id,is_deleted,0',
            'rate' => 'required',
            'tax' => 'required',
            'unit' => 'required',
            'description' => 'required',
            );
            $this->validate($request, $rules);
           
             $postData = $request->all();
             $priceid=$request->id;
             $data['item_name']=$postData["item_name"];
             $data['rate']=$postData["rate"];
             $data['tax']=$postData["tax"];
             $data['unit']=$postData["unit"];
             $data['description']=$postData["description"];
             $data['updated_at']=date('Y-m-d H:i:s');
             $result=DB::table('tbl_items')
            ->where('item_id',$itemid)
            ->update($data);
             if( $result){
              $data['success'] = trans('messages.341');
            }
          else{
            $data['danger'] = trans('messages.342');
            }
            return redirect('item')->with($data);  
   }

  



    
}
