<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminLeadsController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_leads()
    {
        
        $data['page_title'] = "Leads";
        $check_data = \DB::select("select count(*) as tbl_leads From tbl_leads Where is_deleted = '0' ");
        $data['tbl_leads']=$check_data[0]->tbl_leads;
        $check_active_data = \DB::select("select count(*) as tbl_leads From tbl_leads Where is_blocked = 0 AND is_deleted = '0' ");
        $data['active_users']=$check_active_data[0]->tbl_leads; 
        $check_inactive_data = \DB::select("select count(*) as tbl_leads From tbl_leads Where is_blocked = 1 AND is_deleted = '0' ");
        $data['inactive_users']=$check_inactive_data[0]->tbl_leads; 

        $left = array(
            array('tbl_leads_status AS b','a.leads_status','=','b.status_id'),
            array('tbl_leads_sources AS c','a.leads_source','=','c.sources_id'),
            array('tbl_tags AS d','a.tag_id','=','d.tag_id'),
            array('tbl_staff AS e','a.leads_assigned','=','e.staff_id'),
		     ); 
       $data['leadslist'] =$this->common_model
      ->get_all('tbl_leads AS a', $select = array('a.*', 'b.status_name as status_name', 'c.sources_name as sources_name', 'd.tag_name as tag_name', 'e.first_name as first_name', 'e.last_name as last_name'), $where = array(array('a.is_deleted', '=', 0)), $join = array(), $left , $right = array(), $order = array(array('a.leads_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
  	  return view('admin.leads.leads_view')->with($data);
    }
      
    public function add_leads(Request $request){
        $data=array(
            'page_title'=>'Add Customer',
        );
		$data['statuslist'] =$this->common_model
     ->get_all($table = "tbl_leads_status", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('status_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
		
		$data['taglist'] =$this->common_model
    ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
    $data['stafflist'] =$this->common_model
    ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
		$data['sourcelist'] =$this->common_model
    ->get_all($table = "tbl_leads_sources", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('sources_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");

	//   $data['countrylist'] =$this->common_model
    // ->get_all($table = "tbl_countries", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('country_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.leads.add_leads')->with($data);
    }
    public function save_leads(Request $request)

       {
            
            $save_data['leads_status'] =  $request->input('status');
			$save_data['leads_source'] =  $request->input('sources');
			$save_data['name'] =  $request->input('name');
            $save_data['leads_assigned'] =  $request->input('staff') ? $request->input('staff') : 0;
            $save_data['tag_id'] =  $request->input('tag') ? $request->input('tag') : 0;
			$save_data['address'] =  $request->input('address');
			$save_data['position'] =  $request->input('position');
			$save_data['city'] =  $request->input('city');
			$save_data['email'] =  $request->input('email');
			$save_data['state'] =  $request->input('state');
			$save_data['country'] =  $request->input('country');
			$save_data['website'] =  $request->input('website');
			$save_data['phone'] =  $request->input('phone');
			$save_data['zipcode'] =  $request->input('zip');
			$save_data['company'] =  $request->input('company');
			$save_data['description'] =  $request->input('description');
			$save_data['created_at'] = date('Y-m-d H:i:s');
			$result = $this->common_model->insert_data_get_id($table = "tbl_leads", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.389');
             }
              else{
            $data['error'] = trans('messages.390');
             }
        return redirect('leads')->with($data);
     }
    
	
	
	
	   public function leads_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
     

       $left = array(
           array('tbl_leads_status AS b','a.leads_status','=','b.status_id'),
		     ); 
       $postdata['leadslist'] =$this->common_model
      ->get_all('tbl_leads AS a', $select = array('a.*', 'b.status_name as status_name'), $where = array(array('a.is_deleted', '=', 0)), $join = array(), $left , $right = array(), $order = array(array('a.leads_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $postdata['stafflist'] =$this->common_model
      ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
	  $postdata['taglist'] =$this->common_model
    ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
	
		$postdata['sourcelist'] =$this->common_model
    ->get_all($table = "tbl_leads_sources", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('sources_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");

	   $postdata['Editdata'] = DB::table('tbl_leads')->where('leads_id', $data)->first();
       return view('admin.leads.leads_edit')->with($postdata);
	  
    }
	
	
	
    
     public function leads_detail($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('tbl_leads')->where('leads_id', $data)->first();
       $postdata['grouplist'] =$this->common_model
       ->get_all($table = "tbl_leads_status", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('status_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
       $postdata['countrylist'] =$this->common_model
       ->get_all($table = "tbl_leads_sources", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('sources_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
       $postdata['enc_type']=$id;
       return view('admin.leads.leads_detail')->with($postdata);
    }
	
	
    public function update_leads( Request $request){
       
		   $taxid=$request->id;
        
           
             $postData = $request->all();
			$priceid=$request->id;
			
            $data['leads_status'] =  $postData["status"];
			$data['leads_source'] =  $postData["sources"];
			$data['tag_id'] = $postData["tag"] ? $postData["tag"] : 0;
			$data['name'] =  $postData["name"];
			$data['leads_assigned'] =  $postData["staff"] ? $postData["staff"] : 0;
			$data['address'] =  $postData["address"];
			$data['position'] =  $postData["position"];
			$data['city'] =  $postData["city"];
			$data['email'] =  $postData["email"];
			$data['state'] =  $postData["state"];
			$data['country'] =  $postData["country"];
			$data['website'] =  $postData["website"];
			$data['phone'] =  $postData["phone"];
			$data['zipcode'] =  $postData["zipcode"];
			$data['company'] =  $postData["company"];
			$data['description'] =  $postData["description"];
			$data['created_at'] = date('Y-m-d H:i:s');
			
			 $result=DB::table('tbl_leads')
            ->where('leads_id',$taxid)
            ->update($data);
							  
            if( $result){
            $data['success'] = trans('messages.391');
             }
              else{
            $data['error'] = trans('messages.392');
             }
        return redirect('leads')->with($data);
     }
    
      
}
