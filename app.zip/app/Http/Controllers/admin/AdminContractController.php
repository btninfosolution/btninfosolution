<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminContractController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_contract()
    {
        
        $data['page_title'] = "Contract"; 
       $data['contractlist'] =$this->common_model
      ->get_all('tbl_contract', $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array() , $right = array(), $order = array(array('contract_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.contract.contract_view')->with($data);
    }
    public function add_contract(Request $request){
        $data=array(
            'page_title'=>'Add Contract',
        );
        return view('admin.contract.add_contract')->with($data);
    }
    public function save_contract(Request $request)

       {
	
            $rules = array(
                'contract_name' => 'required|unique:tbl_contract,contract_name,NULL,contract_id,is_deleted,0',
              );
            $this->validate($request, $rules);
            $save_data['contract_name'] =  $request->input('contract_name');
			$save_data['created_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
           $result = $this->common_model->insert_data_get_id($table = "tbl_contract", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.353');
             }
              else{
            $data['error'] = trans('messages.354');
             }
        return redirect('contract-type')->with($data);
     }
    
    
     public function contract_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('tbl_contract')->where('contract_id', $data)->first();
       return view('admin.contract.contract_edit')->with($postdata);
    }
    public function update_contract( Request $request){
        $Contractid=$request->id;
        
            $rules = array(
            'contract_name' => 'required|unique:tbl_contract,contract_name,'.$Contractid.',contract_id,is_deleted,0',
            );
            $this->validate($request, $rules);
           
             $postData = $request->all();
             $priceid=$request->id;
             $data['contract_name']=$postData["contract_name"];
			
             $data['updated_at']= date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
             $result=DB::table('tbl_contract')
            ->where('contract_id',$Contractid)
            ->update($data);
             if( $result){
              $data['success'] = trans('messages.384');
            }
          else{
            $data['danger'] = trans('messages.385');
            }
            return redirect('contract-type')->with($data);  
   }

  



    
}
