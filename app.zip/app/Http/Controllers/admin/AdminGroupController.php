<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminGroupController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_group()
    {
        
        $data['page_title'] = "Group"; 
       $data['grouplist'] =$this->common_model
      ->get_all('tbl_groups', $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array() , $right = array(), $order = array(array('group_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.group.group_view')->with($data);
    }
    public function add_group(Request $request){
        $data=array(
            'page_title'=>'Add Group',
        );
        return view('admin.group.add_group')->with($data);
    }
    public function save_group(Request $request)

       {
            $rules = array(
                'group_name' => 'required|unique:tbl_groups,group_name,NULL,group_id,is_deleted,0',
              );
            $this->validate($request, $rules);
            $save_data['group_name'] =  $request->input('group_name');
            $save_data['created_at'] = date('Y-m-d H:i:s');
           $result = $this->common_model->insert_data_get_id($table = "tbl_groups", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.312');
             }
              else{
            $data['error'] = trans('messages.313');
             }
        return redirect('group')->with($data);
     }
    
    
     public function group_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('tbl_groups')->where('group_id', $data)->first();
       return view('admin.group.group_edit')->with($postdata);
    }
    public function update_group( Request $request){
        $groupid=$request->id;
        
            $rules = array(
            'group_name' => 'required|unique:tbl_groups,group_name,'.$groupid.',group_id,is_deleted,0',
            );
            $this->validate($request, $rules);
           
             $postData = $request->all();
             $priceid=$request->id;
             $data['group_name']=$postData["group_name"];
             $data['updated_at']=date('Y-m-d H:i:s');
             $result=DB::table('tbl_groups')
            ->where('group_id',$groupid)
            ->update($data);
             if( $result){
              $data['success'] = trans('messages.314');
            }
          else{
            $data['danger'] = trans('messages.315');
            }
            return redirect('group')->with($data);  
   }

  



    
}
