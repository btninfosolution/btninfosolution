<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminSourcesController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_sources()
    {
        
        $data['page_title'] = "Source"; 
       $data['sourcelist'] =$this->common_model
      ->get_all('tbl_leads_sources', $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array() , $right = array(), $order = array(array('sources_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.sources.sources_view')->with($data);
    }
    public function add_sources(Request $request){
        $data=array(
            'page_title'=>'Add Sources',
        );
        return view('admin.sources.add_sources')->with($data);
    }
    public function save_sources(Request $request)

       {
	
            $rules = array(
                'sources_name' => 'required|unique:tbl_leads_sources,sources_name,NULL,sources_id,is_deleted,0',
              );
            $this->validate($request, $rules);
            $save_data['sources_name'] =  $request->input('sources_name');
			$save_data['created_at'] = date('Y-m-d H:i:s');
           $result = $this->common_model->insert_data_get_id($table = "tbl_leads_sources", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.373');
             }
              else{
            $data['error'] = trans('messages.374');
             }
        return redirect('sources')->with($data);
     }
    
    
     public function sources_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('tbl_leads_sources')->where('sources_id', $data)->first();
       return view('admin.sources.sources_edit')->with($postdata);
    }
    public function update_source( Request $request){
        $taxid=$request->id;
        
            $rules = array(
            'sources_name' => 'required|unique:tbl_leads_sources,sources_name,'.$taxid.',sources_id,is_deleted,0',
            );
            $this->validate($request, $rules);
           
             $postData = $request->all();
             $priceid=$request->id;
             $data['sources_name']=$postData["sources_name"];
			
             $data['updated_at']=date('Y-m-d H:i:s');
             $result=DB::table('tbl_leads_sources')
            ->where('sources_id',$taxid)
            ->update($data);
             if( $result){
              $data['success'] = trans('messages.375');
            }
          else{
            $data['danger'] = trans('messages.376');
            }
            return redirect('sources')->with($data);  
   }

  



    
}
