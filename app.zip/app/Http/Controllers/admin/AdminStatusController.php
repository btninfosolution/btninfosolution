<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminStatusController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_status()
    {
        
        $data['page_title'] = "Group"; 
       $data['taglist'] =$this->common_model
      ->get_all('tbl_leads_status', $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array() , $right = array(), $order = array(array('status_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.status.status_view')->with($data);
    }
    public function add_status(Request $request){
        $data=array(
            'page_title'=>'Add Status',
        );
        return view('admin.status.add_status')->with($data);
    }
    public function save_status(Request $request)

       {
	
            $rules = array(
                'status_name' => 'required|unique:tbl_leads_status,status_name,NULL,status_id,is_deleted,0',
              );
            $this->validate($request, $rules);
            $save_data['status_name'] =  $request->input('status_name');
            $save_data['created_at'] = date('Y-m-d H:i:s');
           $result = $this->common_model->insert_data_get_id($table = "tbl_leads_status", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.368');
             }
              else{
            $data['error'] = trans('messages.369');
             }
        return redirect('status')->with($data);
     }
    
    
     public function status_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('tbl_leads_status')->where('status_id', $data)->first();
       return view('admin.status.status_edit')->with($postdata);
    }
    public function update_status( Request $request){
        $tagid=$request->id;
        
            $rules = array(
            'status_name' => 'required|unique:tbl_leads_status,status_name,'.$tagid.',status_id,is_deleted,0',
            );
            $this->validate($request, $rules);
           
             $postData = $request->all();
             $priceid=$request->id;
             $data['status_name']=$postData["status_name"];
             $data['updated_at']=date('Y-m-d H:i:s');
             $result=DB::table('tbl_leads_status')
            ->where('status_id',$tagid)
            ->update($data);
             if( $result){
              $data['success'] = trans('messages.370');
            }
          else{
            $data['danger'] = trans('messages.371');
            }
            return redirect('status')->with($data);  
   }

  



    
}
