<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class CommonController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }
    public function delete_record(Request $request)
    {
        $status_data = $request->status_data;
        $params = Crypt::decrypt($status_data); 
        // echo $params; die();
        $explodedata=explode('&', $params);
        $id = $explodedata[0];
        $table = $explodedata[1];
        $field = $explodedata[2];
        $isdeleted = $explodedata[3];
        $redirect_url = $explodedata[4];
        $delete_type = $explodedata[5];
       // print_r($redirect_url);die;
        if($id && $table && $field)
        { 
            try {
                switch ($table) {
                    case 'tbl_groups':
                        $check_data = false;
                        $msg = 'Group Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_items':
                        $check_data = false;
                        $msg = 'Items Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_expense_catogory':
                        $check_data = false;
                        $msg = 'Expense Category Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_contractm':
                        $check_data = false;
                        $msg = 'Contract Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_expense':
                        $check_data = false;
                        $msg = 'Expenses Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_leads_sources':
                        $check_data = false;
                        $msg = 'Leads Sources Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_leads_status':
                        $check_data = false;
                        $msg = 'Leads Status Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_contract':
                        $check_data = false;
                        $msg = 'Contract Type Status Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_task':
                        $check_data = false;
                        $msg = 'Task  Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_leads':
                        $check_data = false;
                        $msg = 'Lead  Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;

                        case 'tbl_school_list':
                        $check_data = false;
                        $msg = 'School Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_client_contacts':
                        $check_data = false;
                        $msg = 'Contact Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        case 'tbl_plan':
                        $check_data = false;
                        $msg = 'Plan Successfully deleted.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $msg = '';
                            }
                        }
                        break;
                        
                        case 'tbl_countries':
                        $check_data = \DB::select("select count(*) as chk From tbl_states Where country_id = ? AND is_deleted = '0' ",[$id]);
                       // $check_data = false;
                        $msg = 'You have a state associated with this country. Please delete that first.';
                        if($check_data)
                        {
                            if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                            {
                                $data['danger'] = $msg;
                                return redirect(url($redirect_url))->with($data);
                            }else{
                                $msg = 'Country Successfully deleted.';
                            }
                        }
                        
                        break;

                     default:
                        $msg = '';
                    break;
                }


                //type wise operation
                if($delete_type )
                {
                    $delete = $this->common_model->delete_data($table, array(array($field, '=', $id)));
                    if($delete)
                    {
                        //redirect
                        $data['success'] = $msg;
                    }
                    else
                    {
                        //redirect
                        $data['danger'] = "something wrong.try again later.";
                    }
                }
                else
                {
                    
                    $save_data['is_deleted'] = 1;
                    $save_data['updated_at'] = date('Y-m-d H:i:s');
                    $delete = $this->common_model->update_data($table, array(array($field, '=', $id)), $data = $save_data);
                    if($delete)
                    {
                        //redirect
                        
                        $data['success'] = $msg;
                    }
                    else
                    {
                        //redirect
                        $data['danger'] = "something wrong.try again later.";
                    }
                }

                return redirect(url($redirect_url))->with($data);
            
                
            } catch (\Exception $e) {
                return response()->json(['message'=>'Process Failed','data' => '','status' => false],400);
            }   
            
        }
    }

    public function change_status(Request $request)
    {
               $status_data = $request->status_data;
               $params = Crypt::decrypt($status_data); 
               $explodedata=explode('&', $params);
               $ide=$explodedata[0];
               $tbl=$explodedata[1];
               $fld=$explodedata[2];
               $isblck=$explodedata[3];
               $rurl=$explodedata[4];
               $idexplode=explode('=',$ide);
               $tblexplode=explode('=',$tbl);
               $fldexplode=explode('=',$fld);
               $isblocked=explode('=',$isblck);
               $redurl=explode('=',$rurl);
               $id=$idexplode[1];
               $table=$tblexplode[1];
               $field=$fldexplode[1];
               $is_blocked=$isblocked[1];
               $redirect_url=$redurl[1];
               $table = $table;
               $field = $field;
        if($id && $table && $field)
        {
             if($table =='tbl_countries'){
            $check_data = \DB::select("select count(*) as chk From tbl_states Where country_id = ? AND is_deleted = '0' ",[$id]);
            //print_r( $check_data);die;
          //  $check_data = true;
            $msg = 'Sorry you can not change this status.This country is having sates';
            if($check_data)
            {
                if(isset($check_data[0]->chk) && $check_data[0]->chk > 0)
                {
                    $data['danger'] = $msg;
                    return redirect(url($redirect_url))->with($data);
                }else{
                    $msg = 'Status changed successfully';
                }
            }
        }
            $save_data['is_blocked'] = $is_blocked==1 ? 0 : 1;
            $save_data['updated_at'] = date('Y-m-d H:i:s');
            $status = $this->common_model->update_data($table, array(array($field, '=', $id)), $data = $save_data);
            
        }
        
        $data['success']="Status changed successfully";
        return redirect($redirect_url)->with($data);
    }
  
  
}
