<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminDashboardController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_dashboard()
    {
        
        $data['page_title'] = "Dashboard";
        $check_data = \DB::select("select count(*) as user From users Where is_deleted = '0' ");
        $data['users']=$check_data[0]->user;
        $check_lead_data = \DB::select("select count(*) as user From tbl_leads Where is_blocked = 0 AND is_deleted = '0' ");
        $data['lead']=$check_lead_data[0]->user; 
        $check_task_data = \DB::select("select count(*) as user From tbl_task Where is_blocked = 0 AND is_deleted = '0' ");
        $data['task']=$check_task_data[0]->user; 
        $check_invoice_data = \DB::select("select count(*) as user From tbl_invoices Where is_invoice = 1 ");
        $data['invoice']=$check_invoice_data[0]->user; 
        
        return view('admin.dashboard')->with($data);
    }
    
    
    
    /******** Products data import *********/
}
