<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminTaskController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_task(Request $request)
    {        
        $data['page_title'] = "Task"; 

        $not_started_data = \DB::select("select count(*) as user From tbl_task Where is_deleted = '0' AND task_status = 1");
        $data['not_started']=$not_started_data[0]->user;
        $in_progress_data = \DB::select("select count(*) as user From tbl_task Where is_deleted = '0' AND task_status = 2 ");
        $data['in_progress']=$in_progress_data[0]->user;
        $complete_data = \DB::select("select count(*) as user From tbl_task Where is_deleted = '0' AND task_status = 3 ");
        $data['complete']=$complete_data[0]->user;
        $testing_data = \DB::select("select count(*) as user From tbl_task Where is_deleted = '0' AND task_status = '4' ");
        $data['testing']=$testing_data[0]->user;
        
       
      $sql="SELECT *, s.tag_name,c.first_name,c.last_name 
               FROM tbl_task as ur
      LEFT JOIN tbl_tags as s ON ur.tag_id = s.tag_id
      LEFT JOIN tbl_staff as c ON ur.staff_id = c.staff_id
      WHERE ur.is_deleted=0
      ";
       if($request->staff_name )
       { 
          $sql = $sql .' AND ur.staff_id = "'.$request->staff_name.'"';
       }
       if($request->status )
       { 
          $sql = $sql .' AND task_status = "'.$request->status.'"';
       }
       if($request->to_date )
       { 
          $sql = $sql .' AND start_date = "'.$request->to_date.'"';
       }
       if($request->due_date )
       { 
          $sql = $sql .' AND due_date = "'.$request->due_date.'"';
       }
       
       
       
   //   echo $request->to_date;die;
      
        $tasklist =DB::select($sql.' '.'ORDER BY task_id DESC');
      $data['stafflist'] =$this->common_model
      ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_type', '=', 2)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['addpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_add', '=', 0),array('left_menu_title', '=', 6)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['editpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_edit', '=', 0),array('left_menu_title', '=', 6)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['deletepermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('delete_permisson', '=', 0),array('left_menu_title', '=', 6)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['globalpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('global_view', '=', 1),array('left_menu_title', '=', 6)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['ownpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('own_view', '=', 1),array('left_menu_title', '=', 6)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      if(!empty($data['globalpermission'])){
        $data['tasklist'] =$tasklist;
      }
      if(session('user_type') ==1){
        $data['tasklist'] =$tasklist;
      }
       if(!empty($data['ownpermission'])){
        
        $left1 = array(
          array('tbl_tags AS d','a.tag_id','=','d.tag_id'),
          array('tbl_staff AS e','a.staff_id','=','e.staff_id'),
       ); 
        $data['tasklist'] = $this->common_model
        ->get_all('tbl_task AS a', $select = array('a.*','d.tag_name as tag_name', 'e.first_name as first_name', 'e.last_name as last_name'), $where = array(array('a.is_deleted', '=', 0),array('a.staff_id', '=', session('id'))), $join = array(), $left1 , $right = array(), $order = array(array('a.task_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      }
      
        return view('admin.task.task_view')->with($data);
    }
    public function add_task(Request $request){
       // echo "ddd";die;
        $data=array(
            'page_title'=>'Add Task',
        );
        $data['stafflist'] =$this->common_model
        ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_type', '=', 2)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
     $data['taglist'] =$this->common_model
     ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0,)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.task.add_task')->with($data);
    }
    public function save_task(Request $request)

       {  //  echo "Ddd";die;
            $rules = array(
                'subject' => 'required',
                'start_date' => 'required'
              );
            $this->validate($request, $rules); 
            $save_data['subject'] =  $request->input('subject');
            $save_data['hourly_rate'] =  $request->input('hourly_rate');
            $save_data['start_date'] =  $request->input('start_date');
            $save_data['due_date'] =  $request->input('due_date');
            $save_data['priority'] =  $request->input('priority');
            $save_data['related_to'] =  $request->input('related_to');
            $save_data['repeat_every'] =  $request->input('repeat_every');
            $save_data['staff_id'] =  $request->input('staff_id');
            $save_data['tag_id'] =  $request->input('tag_id');
            $save_data['description'] =  $request->input('description');
            $save_data['task_status'] =  $request->input('status') ? $request->input('status') : 1;
            $save_data['created_at'] = date('Y-m-d H:i:s');
            //print_r($save_data);die;
            $result = $this->common_model->insert_data_get_id($table = "tbl_task", $data1 = $save_data);
            $save_data1['module_name'] = 'Task';
            $save_data1['created_by'] =  session('id');
            $save_data1['created_id'] =  $result;
            $save_data1['created_at'] = date('Y-m-d H:i:s');
            //print_r($save_data);die;
            $result1 = $this->common_model->insert_data_get_id($table = "tbl_logs", $data1 = $save_data1);
            if( $result){
              $stafflist =$this->common_model
              ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('staff_id', '=', $request->input('staff_id'))), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
               $staff=$stafflist[0];
              $staff_email=$staff->email;
               $staff_name=$staff->first_name;
               $emailData['subject'] = $request->input('subject');
               $emailData['start_date'] = $request->input('start_date');
               $emailData['name'] =  $staff_name;
            
             try{
               Mail::send('email.task_assign',$emailData,function($message) use($staff_email)
               {
                   $message->from('btncrm@gmail.com', 'CRM');
                   $message->subject('Task Assign');
                   $message->to($staff_email);
                 
               });
               $data['success'] = trans('messages.704');
           }
           catch(\Exception $e){
              // dd($e);die;
              $data['danger'] = trans('messages.705');
           }
             }
              else{
            $data['danger'] = trans('messages.705');
             }
        return redirect('task')->with($data);
     }
    
    
     public function task_edit($id){
       try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
        $postdata['Editdata'] = DB::table('tbl_task')->where('task_id', $data)->first();
        $postdata['taglist'] =$this->common_model
     ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
     $postdata['stafflist'] =$this->common_model
     ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_type', '=', 2)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
       // print_r($postdata['Editdata']);die;
        return view('admin.task.task_edit')->with($postdata);
    }
    public function update_task( Request $request){
        $task_id=$request->id;       
        $postData = $request->all();
        $rules = array(
                'subject' => 'required',
                'start_date' => 'required'
              );
        $this->validate($request, $rules); 
        $save_data['subject'] =  $request->input('subject');
        $save_data['hourly_rate'] =  $request->input('hourly_rate');
        $save_data['start_date'] =  $request->input('start_date');
        $save_data['due_date'] =  $request->input('due_date');
        $save_data['priority'] =  $request->input('priority');
        $save_data['related_to'] =  $request->input('related_to');
        $save_data['repeat_every'] =  $request->input('repeat_every');
        $save_data['staff_id'] =  $request->input('staff_id');
        $save_data['tag_id'] =  $request->input('tag_id');
        $save_data['description'] =  $request->input('description');
        $save_data['task_status'] =  $request->input('status') ? $request->input('status') : 1;
        $save_data['updated_at']=date('Y-m-d H:i:s');
        $result=DB::table('tbl_task')
        ->where('task_id',$task_id)
        ->update($save_data);
         if( $result){
          $loglist =$this->common_model
          ->get_all($table = "tbl_logs", $select = array('*'), $where = array(array('created_id', '=',  $task_id)), $join = array(), $left = array(), $right = array(), $order = array(array('logs_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        if(!empty( $loglist)){
          $save_data1['updated_by'] =  session('id');
          $save_data1['updated_at']=date('Y-m-d H:i:s');
          $result=DB::table('tbl_logs')
          ->where('created_id',$task_id)
          ->update($save_data1);

        }
          $data['success'] = trans('messages.706');
        }
      else{
        $data['danger'] = trans('messages.707');
        }
        return redirect('task')->with($data);  
   }

  



    
}
