<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminTaxController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_tax()
    {
        
        $data['page_title'] = "Tax"; 
       $data['taxlist'] =$this->common_model
      ->get_all('tbl_tax', $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array() , $right = array(), $order = array(array('tax_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.tax.tax_view')->with($data);
    }
    public function add_tax(Request $request){
        $data=array(
            'page_title'=>'Add Tax',
        );
        return view('admin.tax.add_tax')->with($data);
    }
    public function save_tax(Request $request)

       {
	
            $rules = array(
                'tax_name' => 'required|unique:tbl_tax,tax_name,NULL,tax_id,is_deleted,0',
              );
            $this->validate($request, $rules);
            $save_data['tax_name'] =  $request->input('tax_name');
			 $save_data['tax_rate'] =  $request->input('tax_rate');
            $save_data['created_at'] = date('Y-m-d H:i:s');
           $result = $this->common_model->insert_data_get_id($table = "tbl_tax", $data1 = $save_data);
            if( $result){
            $data['success'] = trans('messages.347');
             }
              else{
            $data['error'] = trans('messages.348');
             }
        return redirect('tax')->with($data);
     }
    
    
     public function tax_edit($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('tbl_tax')->where('tax_id', $data)->first();
       return view('admin.tax.tax_edit')->with($postdata);
    }
    public function update_tax( Request $request){
        $taxid=$request->id;
        
            $rules = array(
            'tax_name' => 'required|unique:tbl_tax,tax_name,'.$taxid.',tax_id,is_deleted,0',
            );
            $this->validate($request, $rules);
           
             $postData = $request->all();
             $priceid=$request->id;
             $data['tax_name']=$postData["tax_name"];
			 $data['tax_rate']=$postData["tax_rate"];
             $data['updated_at']=date('Y-m-d H:i:s');
             $result=DB::table('tbl_tax')
            ->where('tax_id',$taxid)
            ->update($data);
             if( $result){
              $data['success'] = trans('messages.349');
            }
          else{
            $data['danger'] = trans('messages.350');
            }
            return redirect('tax')->with($data);  
   }

  



    
}
