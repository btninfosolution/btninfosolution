<?php

namespace App\Http\Controllers\admin;
//require_once ("./app/excel/Classes/PHPExcel.php");

use Validator;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\model\common_model;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Response;

use Session;
use Mail;
use DB;
use Excel;



class AdminMasterController extends Controller
{
    public function __construct(){
        $this->common_model = new common_model();
    }

  
    
    public function admin_customer()
    {
        
        $data['page_title'] = "Customer";
        $check_data = \DB::select("select count(*) as user From users Where is_deleted = '0' ");
        $data['users']=$check_data[0]->user;
        $check_active_data = \DB::select("select count(*) as user From users Where is_blocked = 0 AND is_deleted = '0' ");
        $data['active_users']=$check_active_data[0]->user; 
        $check_inactive_data = \DB::select("select count(*) as user From users Where is_blocked = 1 AND is_deleted = '0' ");
        $data['inactive_users']=$check_inactive_data[0]->user; 

        $left = array(
            array('tbl_groups AS b','a.group_id','=','b.group_id'),
      ); 
      $customerlist =$this->common_model
      ->get_all('users AS a', $select = array('a.*', 'b.group_name as group_name'), $where = array(array('a.is_deleted', '=', 0)), $join = array(), $left , $right = array(), $order = array(array('a.id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['addpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_add', '=', 0),array('left_menu_title', '=', 2)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['editpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('is_edit', '=', 0),array('left_menu_title', '=', 2)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['deletepermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('delete_permisson', '=', 0),array('left_menu_title', '=', 2)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      $data['globalpermission'] =$this->common_model
      ->get_all($table = "tbl_staff_permission", $select = array('*'), $where = array(array('staff_id', '=', session('id')),array('global_view', '=', 0),array('left_menu_title', '=', 2)), $join = array(), $left = array(), $right = array(), $order = array(array('permission_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
      if(!empty($data['globalpermission'])){
        $data['customerlist'] ="";
      }else{
        $data['customerlist'] = $customerlist;
      }
        return view('admin.customer.customer_view')->with($data);
    }
    public function add_customer(Request $request){
        $data=array(
            'page_title'=>'Add Customer',
        );
        $data['grouplist'] =$this->common_model
     ->get_all($table = "tbl_groups", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('group_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
     $data['countrylist'] =$this->common_model
     ->get_all($table = "tbl_countries", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('country_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        return view('admin.customer.add_customer')->with($data);
    }
    public function save_customer(Request $request)

       {
            $rules = array(
                'phone' => 'required|unique:users,phone,NULL,id,is_deleted,0',
                'client_name' => 'required',
              );
            $this->validate($request, $rules);
            $save_data['phone'] =  $request->input('phone');
            $save_data['client_name'] =  $request->input('client_name');
            $save_data['company_name'] =  $request->input('company_name');
            $save_data['gst_no'] =  $request->input('gst');
           // $save_data['group_id'] =  $request->input('group');
            $save_data['country_id'] =  $request->input('country');
            $save_data['state'] =  $request->input('state');
            $save_data['city'] =  $request->input('city');
            $save_data['website'] =  $request->input('website');
            $save_data['address'] =  $request->input('address');
            $save_data['billing_city'] =  $request->input('billing_city');
            $save_data['billing_state'] =  $request->input('billing_state');
            $save_data['billing_country_id'] =  $request->input('bill_country');
            $save_data['billing_zip'] =  $request->input('bill_zip');
            $save_data['billing_address'] =  $request->input('bill_address');
            $save_data['user_type'] = 2;
            $save_data['created_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
           $result = $this->common_model->insert_data_get_id($table = "users", $data1 = $save_data);
           $last_id=DB::getPdo()->lastInsertId();
           $category = implode(',', $request->group);
            $category_array = explode(',', $category);
            $counter = 0;
            foreach ($category_array as $key => $value)
            {
                $category_data = array();
                $category_data = array(
                    'group_id' => $value,
                    'customer_id' => $last_id,
                    'is_blocked' => 0,
                    'created_at' => date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes')),
                );

                $insert_id = $this->common_model->insert_data_get_id($table = "tbl_customer_groups", $data = $category_data);
                $counter++;
            }
            if( $result){
            $data['success'] = trans('messages.307');
             }
              else{
            $data['error'] = trans('messages.308');
             }
        return redirect('customer')->with($data);
     }
    
    
     public function customer_detail($id){
        try{
            $data = Crypt::decrypt($id); 
        }
            catch(\Exception $e){
                return redirect()->back()->withErrors(['Error', 'The Id not exist']);
            }
       
       $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
       $postdata['grouplist'] =$this->common_model
       ->get_all($table = "tbl_groups", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('group_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
       $postdata['countrylist'] =$this->common_model
       ->get_all($table = "tbl_countries", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('country_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
       $postdata['enc_type']=$id;
       $select_category = $this->common_model->get_all($table = "tbl_customer_groups", $select = array('*'), $where = array(array('customer_id', '=', $data)), $join = array(), $left = array(), $right = array(), $order = array(array('customer_group_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
        if(!empty( $select_category)){
            foreach($select_category as $group){
             $selected_group_id[]=$group->group_id;
            }
            $selectedgymlist =  DB::table('tbl_groups')
         ->whereIn('group_id',$selected_group_id)->where('is_deleted','0'  )->where('is_blocked','0'  )->get();
         //print_r($selectedgymlist);die;
         $postdata['selected_category'] =$selectedgymlist;
            }else{
                $postdata['selected_category'] ="";
            }
       return view('admin.customer.customer_detail')->with($postdata);
    }
    public function update_customer( Request $request){
        $userid=$request->id;
        $url=$request->enc_type;
        
            $rules = array(
            'phone' => 'required|unique:users,phone,'.$userid.',id,is_deleted,0',
            'client_name' => 'required',
            );
            $this->validate($request, $rules);
           
             $postData = $request->all();
             $priceid=$request->id;
             $data['company_name']=$postData["company_name"];
             $data['client_name']=$postData["client_name"];
             $data['phone']=$postData["phone"];
             $data['gst_no']=$postData["gst"];
            // $data['group_id']=$postData["group"];
             $data['country_id']=$postData["country"];
             $data['state']=$postData["state"];
             $data['city']=$postData["city"];
             $data['website']=$postData["website"];
             $data['address']=$postData["address"];
             $data['billing_city']=$postData["billing_city"];
             $data['billing_state']=$postData["billing_state"];
             $data['billing_country_id']=$postData["bill_country"];
             $data['billing_zip']=$postData["bill_zip"];
             $data['billing_address']=$postData["bill_address"];
             $data['updated_at']= date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
            // print_r($data);die;
             $result=DB::table('users')
            ->where('id',$userid)
            ->update($data);
            DB::table('tbl_customer_groups')
           ->where('customer_id', $userid)
           ->delete();
            $category = implode(',', $request->group);
            $category_array = explode(',', $category);
            $counter = 0;
            if(!empty($category_array)){
            foreach ($category_array as $key => $value)
            {
                $category_data = array();
                $category_data = array(
                    'group_id' => $value,
                    'customer_id' => $userid,
                    'is_blocked' => 0,
                    'created_at' => date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes')),
                );

                $insert_id = $this->common_model->insert_data_get_id($table = "tbl_customer_groups", $data = $category_data);
                $counter++;
            }
        }
           // print_r($result);die;
             if( $result){
              $data['success'] = trans('messages.309');
            }
          else{
            $data['danger'] = trans('messages.310');
            }
              return redirect('/customer-detail'.'/'.$url)->with($data);  
   }

   public function customer_contact_detail($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   
   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   $postdata['contactlist'] =$this->common_model
   ->get_all($table = "tbl_client_contacts", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_id', '=', $data)), $join = array(), $left = array(), $right = array(), $order = array(array('contact_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['countrylist'] =$this->common_model
   ->get_all($table = "tbl_countries", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('country_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['enc_type']=$id;
   return view('admin.customer.contact_detail')->with($postdata);
}

  
public function change_password_admin(){
    $id=session('id');
   $postdata['Editdata'] = DB::table('tbl_staff')->where('staff_id', $id)->first();
    return view('admin.changepassword')->with($postdata);
}
   public function update_adminpassword( Request $request){
        
    $rules = array(
    'newpassword' => 'required',
    );
    $this->validate($request, $rules);
   
     $postData = $request->all();
     $id=$request->id;
     $data['password']=md5($postData["newpassword"]);
     $data['updated_at']= date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
     $result=DB::table('tbl_staff')
    ->where('staff_id',$id)
    ->update($data);
     if( $result){
      $data['success'] = trans('messages.321');
    }
  else{
       $data['danger'] = trans('messages.322');
    }
      return redirect('changepassword')->with($data);  
      
}

public function add_customer_contact($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   $postdata['enc_type']=$id;

   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   return view('admin.customer.contact_add')->with($postdata);
}
public function image_upload($image_file){
    $image = $image_file;
    $name = time().'.'.$image->getClientOriginalExtension();
    $destinationPath = public_path('/uploads/contact_image');
    $image->move($destinationPath, $name);
    $img_path = $name;
    return $img_path;

}

public function save_customer_contact(Request $request)

{
     $rules = array(
         'phone' => 'unique:tbl_client_contacts,phone,NULL,contact_id,is_deleted,0',
         'email' => 'required|unique:tbl_client_contacts,email,NULL,contact_id,is_deleted,0',
         'first_name' => 'required',
         'last_name' => 'required',
       );
     $this->validate($request, $rules);
     $url=$request->enc_type;
     $save_data['phone'] =  $request->input('phone');
     $save_data['first_name'] =  $request->input('first_name');
     $save_data['last_name'] =  $request->input('last_name');
     $save_data['email'] =  $request->input('email');
     $save_data['user_id'] =  $request->input('id');
     if ($request->hasFile('profile_image')) {
        $image = $request->file('profile_image');
       $img_path = $this->image_upload($image);   
       $save_data['profile_image'] = $img_path;            
    }
     $save_data['created_at'] = date('Y-m-d H:i:s');
    $result = $this->common_model->insert_data_get_id($table = "tbl_client_contacts", $data1 = $save_data);
     if( $result){
     $data['success'] = trans('messages.326');
      }
       else{
     $data['error'] = trans('messages.327');
      }
      return redirect('/contact-detail'.'/'.$url)->with($data); 
}

public function customer_contact_edit($id,$url){
    try{
        $data = Crypt::decrypt($id); 
        $userid = Crypt::decrypt($url); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   
   $postdata['Editdata'] = DB::table('users')->where('id', $userid)->first();
   $postdata['Editcondata'] = DB::table('tbl_client_contacts')->where('contact_id', $data)->first();
   $postdata['enc_type']=$url;
   return view('admin.customer.contact_edit')->with($postdata);
}
public function update_customer_contact( Request $request){
    $userid=$request->id;
    $url=$request->enc_type;
    
        $rules = array(
        'phone' => 'required|unique:tbl_client_contacts,phone,'.$userid.',contact_id,is_deleted,0',
        'email' => 'required|unique:tbl_client_contacts,email,'.$userid.',contact_id,is_deleted,0',
        'first_name' => 'required',
         'last_name' => 'required',
        );
        $this->validate($request, $rules);
       
         $postData = $request->all();
         $priceid=$request->id;
         $data['first_name']=$postData["first_name"];
         $data['last_name']=$postData["last_name"];
         $data['phone']=$postData["phone"];
         $data['email']=$postData["email"];
         if ($request->hasFile('profile_image')) {
            $image = $request->file('profile_image');
           $img_path = $this->image_upload($image);   
           $data['profile_image'] = $img_path;            
        }
         $data['updated_at']= date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
         $result=DB::table('tbl_client_contacts')
        ->where('contact_id',$userid)
        ->update($data);
         if( $result){
          $data['success'] = trans('messages.328');
        }
      else{
        $data['danger'] = trans('messages.329');
        }
          return redirect('/contact-detail'.'/'.$url)->with($data);  
}
   public function delete_contact(Request $request ) {
     $id=$request->id;
        DB::table('tbl_client_contacts')
        ->where('contact_id', $id)
        ->delete();
        $data['success'] = trans('messages.330');
       return redirect()->back()->with($data);
    
  }

  public function customer_note_detail($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   
   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   $postdata['notelist'] =$this->common_model
   ->get_all($table = "tbl_notes", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_id', '=', $data)), $join = array(), $left = array(), $right = array(), $order = array(array('note_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['enc_type']=$id;
   return view('admin.customer.note_detail')->with($postdata);
}

public function save_customer_note(Request $request)

{
     $rules = array(
         'description' => 'required',
       );
     $this->validate($request, $rules);
     $url=$request->enc_type;
     $save_data['description'] =  $request->input('description');
     $save_data['user_id'] =  $request->input('id');
     $save_data['created_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
    $result = $this->common_model->insert_data_get_id($table = "tbl_notes", $data1 = $save_data);
     if( $result){
     $data['success'] = trans('messages.332');
      }
       else{
     $data['error'] = trans('messages.333');
      }
      return redirect('/note-detail'.'/'.$url)->with($data); 
}

public function delete_note(Request $request ) {
    $id=$request->id;
       DB::table('tbl_notes')
       ->where('note_id', $id)
       ->delete();
       $data['success'] = trans('messages.334');
      return redirect()->back()->with($data);
   
 }

 public function customer_invoice_detail($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   
   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   $postdata['contactlist'] =$this->common_model
   ->get_all($table = "tbl_client_contacts", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_id', '=', $data)), $join = array(), $left = array(), $right = array(), $order = array(array('contact_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['countrylist'] =$this->common_model
   ->get_all($table = "tbl_countries", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('country_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['invoicelist'] =$this->common_model
   ->get_all($table = "tbl_invoices", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('customer_id', '=', $data),array('is_invoice', '=', 1)), $join = array(), $left = array(), $right = array(), $order = array(array('invoice_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['enc_type']=$id;
   return view('admin.customer.invoice_detail')->with($postdata);
}

public function add_customer_invoice($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   $postdata['enc_type']=$id;

   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   $postdata['taglist'] =$this->common_model
   ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['stafflist'] =$this->common_model
   ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['itemlist'] =$this->common_model
   ->get_all($table = "tbl_items", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('item_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   return view('admin.customer.invoice_add')->with($postdata);
}

public function save_customer_invoice(Request $request)

{
     $rules = array(
         'start' => 'required',
       );
     $this->validate($request, $rules);
     $url=$request->enc_type;
    // $fetaure = implode(',', $request->item_name);
    // print_r($fetaure);die;
     $save_data['tag_id'] =  $request->input('tag');
     $save_data['payment_type'] =  !empty($request->input('payment')) ?  $request->input('payment') : '';
     $save_data['agent_id'] =  !empty($request->input('agent')) ?  $request->input('agent') : 0;
     $save_data['recuring_invoice'] =  $request->input('recruit');
     $save_data['discount_type'] =  $request->input('dis_type');
     $save_data['admin_note'] =  $request->input('adminnote');
     $save_data['discount_percent'] =  $request->input('discount');
     $save_data['sub_total'] =  $request->input('sub_total');
     $save_data['discount'] =  $request->input('discount_total');
     $save_data['total_amount'] =  $request->input('overall_discount');
     $save_data['client_note'] =  $request->input('clientnote');
     $save_data['terms_condition'] =  $request->input('terms');
     $save_data['invoice_date'] =  $request->input('start');
     $save_data['due_date'] =  $request->input('expiry');
     $save_data['customer_id'] =  $request->input('id');
     $save_data['lead_id'] =  0;
     $otp=rand(10000,99999);
     $save_data['invoice_number'] = 'CRM'.'-'.$otp;
     $save_data['created_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
     
    $result = $this->common_model->insert_data_get_id($table = "tbl_invoices", $data1 = $save_data);
    $last_id=DB::getPdo()->lastInsertId();
    //print_r($last_id);die;
    $item_name = implode(',', $request->item_name);
    $item_description = implode(',', $request->long_description);
    $quantity = implode(',', $request->quantity);
    $item_rate = implode(',', $request->item_rate);
    $name_array = explode(',', $item_name);
    $description_array = explode(',', $item_description);
    $quantity_array = explode(',', $quantity);
    $rate_array = explode(',', $item_rate);
    $counter = 0;
    if(!empty($name_array)){
    foreach ($name_array as $key => $value)
    {
        $category_data = array();
        $category_data = array(
            'item_name' => $value,
            'item_description' => $description_array[$key],
            'invoice_id' => $last_id,
            "quantity" => $quantity_array[$key],
            "item_rate" => $rate_array[$key],
            'is_blocked' => 0,
            'created_at' =>  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes')),
        );
        

        $insert_id = $this->common_model->insert_data_get_id($table = "tbl_invoice_items", $data = $category_data);
        $counter++;
    }
  }
    
     if( $result){
     $data['success'] = trans('messages.351');
      }
       else{
     $data['danger'] = trans('messages.352');
      }
      return redirect('/invoice-detail'.'/'.$url)->with($data); 
}

public function save_customer_proposal(Request $request)

{
     $rules = array(
         'start' => 'required',
       );
     $this->validate($request, $rules);
     $url=$request->enc_type;
    // $fetaure = implode(',', $request->item_name);
    // print_r($fetaure);die;
     $save_data['tag_id'] =  $request->input('tag');
     $save_data['payment_type'] =  !empty($request->input('payment')) ?  $request->input('payment') : '';
     $save_data['agent_id'] =  !empty($request->input('agent')) ?  $request->input('agent') : 0;
     $save_data['recuring_invoice'] =  $request->input('recruit');
     $save_data['discount_type'] =  $request->input('dis_type');
     $save_data['admin_note'] =  $request->input('adminnote');
     $save_data['discount_percent'] =  $request->input('discount');
     $save_data['sub_total'] =  $request->input('sub_total');
     $save_data['discount'] =  $request->input('discount_total');
     $save_data['total_amount'] =  $request->input('overall_discount');
     $save_data['client_note'] =  $request->input('clientnote');
     $save_data['terms_condition'] =  $request->input('terms');
     $save_data['invoice_date'] =  $request->input('start');
     $save_data['due_date'] =  $request->input('expiry');
     $save_data['customer_id'] =  $request->input('id');
     $save_data['is_invoice'] =  2;
     $save_data['lead_id'] =  0;
     $otp=rand(10000,99999);
     $save_data['invoice_number'] = 'CRM'.'-'.$otp;
     $save_data['created_at'] =  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes'));
     
    $result = $this->common_model->insert_data_get_id($table = "tbl_invoices", $data1 = $save_data);
    $last_id=DB::getPdo()->lastInsertId();
    //print_r($last_id);die;
    $item_name = implode(',', $request->item_name);
    $item_description = implode(',', $request->long_description);
    $quantity = implode(',', $request->quantity);
    $item_rate = implode(',', $request->item_rate);
    $name_array = explode(',', $item_name);
    $description_array = explode(',', $item_description);
    $quantity_array = explode(',', $quantity);
    $rate_array = explode(',', $item_rate);
    $counter = 0;
    if(!empty($name_array)){
    foreach ($name_array as $key => $value)
    {
        $category_data = array();
        $category_data = array(
            'item_name' => $value,
            'item_description' => $description_array[$key],
            'invoice_id' => $last_id,
            "quantity" => $quantity_array[$key],
            "item_rate" => $rate_array[$key],
            'is_blocked' => 0,
            'created_at' =>  date("Y-m-d H:i:s", strtotime('+9 hours +30 minutes')),
        );
        

        $insert_id = $this->common_model->insert_data_get_id($table = "tbl_invoice_items", $data = $category_data);
        $counter++;
    }
  }
    
     if( $result){
     $data['success'] = trans('messages.393');
      }
       else{
     $data['danger'] = trans('messages.394');
      }
      return redirect('/proposal-detail'.'/'.$url)->with($data); 
}


public function customer_proposal_detail($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   
   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   $postdata['contactlist'] =$this->common_model
   ->get_all($table = "tbl_client_contacts", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('user_id', '=', $data)), $join = array(), $left = array(), $right = array(), $order = array(array('contact_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['countrylist'] =$this->common_model
   ->get_all($table = "tbl_countries", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('country_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['invoicelist'] =$this->common_model
   ->get_all($table = "tbl_invoices", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('customer_id', '=', $data),array('is_invoice', '=', 2)), $join = array(), $left = array(), $right = array(), $order = array(array('invoice_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['enc_type']=$id;
   return view('admin.customer.proposal_detail')->with($postdata);
}
public function add_customer_proposal($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   $postdata['enc_type']=$id;

   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   $postdata['taglist'] =$this->common_model
   ->get_all($table = "tbl_tags", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('tag_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['stafflist'] =$this->common_model
   ->get_all($table = "tbl_staff", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   $postdata['itemlist'] =$this->common_model
   ->get_all($table = "tbl_items", $select = array('*'), $where = array(array('is_deleted', '=', 0)), $join = array(), $left = array(), $right = array(), $order = array(array('item_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   return view('admin.customer.proposal_add')->with($postdata);
}


public function getitemData(Request $request)
{
    try {

        

        $result_data = DB::table('tbl_items')->where('item_id', $request->hid)->first();
       // print_r($result_data);die;

        if (empty($result_data)) {
            throw new \Exception(trans('messages.28'));
        }

        return response()->json([
            'result' => true,
            'message' => '',
            'data' => $result_data,
        ]);

        

    }catch (\Exception $e) {
        return response()->json([
            'result' => false,
            'message' => $e->getMessage(),
            'data' => array(),
        ]);
    }
}
public function getitemcalculation(Request $request)
{
   

         $itemquan=$request->quantity;
         $itemprice=$request->price;

       $total = $itemquan * $itemprice;

        echo $total;
}
public function customer_payment_detail($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   
   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   $postdata['invoicelist'] =$this->common_model
   ->get_all($table = "tbl_invoices", $select = array('*'), $where = array(array('is_deleted', '=', 0),array('customer_id', '=', $data),array('total_paid_amount', '>', 0),array('is_invoice', '=', 1)), $join = array(), $left = array(), $right = array(), $order = array(array('invoice_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
   
   $postdata['enc_type']=$id;
   return view('admin.customer.payment_detail')->with($postdata);
}

public function customer_payment_edit($id,$url){
    try{
        $data = Crypt::decrypt($id); 
        $userid = Crypt::decrypt($url); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   
   $postdata['Editdata'] = DB::table('users')->where('id', $userid)->first();
   $postdata['Editcondata'] = DB::table('tbl_invoices')->where('invoice_id', $data)->first();
   $postdata['enc_type']=$url;
   return view('admin.customer.payment_edit')->with($postdata);
}

public function customer_statement_detail($id){
    try{
        $data = Crypt::decrypt($id); 
    }
        catch(\Exception $e){
            return redirect()->back()->withErrors(['Error', 'The Id not exist']);
        }
   
   $postdata['Editdata'] = DB::table('users')->where('id', $data)->first();
   
   $postdata['enc_type']=$id;
   return view('admin.customer.statement_detail')->with($postdata);
}

public function getstatementdetail(Request $request)
{      
        $id = $request->id;
        $start_date = $request->start_date;
        $due_date = $request->due_date;
        $data['start_date']= $start_date;
        $data['due_date']= $due_date;
      //  $data['invoicelist'] =$this->common_model
    //  ->get_all('tbl_invoices', $select = array('*'), $where = array(array('is_deleted', '=', 0),array('customer_id', '=', $id)), $join = array(), $left = array() , $right = array(), $order = array(array('invoice_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");

        $data['total_paid_amount'] =DB::table('tbl_invoices')->where('customer_id', $id )
            ->where('is_blocked', 0 )
            ->where('is_deleted','0'  )
            ->WhereBetween('invoice_date', [$start_date,$due_date])
            ->sum('total_paid_amount');
        $data['total_amount'] =DB::table('tbl_invoices')->where('customer_id', $id )
            ->where('is_blocked', 0 )
            ->where('is_deleted','0'  )
            ->WhereBetween('invoice_date', [$start_date,$due_date])
            ->sum('total_amount');
       $data['invoicelist'] =DB::table('tbl_invoices')
          //  ->select('tbl_invoices.*', 'users.company_name', 'users.billing_city', 'users.billing_city')
            ->leftJoin('users', 'tbl_invoices.customer_id', '=', 'users.id')
            ->where('customer_id', $id )
            ->where('tbl_invoices.is_blocked', '0')
            ->where('tbl_invoices.is_deleted','0'  )
            ->WhereBetween('invoice_date', [$start_date,$due_date])
            ->orderBy('invoice_id','DESC')
            ->get();
     // print_r($data);die;
        return view('admin.customer.statement_detail_table')->with($data);
}

public function log_history(Request $request)
{
   $data['page_title'] = "User";
  // $sql = "SELECT * FROM users WHERE is_deleted = 0"; 
  // $where = array(array('is_deleted', '=', 0));
  $left = array(
     array('users AS c','ur.created_by','=','c.id') ,
     array('users AS c','ur.updated_by','=','c.id') ,
 ); 

 $result = $this->common_model->get_all($table = "tbl_logs as ur", $select = array('ur.*','c.first_name','c.last_name'), $where = array(array('ur.is_deleted', '=',0)), $join = array(), $left , $right = array(), $order = array(array('ur.staff_id'=> 'DESC')), $group = "", $limit = array(), $raw = "", $paging = "");
  
   $data['loglist'] = $result;
   return view('admin.log.log_view')->with($data);
 }




    
}
