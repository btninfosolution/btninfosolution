<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


/*
|-------------------------------------------------------------------------
|API Routes Start
|------------------------------------------------------------------------
*/

/*
|-------------------------------------------------------------------------
|App Default route
|------------------------------------------------------------------------
*/
	Route::any('/', function()
	{
		return "Welcome to ".env('APP_NAME');
	});
/*
|-------------------------------------------------------------------------
|API Master Routes Start with out authentication
|------------------------------------------------------------------------
*/



/*
|-------------------------------------------------------------------------
|Admin Route
|------------------------------------------------------------------------
*/

Route::any('admin-login','admin\AdminLoginController@adminLogin');

Route::any('admin-login-process','admin\AdminLoginController@admin_login_process');
Route::any('reset-password/{link?}','admin\AdminLoginController@reset_password');
//Route::any('reset-password-confirm/{link?}', 'admin\AdminLoginController@reset_password_confirm');
Route::any('resetpassword/{link?}', 'admin\AdminLoginController@reset_password_user');
Route::post('send-reset-password-link', 'admin\AdminLoginController@send_reset_password_link');
Route::post('user-reset-password', 'admin\AdminLoginController@user_reset_password');
Route::any('reset-password-status', 'admin\admin_controller@reset_password_status');
	
		Route::group(['middleware' => 'auth'], function(){

		


			Route::any('change-status','admin\CommonController@change_status');

			Route::any('delete-record','admin\CommonController@delete_record');
	
			Route::any('logout','admin\AdminLoginController@admin_logout');
	
			Route::get('changepassword','admin\AdminMasterController@change_password_admin');
			Route::post('update-adminpassword','admin\AdminMasterController@update_adminpassword');
	
			Route::any('admin-dashboard','admin\AdminDashboardController@admin_dashboard');
			Route::any('event','admin\AdminEventController@admin_event');
			//User route
			
			Route::any('customer','admin\AdminMasterController@admin_customer');
			Route::get('add-customer', 'admin\AdminMasterController@add_customer');
			Route::post("save-customer","admin\AdminMasterController@save_customer");
			Route::get('customer-detail/{id}', 'admin\AdminMasterController@customer_detail');
			Route::post('update-customer', 'admin\AdminMasterController@update_customer');
			Route::get('contact-detail/{id}', 'admin\AdminMasterController@customer_contact_detail');
			Route::get('add-customer-contact/{id}', 'admin\AdminMasterController@add_customer_contact');
			Route::post("save-customer-contact","admin\AdminMasterController@save_customer_contact");
			Route::get('customer-contact-edit/{id}/{url}', 'admin\AdminMasterController@customer_contact_edit');
			Route::post('update-customer-contact', 'admin\AdminMasterController@update_customer_contact');
			Route::get('delete-contact/{id}', 'admin\AdminMasterController@delete_contact');
			Route::get('note-detail/{id}', 'admin\AdminMasterController@customer_note_detail');
			Route::post("save-customer-note","admin\AdminMasterController@save_customer_note");
			Route::get('delete-note/{id}', 'admin\AdminMasterController@delete_note');
			Route::get('invoice-detail/{id}', 'admin\AdminMasterController@customer_invoice_detail');
			Route::get('add-customer-invoice/{id}', 'admin\AdminMasterController@add_customer_invoice');
			Route::post("get-item-detail","admin\AdminMasterController@getitemData");
			Route::post("get-item-calculation","admin\AdminMasterController@getitemcalculation");
			Route::post("save-customer-invoice","admin\AdminMasterController@save_customer_invoice");
			Route::get('payment-detail/{id}', 'admin\AdminMasterController@customer_payment_detail');
			Route::get('customer-payment-edit/{id}/{url}', 'admin\AdminMasterController@customer_payment_edit');
			Route::get('statement-detail/{id}', 'admin\AdminMasterController@customer_statement_detail');
			Route::get("get-statement-detail","admin\AdminMasterController@getstatementdetail");
			Route::get('proposal-detail/{id}', 'admin\AdminMasterController@customer_proposal_detail');
			Route::get('add-customer-proposal/{id}', 'admin\AdminMasterController@add_customer_proposal');
			Route::post("save-customer-proposal","admin\AdminMasterController@save_customer_proposal");
	
			//Group route
			Route::any('group','admin\AdminGroupController@admin_group');
			Route::get('add-group', 'admin\AdminGroupController@add_group');
			Route::post("save-group","admin\AdminGroupController@save_group");
			Route::get('group-edit/{id}', 'admin\AdminGroupController@group_edit');
			Route::post('update-group', 'admin\AdminGroupController@update_group');

			//Items route
			Route::any('item','admin\AdminItemController@admin_item');
			Route::get('add-item', 'admin\AdminItemController@add_item');
			Route::post("save-item","admin\AdminItemController@save_item");
			Route::get('item-edit/{id}', 'admin\AdminItemController@item_edit');
			Route::post('update-item', 'admin\AdminItemController@update_item');
			//Tag route
			Route::any('tags','admin\AdminTagController@admin_tag');
			Route::get('add-tags', 'admin\AdminTagController@add_tags');
			Route::post("save-tags","admin\AdminTagController@save_tags");
			Route::get('tag-edit/{id}', 'admin\AdminTagController@tag_edit');
			Route::post('update-tag', 'admin\AdminTagController@update_tag');
			//Tax route
			Route::any('tax','admin\AdminTaxController@admin_tax');
			Route::get('add-tax', 'admin\AdminTaxController@add_tax');
			Route::post("save-tax","admin\AdminTaxController@save_tax");
			Route::get('tax-edit/{id}', 'admin\AdminTaxController@tax_edit');
			Route::post('update-tax', 'admin\AdminTaxController@update_tax');
			//Contract Type route
			Route::any('contract-type','admin\AdminContractController@admin_contract');
			Route::get('add-contract', 'admin\AdminContractController@add_contract');
			Route::post("save-contract","admin\AdminContractController@save_contract");
			Route::get('contract-edit/{id}', 'admin\AdminContractController@contract_edit');
			Route::post('update-contract', 'admin\AdminContractController@update_contract');
			//Contract  route
			Route::any('contractm','admin\AdminContractmController@admin_contractm');
			Route::get('add-contractm', 'admin\AdminContractmController@add_contractm');
			Route::post("save-contractm","admin\AdminContractmController@save_contractm");
			Route::get('contractm-edit/{id}', 'admin\AdminContractmController@contractm_edit');
			Route::post('update-contractm', 'admin\AdminContractmController@update_contractm');
			//Expense route
			Route::any('expense','admin\AdminExpenseController@admin_expense');
			Route::get('add-expense', 'admin\AdminExpenseController@add_expense');
			Route::post("save-expense","admin\AdminExpenseController@save_expense");
			Route::get('expense-edit/{id}', 'admin\AdminExpenseController@expense_edit');
			Route::post('update-expense', 'admin\AdminExpenseController@update_expense');
			//Expense category route
			Route::any('expense-category','admin\AdminExpensecatController@admin_expense_category');
			Route::get('add-expense-category', 'admin\AdminExpensecatController@add_expense_category');
			Route::post("save-expense-category","admin\AdminExpensecatController@save_expense_category");
			Route::get('expense-category-edit/{id}', 'admin\AdminExpensecatController@expense_category_edit');
			Route::post('update-expense-category', 'admin\AdminExpensecatController@update_expense_category');

			//Lead status route
			Route::any('status','admin\AdminStatusController@admin_status');
			Route::get('add-status', 'admin\AdminStatusController@add_status');
			Route::post("save-status","admin\AdminStatusController@save_status");
			Route::get('status-edit/{id}', 'admin\AdminStatusController@status_edit');
			Route::post('update-status', 'admin\AdminStatusController@update_status');
			//Lead source route
			Route::any('sources','admin\AdminSourcesController@admin_sources');
			Route::get('add-sources', 'admin\AdminSourcesController@add_sources');
			Route::post("save-sources","admin\AdminSourcesController@save_sources");
			Route::get('sources-edit/{id}', 'admin\AdminSourcesController@sources_edit');
			Route::post('update-sources', 'admin\AdminSourcesController@update_source');
			//Task route
			Route::any('task','admin\AdminTaskController@admin_task');
			Route::get('add-task', 'admin\AdminTaskController@add_task');
			Route::post("save-task","admin\AdminTaskController@save_task");
			Route::get('task-edit/{id}', 'admin\AdminTaskController@task_edit');
			Route::post('update-task', 'admin\AdminTaskController@update_task');
			//Leads route
			Route::any('leads','admin\AdminLeadsController@admin_leads');
			Route::get('add-leads', 'admin\AdminLeadsController@add_leads');
			Route::any('save-leads','admin\AdminLeadsController@save_leads');
			Route::get('leads-edit/{id}', 'admin\AdminLeadsController@leads_edit');
			Route::post('update-leads', 'admin\AdminLeadsController@update_leads');
			Route::post("get-leaddata","admin\AdminLeadsController@get_leaddata");
			//Proposal route
			Route::any('lead-proposal','admin\AdminProposalController@admin_proposal');
			Route::get('add-proposal', 'admin\AdminProposalController@add_proposal');
			Route::get('proposal-edit/{id}', 'admin\AdminProposalController@proposal_edit');
			Route::post('update-proposal', 'admin\AdminProposalController@update_proposal');
			Route::post("save-proposal","admin\AdminProposalController@save_proposal");
			Route::any('customer-proposal','admin\AdminProposalController@admin_customer_proposal');
			Route::get('add-customer-proposal', 'admin\AdminProposalController@add_customer_proposal');
			Route::post("save-customer-proposal","admin\AdminProposalController@save_customer_proposal");
			Route::get('customer-proposal-edit/{id}', 'admin\AdminProposalController@customer_proposal_edit');
			Route::post('update-customer-proposal', 'admin\AdminProposalController@customer_update_proposal');
			Route::any('lead-proposal-download/{id}','admin\AdminProposalController@lead_proposal_download');
			//Staffffffff route
			Route::any('staff','admin\AdminStaffController@admin_staff');
			Route::get('add-staff', 'admin\AdminStaffController@add_staff');
			Route::post("save-staff","admin\AdminStaffController@save_staff");
			Route::get('staff-edit/{id}', 'admin\AdminStaffController@staff_edit');
			Route::post('update-staff', 'admin\AdminStaffController@update_staff');
			Route::get('cv-download/{id}', 'admin\AdminStaffController@getDownload');
			Route::get('staff-detail/{id}', 'admin\AdminStaffController@staff_detail');
			Route::post("permission-save","admin\AdminStaffController@save_permission");
			//log
			Route::any('log-history','admin\AdminMasterController@log_history');
		

		

	});
/*
|-------------------------------------------------------------------------
|Route Controller
|------------------------------------------------------------------------
*/
	Route::controllers([
		'auth' => 'Auth\AuthController',
		'password' => 'Auth\PasswordController',
	]);







