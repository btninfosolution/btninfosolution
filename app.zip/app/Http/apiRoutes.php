<?php

/*
|--------------------------------------------------------------------------
| Application API Routes
|--------------------------------------------------------------------------
*/

	include("apiRoutes.php");

Route::post('api/login','api@login');
Route::post('api/registration','Api@registration');
Route::post('api/forgot-password','Api@forgot_password');
Route::any('api/reset-password/{token}','Api@reset_password');

/**************API Route******************* */

/*Route::any('welcome-to-api','Api@index');
Route::group(['prefix' => 'api','middleware' => 'jwt.auth'], function () {
	Route::post('logout','Api@logout');
	Route::post('update-profile','Api@update_profile');
	Route::post('update-password','Api@update_password');
	Route::post('user-location-store-list','Api@user_location_store_list');
	Route::post('store-list','Api@store_list');
	Route::post('product-list','Api@product_list');
	Route::post('my-list','Api@my_list');
	Route::post('my-list-add','Api@my_list_add');
	Route::post('my-list-delete','Api@my_list_delete');
	Route::post('my-list-product-add','Api@my_list_product_add');
	Route::post('my-list-product-update','Api@my_list_product_update');
	Route::post('my-list-product-delete','Api@my_list_product_delete');
	Route::post('my-list-product-details','Api@my_list_product_details');
	Route::post('my-list-product-list','Api@my_list_product_list');
	Route::post('my-list-invite-list','Api@my_list_invite_list');
	Route::post('my-list-invite-list-update','Api@my_list_invite_update');
	Route::post('my-list-product-marked','Api@my_list_product_marked');
	Route::post('app-user-list','Api@app_user_list');
	Route::post('coupon-list','Api@coupon_list');
	Route::post('user-details','Api@user_details');
	Route::post('user-store-add','Api@user_store_add');
	Route::post('user-store-list','Api@user_store_list');
	Route::post('my-list-invite-list-delete','Api@my_list_invite_delete');
	Route::post('notification-date-time-list','Api@notification_date_time_list');
	Route::post('notification-date-time-details','Api@notification_date_time_details');
	Route::post('notification-date-time-add','Api@notification_date_time_add');
	Route::post('notification-date-time-edit','Api@notification_date_time_edit');
	Route::post('notification-date-time-status','Api@notification_date_time_status');
	Route::post('notification','Api@notification');
	
	
});*/






/**************API Route******************* */
Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);
/************************Admin routes************************* */
/************************Admin routes************************* */


Route::any('/', function()
{
	return "Welcome to ".env('APP_NAME');
});


Route::any('admin-login','admin\AdminLoginController@adminLogin');

Route::any('admin-login-process','admin\admin_controller@admin_login_process');
Route::any('reset-password/{link?}', 'admin\admin_controller@reset_password');
Route::any('reset-password-user/{link?}', 'admin\admin_controller@reset_password_user');
Route::post('send-reset-password-link', 'admin\admin_controller@send_reset_password_link');
Route::post('user-reset-password', 'admin\admin_controller@user_reset_password');
Route::any('reset-password-status', 'admin\admin_controller@reset_password_status');


Route::group(['middleware' => 'auth'], function(){
	Route::any('admin-logout','admin\admin_controller@admin_logout');
	Route::any('admin-change-password','admin\admin_controller@change_password');
	Route::any('admin-change-password-process','admin\admin_controller@change_password_process');
	Route::any('admin-dashboard','admin\admin_controller@admin_dashboard');

	Route::any('admin-product-list','admin\admin_controller@product_list');
	Route::any('admin-product-status-change/{id}/{status}','admin\admin_controller@admin_question_status_change');
	Route::any('admin-product-new','admin\admin_controller@admin_product_new');
	Route::any('admin-store-list','admin\admin_controller@store_list');
	Route::any('admin-product-edit/{id}','admin\admin_controller@admin_product_edit');
	Route::any('admin-store-new','admin\admin_controller@admin_store_new');
	Route::any('admin-store-edit/{id}','admin\admin_controller@admin_store_edit');
	Route::any('delete-row','admin\admin_controller@delete_row');
	Route::any('change-status','admin\admin_controller@change_status');
	Route::any('store-product-list','admin\admin_controller@store_product_list');
	Route::any('store-product-update','admin\admin_controller@store_product_update');
	Route::any('admin-register-user-list','admin\admin_controller@admin_register_user_list');
	Route::any('admin-brand-list','admin\admin_controller@brand_list');
    Route::any('admin-brand-new','admin\admin_controller@admin_brand_new');
    Route::any('admin-brand-edit/{id}','admin\admin_controller@admin_brand_edit');
    Route::any('admin-category-list','admin\admin_controller@category_list');
    Route::any('admin-category-new','admin\admin_controller@admin_category_new');
    Route::any('admin-category-edit/{id}','admin\admin_controller@admin_category_edit');
    Route::any('admin-coupon-list','admin\admin_controller@coupon_list');
    Route::any('admin-coupon-new','admin\admin_controller@admin_coupon_new');
    Route::any('admin-coupon-edit/{id}','admin\admin_controller@admin_coupon_edit');
    Route::any('admin-export-user-data','admin\admin_controller@admin_export_user_data');
    Route::any('admin-export-products','admin\admin_controller@admin_export_products');
    Route::any('admin-product-bulk-upload','admin\admin_controller@admin_product_bulk_upload');
    Route::any('admin-excel-demo-format-products','admin\admin_controller@admin_excel_demo_format_products');
    Route::any('admin-excel-demo-format-brands','admin\admin_controller@admin_excel_demo_format_brands');
    Route::any('admin-brand-bulk-upload','admin\admin_controller@admin_brand_bulk_upload');
});
/*******************************Admin routes************************************ */
/*******************************Admin routes************************************ */
