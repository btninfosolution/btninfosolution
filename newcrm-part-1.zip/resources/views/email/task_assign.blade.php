<style>
   body {margin:0; background:#eef2f6;}
</style>
<div style="max-width:650px; margin:20px auto; font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif">
   <div style="padding:20px; margin-top: 15px; background: #FFF; border-radius:8px;">
      <p style="text-align:center; font-size:18px; margin-top: 0 "> BTN CRM  Team!</p>
      <p style="text-align:left; font-size:16px">Hi <?php echo $name;?>,<br>
                              Admin has assigned a task for you.kindly check<br>
                               Subject: <?php echo $subject;?><br>
                               Start Date: <?php echo $start_date;?><br>
                               Thanks,<br>
                            Team BTN CRM</p>
      
   </div>
   <br />
    <em>- BTN CRM Team</em><br />
    <br />
</div>
