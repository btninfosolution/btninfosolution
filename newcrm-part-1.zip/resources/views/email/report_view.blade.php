<style>
   body {margin:0; background:#eef2f6;}
</style>
<div style="max-width:650px; margin:20px auto; font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif">
   <div style="padding:20px; margin-top: 15px; background: #FFF; border-radius:8px;">
      <p style="text-align:center; font-size:18px; margin-top: 0 ">Guardian Angel!</p>
      <p style="text-align:center">Student Report</p>
      <div style="text-align:center;">
         <p>Student Name : <?=$student_name;?></p><br> 
         <p>School Name : <?=$school_name;?></p><br> 
         <p>School Location: <?=$school_location;?></p><br> 
         <p>Concern Area: <?=$category_name;?></p><br> 
         <p>Comment: <?=$comment;?></p><br> 
      </div>
   </div>
   <br />
    <em>- The Guardian Angel Team</em><br />
    <br />
</div>