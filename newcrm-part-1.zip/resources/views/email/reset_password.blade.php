<style>
   body {margin:0; background:#eef2f6;}
</style>
<div style="max-width:650px; margin:20px auto; font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif">
   <div style="padding:20px; margin-top: 15px; background: #FFF; border-radius:8px;">
      <p style="text-align:center; font-size:18px; margin-top: 0 ">Welcome to Guardian Angel!</p>
      <p style="text-align:center">Click the button below to reset your password.</p>
      <div style="text-align:center;">
         <a href="<?=$redirect_url;?>" style="border-radius: 4px;background-color: #0000A0; color: #FFFFFF; padding: 10px 25px; width:150px; display:inline-block; text-decoration: none;">Reset!</a>  &nbsp;
      </div>
   </div>
   <br />
    <em>- Guardian Angle  Team</em><br />
    <br />
</div>