<!DOCTYPE html>
<html lang="en">
   @include('admin/admin_head') 
   <body class="bg-theme bg-theme1">
      <!-- start loader -->
      <div id="pageloader-overlay" class="visible incoming">
         <div class="loader-wrapper-outer">
            <div class="loader-wrapper-inner" >
               <div class="loader"></div>
            </div>
         </div>
      </div>
      <!-- end loader -->
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      @include('admin/admin_leftpanel')
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      @include('admin/admin_header')
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
      <div class="container-fluid">
      <div class="row mt-3">
      <h4 class="page-title pull-left">Group Summary</h4>
      <div class="col-md-12">
         <div class="row" style="padding-top:20px;">
            <!--<button type="button" class="btn btn-primary mb-3">New Customer</button>-->
            <a class="btn btn-primary mb-3" href="{{url('add-group')}}"></i> New Group</a>
         </div>
         @include('admin/admin_alert') 
      </div>
      
      <div class="card">
      <div class="card-body">
         <h5 class="card-title">Groups</h5>
         <div class="table-responsive">
            <table class="table footable" data-page-size="6" data-first-text="FIRST" data-next-text="NEXT" data-previous-text="PREVIOUS" data-last-text="LAST">
                  


                  <thead class="bg-light text-capitalize">
                                    <tr>
                                       <th>
                                          <div class="custom-control custom-checkbox">
                                             <input type="checkbox" class="custom-control-input" id="customCheck1" unchecked>
                                          </div>
                                       </th>
                                       <th scope="col">#</th>
                                       <th scope="col">Group Name</th>
                                       <th scope="col">Date Created</th>
                                       <th scope="col">Action</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?php $i = 1; ?>
                                    @if (!empty($grouplist))
                                    @foreach($grouplist as $group) 
                                    <?php   $id= Crypt::encrypt($group->group_id );?> 
                                    <tr scope="row">
                                       <td><input type="checkbox" class="custom-control-input" id="customCheck1" unchecked></td>
                                       <td>{{$i}}</td>
                                       <td>{{$group->group_name}}</td>
									   <td>{{$group->created_at}}</td>
                           
                                       <td> <a href="{{url('group-edit').'/'.$id}}" title="Edit" data-toggle="tooltip"><span class="badge badge-pill badge-primary">Edit</span></a>|
									    <a data-id="{{ $group->is_deleted }}"href="{{ url('delete-record') }}?status_data={{Crypt::encrypt($group->group_id.'&tbl_groups&group_id&'.$group->is_deleted.'&group'.'&0') }}" title="Delete" onclick="return confirm('Are you sure you want to delete this group ?');" data-toggle="tooltip"><span class="badge badge-pill badge-danger">Delete</span></a> 
									   </td>
                                    </tr>
                                    <?php $i++; ?>
                                    @endforeach
                                    @endif 
                                 </tbody>


                  
                   
               

     

                    <tfoot class="hide-if-no-paging">
            <td colspan="5">
                <div class="pagination"></div>
            </td>
            </tfoot>
            

                </table>
                              <div class="pagination">
            <!--start overlay-->
            <div class="overlay toggle-menu"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
        <div class="overlay"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      @include('admin/admin_footer')
 
   </body>
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>




