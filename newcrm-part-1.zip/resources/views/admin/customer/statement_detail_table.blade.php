<div class="panel_s">
    <div class="panel-body">
        <div class="row">
            <div class="col-md-12">
               <address class="text-right"> </address>
           </div>
           <div class="col-md-12">
               <hr>
           </div>
        </div>
        <div class="row">
           <div class="col-md-7">
               <address>
                    <p>To:</p>
                    <b>{{$invoicelist[0]->company_name}}</b><br> {{$invoicelist[0]->billing_city}}<br> {{$invoicelist[0]->billing_state}}<br> IN {{$invoicelist[0]->billing_zip}}                 
                </address>
            </div>
            <div id="statement-html col-md-5">
                <div class="text-right">
                <h4 class="no-margin bold">Account Summary</h4>
                <p class="text-muted">{{ $start_date}} To {{$due_date}} </p>
                <hr>
                <table class="table statement-account-summary">
                  <tbody>
                   <!--  <tr>
                      <td class="text-left">Beginning Balance:</td>
                      <td>₹0.00</td>
                    </tr> -->
                    <tr>
                      <td class="text-left">Invoiced Amount:</td>
                      <td>₹{{sprintf('%0.2f', $total_amount)}}</td>
                    </tr>
                    <tr>
                      <td class="text-left">Amount Paid:</td>
                      <td>₹{{sprintf('%0.2f', $total_paid_amount)}}</td>
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td class="text-left"><b>Balance Due</b>:</td>
                      <td>₹{{sprintf('%0.2f', $total_amount) - sprintf('%0.2f', $total_paid_amount)}}</td>
                    </tr>
                  </tfoot>
                </table>

            </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12">
                <div class="text-center bold padding-10 ptb--10">Showing all invoices and payments between {{ $start_date}} and {{ $due_date}}  </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                               <tr>
                                 <th><b>Date</b></th>
                                 <th><b>Invoice Number</th>
                                 <th class="text-right"><b>Amount</b></th>
                                 <th class="text-right"><b>Payments</b></th>
                               </tr>
                            </thead>
                            <tbody>
                               @if (!empty($invoicelist))
                                @foreach($invoicelist as $invoice) 
                                 <?php   $id= Crypt::encrypt($invoice->invoice_id );?>
                               <tr>
                                 <td>{{$invoice->invoice_date}}</td>
                                 <td>{{$invoice->invoice_number}}</td>
                                 <td class="text-right">{{$invoice->total_amount}}</td>
                                 <td>{{$invoice->total_paid_amount}}</td>
                               </tr>
                                @endforeach
                               @endif 
                              </tbody>
                              <tfoot class="statement_tfoot">
                               <tr>
                                 <td colspan="3" class="text-right">
                                   <b>Balance Due</b>
                                 </td>
                                 <td class="text-right" colspan="2">
                                   <b>₹{{sprintf('%0.2f', $total_amount) - sprintf('%0.2f', $total_paid_amount)}}</b>
                                 </td>
                               </tr>
                             </tfoot>
                        </table>
                    </div>
            </div>
        </div>
    </div>
</div>