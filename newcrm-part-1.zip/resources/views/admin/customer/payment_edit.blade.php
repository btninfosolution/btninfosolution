<!doctype html>
<html class="no-js" lang="en">
@include('admin/admin_head')

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <!-- preloader area start -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- preloader area end -->
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
          @include('admin/admin_leftpanel')
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
             @include('admin/admin_header')
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
            
            
            
            
            
            
            
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Payment</h4>
                            
                        </div>
                    </div>
                     @include('admin/page_title')
                </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner row" style="margin-right:0px; margin-left:0px;">
            
            
            <div class="col-md-5" style="margin-top:20px;">
            <div class="card col-md-12">	
                <div class="card-body" style="padding:10px 0px;">
                               <div class="panel-body">
								<h4 class="no-margin">Payment for Invoice <a href="http://leadsmanagement.online/btninfosolution/admin/invoices/list_invoices/3">INV-000003</a></h4>
								<hr class="hr-panel-heading">
								<div class="form-group" app-field-wrapper="amount"><label for="amount" class="control-label"> <small class="req text-danger">* </small>Amount Received</label>
                                <input type="number" id="amount" name="amount" class="form-control" value="21000.00"></div>								
                                
                                <div class="form-group">
                                            <label for="example-datetime-local-input" class="col-form-label">Date and time</label>
                                            <input class="form-control" type="date" value="2018-07-19T15:30:00" id="example-datetime-local-input">
                                        </div>				

				
                
                <div class="form-group">
                                            <label class="col-form-label">Payment Mode</label>
                                            <select class="form-control">
                                                <option>Bank</option>
                                                <option>Gpay</option>
                                                <option>Small select</option>
                                            </select>
                                        </div>
                
                
                								<i class="fa fa-question-circle" data-toggle="tooltip" data-title="Some payment gateways support different/multiple payment methods like Credit Card, PayPal, Bank."></i>
								<div class="form-group" app-field-wrapper="paymentmethod"><label for="paymentmethod" class="control-label">Payment Method</label><input type="text" id="paymentmethod" name="paymentmethod" class="form-control" value=""></div>								<div class="form-group" app-field-wrapper="transactionid"><label for="transactionid" class="control-label">Transaction ID</label><input type="text" id="transactionid" name="transactionid" class="form-control" value=""></div>								<div class="form-group" app-field-wrapper="note"><label for="note" class="control-label">Note</label><textarea id="note" name="note" class="form-control" rows="7"></textarea></div>								
							</div> 
                                
                            </div>
                
            </div>
            </div>            
      
            <div class="card col-md-7" style="margin-top:20px;">
                            <div class="card-body">
                                
                                <div class="panel_s">
					<div class="panel-body">
						<h4 class="pull-left ">Payment</h4>
						<div class="pull-right">
							<div class="btn-group btn_butt">
								<a href="#" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-file-pdf-o"></i> <span class="caret"></span></a>
								<ul class="dropdown-menu dropdown-menu-right">
									<li class="hidden-xs"><a href="http://leadsmanagement.online/btninfosolution/admin/payments/pdf/3?output_type=I">View PDF</a></li>
									<li class="hidden-xs"><a href="http://leadsmanagement.online/btninfosolution/admin/payments/pdf/3?output_type=I" target="_blank">View PDF in New Tab</a></li>
									<li><a href="http://leadsmanagement.online/btninfosolution/admin/payments/pdf/3">Download</a></li>
									<li>
										<a href="http://leadsmanagement.online/btninfosolution/admin/payments/pdf/3?print=true" target="_blank">
											Print										</a>
									</li>
								</ul>
							</div>
															<a href="http://leadsmanagement.online/btninfosolution/admin/payments/delete/3" class="btn btn-danger _delete">
									<i class="fa fa-remove"></i>
								</a>
													</div>
						<div class="clearfix"></div>
						<hr class="hr-panel-heading">
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<address>
																	</address>
							</div>
							<div class="col-sm-6 text-right">
								<address>
									<span class="bold">
										<a href="http://leadsmanagement.online/btninfosolution/admin/clients/client/2" target="_blank"><b>BTN Infosolution</b></a><br> jaipur<br> Chinsurah West Bengal<br> IN 712102									</span></address>
								</div>
							</div>
							<div class="col-md-12 text-center">
								<h3 class="text-uppercase">Payment Receipt</h3>
							</div>
							<div class="col-md-12 mtop30">
								<div class="row">
									<div class="col-md-6">
										<p>Payment Date: <span class="pull-right bold">2020-08-05</span></p>
										<hr>
										<p>Payment Mode:											
                                        <span class="pull-right bold">
												Bank	
                                        </span></p>
									</div>
                                    </div>
										<div class="clearfix"></div>
								<div class="row">
										<div class="col-md-6">
											<div class="payment-preview-wrapper">
												Total Amount<br>
												₹21,000.00											
                                            </div>
										</div>
									</div>
								</div>
								<div class="col-md-12 mtop30">
									<h4>Payment For</h4>
									<div class="table-responsive">
										<table class="table table-borderd table-hover">
											<thead>
												<tr>
													<th>Invoice Number</th>
													<th>Invoice Date</th>
													<th>Invoice Amount</th>
													<th>Payment Amount</th>
																									</tr>
											</thead>
											<tbody>
												<tr>
													<td>INV-000003</td>
													<td>2020-08-05</td>
													<td>₹21,000.00</td>
													<td>₹21,000.00</td>
																									</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
                                
                            </div>
                        </div>
            
                            
<div class="btn-bottom-toolbar text-right col-md-12" style="margin-top:15px; padding:0px;">
									<button type="submit" class="btn btn-info">Save</button>
								</div>
            
            
            
            
                
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
        <footer>
            <div class="footer-area">
                <p>© Copyright 2020. All right reserved. Created by <a href="#">Lorem Ipsum</a>.</p>
            </div>
        </footer>
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    <!-- offset area start -->
    <div class="offset-area">
        <div class="offset-close"><i class="ti-close"></i></div>
        <ul class="nav offset-menu-tab">
            <li><a class="active" data-toggle="tab" href="#activity">Activity</a></li>
            <li><a data-toggle="tab" href="#settings">Settings</a></li>
        </ul>
        <div class="offset-content tab-content">
            <div id="activity" class="tab-pane fade in show active">
                <div class="recent-activity">
                    <div class="timeline-task">
                        <div class="icon bg1">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg2">
                            <i class="fa fa-check"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Added</h4>
                            <span class="time"><i class="ti-time"></i>7 Minutes Ago</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg2">
                            <i class="fa fa-exclamation-triangle"></i>
                        </div>
                        <div class="tm-title">
                            <h4>You missed you Password!</h4>
                            <span class="time"><i class="ti-time"></i>09:20 Am</span>
                        </div>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg3">
                            <i class="fa fa-bomb"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Member waiting for you Attention</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg3">
                            <i class="ti-signal"></i>
                        </div>
                        <div class="tm-title">
                            <h4>You Added Kaji Patha few minutes ago</h4>
                            <span class="time"><i class="ti-time"></i>01 minutes ago</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg1">
                            <i class="fa fa-envelope"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Ratul Hamba sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Hello sir , where are you, i am egerly waiting for you.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg2">
                            <i class="fa fa-exclamation-triangle"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg2">
                            <i class="fa fa-exclamation-triangle"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg3">
                            <i class="fa fa-bomb"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                    <div class="timeline-task">
                        <div class="icon bg3">
                            <i class="ti-signal"></i>
                        </div>
                        <div class="tm-title">
                            <h4>Rashed sent you an email</h4>
                            <span class="time"><i class="ti-time"></i>09:35</span>
                        </div>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                        </p>
                    </div>
                </div>
            </div>
            <div id="settings" class="tab-pane fade">
                <div class="offset-settings">
                    <h4>General Settings</h4>
                    <div class="settings-list">
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Notifications</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch1" />
                                    <label for="switch1">Toggle</label>
                                </div>
                            </div>
                            <p>Keep it 'On' When you want to get all the notification.</p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Show recent activity</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch2" />
                                    <label for="switch2">Toggle</label>
                                </div>
                            </div>
                            <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Show your emails</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch3" />
                                    <label for="switch3">Toggle</label>
                                </div>
                            </div>
                            <p>Show email so that easily find you.</p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Show Task statistics</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch4" />
                                    <label for="switch4">Toggle</label>
                                </div>
                            </div>
                            <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Notifications</h5>
                                <div class="s-swtich">
                                    <input type="checkbox" id="switch5" />
                                    <label for="switch5">Toggle</label>
                                </div>
                            </div>
                            <p>Use checkboxes when looking for yes or no answers.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- offset area end -->
    <!-- jquery latest version -->
     @include('admin/admin_footer')
</body>

</html>
