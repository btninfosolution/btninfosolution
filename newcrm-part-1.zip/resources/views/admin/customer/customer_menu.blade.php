<div class="col-md-4">
            <div class="card col-md-12">	
                <div class="card-body">
                                <h4 class="header-title">Contextual Classes Links</h4>
                                <div class="list-group">
                                <a href="{{url('customer-detail').'/'.$enc_type}}" class="list-group-item list-group-item-action">
                                    <i class="fa fa-user"></i>&nbsp;
                                    Profile</a>
                                    
                                    <a href="{{url('contact-detail').'/'.$id}}" class="list-group-item list-group-item-action">
                                    <i class="fa fa-phone"></i>&nbsp;
                                    Contacts</a>
                                    
                                    <a href="{{url('note-detail').'/'.$id}}" class="list-group-item list-group-item-action">
                                    <i class="ti-layout-sidebar-left"></i>&nbsp;
                                    Notes</a>
                                    
                                    <a href="{{url('invoice-detail').'/'.$id}}" class="list-group-item list-group-item-action">
                                    <i class="fa fa-file"></i>&nbsp;
                                    Invoice</a>
                                    
                                    
                                     <a href="{{url('payment-detail').'/'.$id}}" class="list-group-item list-group-item-action">
                                    <i class="fa fa-money"></i>&nbsp;
                                    Payment</a>
                                    
                                    <a href="{{url('statement-detail').'/'.$id}}" class="list-group-item list-group-item-action">
                                    <i class="fa fa-file"></i>&nbsp;
                                    Statement</a>
                                    
                                    <a href="{{url('proposal-detail').'/'.$id}}" class="list-group-item list-group-item-action">
                                    <i class="ti-layout-sidebar-left"></i>&nbsp;
                                    Proposal</a>
                                   
                                    
                                   
                                </div>
                            </div>
                
            </div>
            </div>