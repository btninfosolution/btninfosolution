<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
   @include('admin/admin_head') 
    <head>
   <style>
  .footer {
          position: fixed;
          padding-right: 300px;
          border-top: 0.1%;
          text-align: center;
          width: 100%;
   }
   div.footer {
          border-top: 0;
           text-align: center;
   }
  
   </style>
   </head>
   <body class="bg-theme bg-theme1">
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      @include('admin/admin_leftpanel')
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      @include('admin/admin_header')
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
         <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
               <div class="col-sm-9">
                  <h4 class="page-title">Group</h4>
               </div>
               <div class="col-sm-3">
                  <div class="btn-group float-sm-right">
                     <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
                     <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
                     <span class="caret"></span>
                     </button>
                     <div class="dropdown-menu">
                        <a href="javaScript:void();" class="dropdown-item">Action</a>
                        <a href="javaScript:void();" class="dropdown-item">Another action</a>
                        <a href="javaScript:void();" class="dropdown-item">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a href="javaScript:void();" class="dropdown-item">Separated link</a>
                     </div>
                  </div>
               </div>
            </div>
            <!-- End Breadcrumb-->
            <hr>
            <div class="row">
               <div class="col-lg-12">
                  <div class="card">
                     <div class="card-body">
                        <ul class="nav nav-tabs nav-tabs-primary">
                           <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#tabe-1"><i class="icon-home"></i> <span class="hidden-xs">Group Details</span></a>
                           </li>
                        </ul>
                        <form action="{{ url('save-leads') }}" class="form-material" id="formData" name="create_leads" method="post" >
                        {{csrf_field()}}
                        @if (count($errors) > 0)
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                              @endforeach
                           </ul>
                        </div>
                        @endif
                        
						
						
						
						
						<div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
							  
							  <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Status<span class="text-danger">*</span></label>
                                    <select id="status" name="status"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @if(!empty($statuslist))
                                       @foreach ($statuslist as $status) 
                                       <option value="{{$status->status_id}}">{{$status->status_name}}</option>
                                       @endforeach
                                       @endif
                                    </select>
                                </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Source<span class="text-danger">*</span></label>
                                    <select id="sources" name="sources"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @if(!empty($sourcelist))
                                       @foreach ($sourcelist as $sources) 
                                       <option value="{{$sources->sources_id}}">{{$sources->sources_name}}</option>
                                       @endforeach
                                       @endif
                                    </select>
                                 </div>
							  
							  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Tags</label>
                                    <select id="tag" name="tag"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @if(!empty($taglist))
                                       @foreach ($taglist as $tag) 
                                       <option value="{{$tag->tag_id}}">{{$tag->tag_name}}</option>
                                       @endforeach
                                       @endif
                                    </select>
                                 </div>
							  
							   <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Assigned</label>
                                    <select id="staff" name="staff"class=""style="width:100%" >
                                    <option value='' selected='true'>Please Select </option>
                                      @if(!empty($stafflist))
                                       @foreach ($stafflist as $staff) 
                                       <option value="{{$staff->staff_id}}">{{$staff->first_name}} {{$staff->last_name}}</option>
                                       @endforeach
                                       @endif
                                       </select>
                                 </div>
							  
							  
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="name" placeholder="Name" name="name">
                                    
                                 </div>
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Address</label>
                                    <input type="text" class="form-control" id="address" placeholder="Address" name="address">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Company</label>
                                   <input type="text" class="form-control" id="company" name="company" placeholder="Company" >
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Position</label>
                                    <input type="text" class="form-control" id="position" name="position" placeholder="Position" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">City</label>
                                    <input type="text" class="form-control" id="city" placeholder="City" name="city">
                                   
                                 </div>
                                
								
								<div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Email</label>
                                    <input type="text" class="form-control" id="email" name="email" placeholder="Email" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">State</label>
                                    <input type="text" class="form-control" id="state" placeholder="State" name="state">
                                   
                                 </div>
								
																
								 <div class="col-md-6 mb-3">
                                   <label for="validationCustom05">Country</label>
                                    <input type="text" class="form-control" id="country" name="country" placeholder="Country" >
	                             </div>
								 
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Website</label>
                                    <input type="text" class="form-control" id="website" name="website" placeholder="" >
                                 </div>
                                 
								 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Phone</label>
                                    <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone" >
                                 </div>
								 
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Zip Code</label>
                                    <input type="text" class="form-control" id="zip" name="zip" placeholder="Zip" >
                                 </div>
								 
								 
								 
								 
								 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Description</label>
                                    <textarea id="description" name="description" class="form-control" rows="4"></textarea>
                                 </div> 
                                 

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Add As Customer</label>
                                      <input type="checkbox" id="add_as_user" name="add_as_user" value="1">

                                 </div> 
                                 

								 
								 
                              </div>
                           </div>
                          
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--End Row-->
            <!--End Row-->
            <div class="overlay"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
<div class="footer">
      @include('admin/admin_footer')
     </div>
     <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
      <script type="text/javascript">
         $("#formData").validate({
           rules: {
             category_name: {
               	required:true,
             },
            
            
            
          
           },
         messages: {
          category_name:{
               required:"{{ trans('messages.366') }}",
             } ,
            
            
             
         
           
           }
         });
      </script>
   </body>
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>

