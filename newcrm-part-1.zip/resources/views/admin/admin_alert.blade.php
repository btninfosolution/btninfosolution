 @if(session('success'))
<div class="callout alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
   <span style="color: green;">{{session('success')}}</span>
</div>
@endif
@if(session('danger'))
<div class="callout alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <span style="color: red;">{{session('danger')}}</span>
</div>
@endif