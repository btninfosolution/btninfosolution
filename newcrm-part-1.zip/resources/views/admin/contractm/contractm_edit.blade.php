<!doctype html>
<html class="no-js" lang="en">
   @include('admin/admin_head') 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         @include('admin/admin_leftpanel')
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            @include('admin/admin_header')
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Contract</h4>
                     </div>
                  </div>
                  @include('admin/page_title')
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Add New Contract</a>
                           <!--<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Advance Option</a>-->
                        </div>
                     </nav>
                     <form action="{{ url('update-contractm') }}" class="form-material" id="formData" name="create_expense" method="post" >
                        {{csrf_field()}}
                        @if (count($errors) > 0)
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                              @endforeach
                           </ul>
                        </div>
                        @endif
                        <input type="hidden" id="id" name="id" value="{{$Editdata->contractm_id}}">
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Subject <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="subject" placeholder="Subject" value="{{$Editdata->contractm_subject}}" name="subject">
                                  </div>
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Contract Value <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="amount" value="{{$Editdata->contractm_value}}"placeholder="Amount" name="amount">
                                    
                                 </div>
                                 
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Start Date <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="start" value="{{$Editdata->contractm_stdt}}" placeholder="Start Date" name="start">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">End Date <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="expiry"value="{{$Editdata->contractm_enddt}}" placeholder=End Date" name="expiry">
                                   
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Customer <span class="text-danger">*</span></label>
                                    <select id="customer_id" name="customer_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @foreach ($customerlist as $group) 
                                       <option value="{{$group->id}}" {{ $Editdata->customer_id == $group->id  ? 'selected' : ''}}>{{$group->client_name}}</option>
                                       @endforeach
                                    </select>
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Contract Type <span class="text-danger">*</span></label>
                                    <select id="contype_id" name="contype_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @foreach ($contypelist as $con) 
                                       <option value="{{$con->contract_id}}" {{ $Editdata->contractm_type == $con->contract_id  ? 'selected' : ''}}>{{$con->contract_name}}</option>
                                       @endforeach
                                    </select>
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Description</label>
                                    <textarea type="text" class="form-control" id="description" placeholder="Description" name="description">{{$Editdata->contractm_desc}}</textarea>
                                    
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                              <div class="form-row">
                                 
                                 
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Currency</label>
                                    <input type="text" class="form-control" id="currency" name="currency" placeholder="Currency" value="INR" readonly="">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Tax 1</label>
                                    <input type="text" class="form-control" id="tax1" name="tax1" placeholder="Tax 1" >
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Tax 2</label>
                                    <input type="text" class="form-control" id="tax2" name="tax2" placeholder="Tax 2" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Payment Mode</label>
                                    <select id="payment_mode" name="payment_mode"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <option value="Bank">Bank</option>
                                       <option value="Google Pay">Google Pay</option>
                                    </select>
                                    <!-- <input type="text" class="form-control" id="payment_mode" name="payment_mode" placeholder="Payment Mode" > -->
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Reference</label>
                                    <input type="text" class="form-control" id="reference" name="reference" placeholder="Reference" >
                                    
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <button type="submit" class="btn btn-primary next" id="expense_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      @include('admin/admin_footer')
       <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
  $("#formData").validate({
    rules: {
        subject: {
          required:true,
      },
      customer_id: {
          required:true,
      },
      contype_id: {
          required:true,
      },
      amount: {
          required:true,
          digits:true,
           
      },
     
     
    
    },
  messages: {
   subject:{
        required:"{{ trans('messages.377') }}",
      } ,
      customer_id:{
        required:"{{ trans('messages.378') }}",
      } ,
      contype_id:{
        required:"{{ trans('messages.379') }}",
      } ,
      amount:{
        required:"{{ trans('messages.356') }}",
        digits:"{{ trans('messages.357') }}",
      } ,
     
      
   
    
    }
  });
</script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/css/bootstrap-datepicker.min.css" />
	  
<script>
  $(document).ready(function() {
  var date = new Date();
  var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  //var end = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  $('#start').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });
  $('#expiry').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });

  $('#start,#expiry').datepicker('setDate');
});
</script>
   </body>
</html>