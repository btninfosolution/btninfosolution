<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8">
      <title>{{ env('APP_NAME') }} || {{ $page_title }}</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="" />
      <meta name="keywords" content="" />
      <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/login/bootstrap.min.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/font-awesome.min.css')}}">
      <link rel="stylesheet" type="text/css" href="{{asset('public/backend/css/login/login.css')}}">
      <script src="{{asset('public/backend/js/jquery.min.js')}}"></script>
      <script src="{{asset('public/backend/js/jquery.validate.min.js')}}"></script>
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
      <style>
         label.error {
         color:red;
         }
      </style>
   </head>
   <body class="sign-in">
      <div class="wrapper">
      <div class="sign-in-page">
         <div class="signin-popup">
            <div class="signin-pop">
               <div class="row">
                  <div class="col-lg-6">
                     <div class="cmp-info">
                        <div class="cm-logo">
                           <img src="{{asset('public/backend/images/logo.png')}}" alt="" height="140"> <br>
                           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                        <!--cm-logo end-->	
                        <img src="images/cm-main-img.png" alt="">			
                     </div>
                     <!--cmp-info end-->
                  </div>
                  <div  class="col-lg-6">
                     <div class="login-sec">
                        <ul class="sign-control">
                           <li data-tab="tab-1" class="current">
                              <!-- <a href="" title="">Reset Password</a> -->
                           </li>
                        </ul>
                        <div class="sign_in_sec current" id="tab-1">
                           <h3>Forget Password</h3>
                           @if(count($errors) > 0)
                           <div class="alert alert-danger">
                              <ul>
                                 @foreach ($errors->all() as $error)
                                 <li>{{ $error }}</li>
                                 @endforeach
                              </ul>
                           </div>
                           @endif
                           @if(session('message'))
                           <div class="alert alert-{{session('message.type')}} alert-dismissible">
                              {{session('message.text')}}
                           </div>
                           @endif
                           <form name="loginform" id="change_password_form" class="form-vertical wpawll-loginform" action="{{url('user-reset-password')}}" method="post" <?=session('message.type')=='error' ? 'style="display: none;"' : ''?>>
                              <input type="hidden" name="user_data" value="<?=$user_data;?>">
                                <div class="row">
                                 <div class="col-lg-12 no-pdd">
                                    <div class="sn-field">
                                       <input type="password" id="exampleEmail" name="password" placeholder="Password">
                                       <i class="fa fa-key"></i>
                                    </div>
                                    <!--sn-field end-->
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-12 no-pdd">
                                       <div class="sn-field">
                                          <input type="password" id="examplepassword" name="confirm_password" placeholder="Confirm Password">
                                          <i class="fa fa-key"></i>
                                       </div>
                                       <!--sn-field end-->
                                    </div>
                                    <div class="col-lg-12 no-pdd">
                                       <!--	<a href="dashboard.html" class="btn btn-danger mt-4">Login</a>-->
                                       <input type="submit" class="btn btn-danger mt-4" id="admin_login_submit" value="Submit"/>
                                    </div>
                                 </div>
                           </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script type="text/javascript">
         $('#wpawll-rememberme').click(function() {
             if($(this).is(':checked'))
             {
         		alert('aaa');
                 $("#is_remember").val('No');
             }
             else
             {
         		alert('bbb');
                 $("#is_remember").val('Yes');
             }
         });
      </script>
      <script>
      	$.validator.addMethod("pwcheck", function(value) {
		   return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) // consists of only these
		       && /[a-z]/.test(value) // has a lowercase letter
		       && /\d/.test(value) // has a digit
		});
         $("#change_password_form").validate({
           rules: {
         password: {
               	required:true,
               	pwcheck:true,
               	minlength: 6
             },
             confirm_password: {
               	required:true,
               	minlength: 6
             },
         
           },
         messages: {
         password:{
               required:"{{ trans('messages.330') }}",
               pwcheck:"Password should contain atlist one uppercase & one lowercase & one number.",
         	   minlength:"{{ trans('messages.332') }}",
             } ,
             confirm_password:{
               required:"{{ trans('messages.331') }}",
             } ,
           }
         });
      </script>
   </body>
</html>