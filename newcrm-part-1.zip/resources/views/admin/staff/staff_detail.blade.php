<!doctype html>
<html class="no-js" lang="en">
   @include('admin/admin_head') 
   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
      <!-- sidebar menu area start -->
      @include('admin/admin_leftpanel')
      <!-- sidebar menu area end -->
      <!-- main content area start -->
      <div class="main-content">
         <!-- header area start -->
         @include('admin/admin_header')
         <!-- header area end -->
         <!-- page title area start -->
         <div class="page-title-area">
            <div class="row align-items-center">
               <div class="col-sm-6">
                  <div class="breadcrumbs-area clearfix">
                     <h4 class="page-title pull-left">Statement</h4>
                  </div>
               </div>
               @include('admin/page_title')
            </div>
         </div>
         <!-- page title area end -->
         <div class="main-content-inner row" style="margin-right:0px; margin-left:0px;">
            <div class="col-md-12 pt--10">
               <div class="panel_s">
                  <div class="panel-body no-padding-bottom">
                     <div class="staff_logged_time row" data-toggle="tooltip" data-title="Timesheets" data-placement="left" data-original-title="" title="">
                        <div class="col-md-5ths col-xs-12 total-column">
                           <div class="panel_s">
                              <div class="panel-body">
                                 <h3 class="text-muted _total">
                                    00:00     
                                 </h3>
                                 <span class="staff_logged_time_text text-success">Total Logged Time</span>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-5ths col-xs-12 total-column">
                           <div class="panel_s">
                              <div class="panel-body">
                                 <h3 class="text-muted _total">
                                    00:00   
                                 </h3>
                                 <span class="staff_logged_time_text text-info">Last Month Logged Time</span>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-5ths col-xs-12 total-column">
                           <div class="panel_s">
                              <div class="panel-body">
                                 <h3 class="text-muted _total">
                                    00:00  
                                 </h3>
                                 <span class="staff_logged_time_text text-success">This Month Logged Time</span>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-5ths col-xs-12 total-column">
                           <div class="panel_s">
                              <div class="panel-body">
                                 <h3 class="text-muted _total">
                                    00:00   
                                 </h3>
                                 <span class="staff_logged_time_text text-info">Last Week Logged Time</span>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-5ths col-xs-12 total-column">
                           <div class="panel_s">
                              <div class="panel-body">
                                 <h3 class="text-muted _total">
                                    00:00   
                                 </h3>
                                 <span class="staff_logged_time_text text-success">This Week Logged Time</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="clearfix"></div>
                  </div>
               </div>
            </div>
            <div class="col-md-12 pt--10">
               <div class="panel_s">
                  <div class="panel-body">
                     <h4 class="no-margin">{{$Editdata->first_name}} {{$Editdata->last_name}}                                    <small> - Last Active:
                        <span class="text-has-action" data-toggle="tooltip" data-title="2020-07-14 13:28:44">
                        a month ago                        </span>
                        </small>
                        <a href="#" onclick="small_table_full_view(); return false;" data-placement="left" data-toggle="tooltip" data-title="Toggle full view" class="toggle_view pull-right">
                        <i class="fa fa-expand"></i></a>
                     </h4>
                  </div>
               </div>
            </div>
            <div class="col-md-5" style="margin-top:20px;">
               <div class="card col-md-12">
                  <div class="panel-body">
                     <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active">
                           <a href="#tab_staff_profile" aria-controls="tab_staff_profile" role="tab" data-toggle="tab">
                           Profile                     </a>
                        </li>
                        <li role="presentation">
                           <a href="#tab_staff_permissions" aria-controls="tab_staff_permissions" role="tab" data-toggle="tab">
                           Permissions                     </a>
                        </li>
                     </ul>
                     <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="tab_staff_profile">
                          
                           
                           <div class="form-group">
                              <div class="row">
                                 <div class="col-md-9">
                                 @if ($Editdata->profile_image !='')
                                                <img src="{{asset('public/uploads/contact_image/'.$Editdata->profile_image)}}" style="max-width:100px;" class="img img-responsive staff-profile-image-thumb"></span> </a>
                                                @else
                                                <img src="{{asset('public/uploads/'.'noimg.png')}}" style="max-width:100px;" class="img img-responsive staff-profile-image-thumb"></span> </a>
                                                @endif
                                   
                                 </div>
                                 
                              </div>
                           </div>
                           <div class="form-group" app-field-wrapper="firstname"><label for="firstname" class="control-label">First Name</label><input type="text" id="firstname" name="firstname" class="form-control" value="{{$Editdata->first_name}}"></div>
                           <div class="form-group" app-field-wrapper="lastname"><label for="lastname" class="control-label">Last Name</label><input type="text" id="lastname" name="lastname" class="form-control" value="{{$Editdata->last_name}}"></div>
                           <div class="form-group" app-field-wrapper="email"><label for="email" class="control-label">Email</label><input type="email" id="email" name="email" class="form-control" autocomplete="off" value="{{$Editdata->email}}"></div>
                           <label for="hourly_rate">Hourly Rate</label>
                           <div class="input-group ">
                              <input type="text" class="form-control" placeholder="Recipient's username" aria-label="0.00" value="{{$Editdata->hourly_rate}}" aria-describedby="basic-addon2">
                              <div class="input-group-append">
                                 <span class="input-group-text" id="basic-addon2">₹ </span>
                              </div>
                           </div>
                           <div class="form-group" app-field-wrapper="phonenumber"><label for="phonenumber" class="control-label">Phone</label><input type="text" id="phonenumber" name="phonenumber" class="form-control" value="{{$Editdata->phone}}"></div>
                           <div class="form-group">
                              <label for="facebook" class="control-label"><i class="fa fa-facebook"></i> Facebook</label>
                              <input type="text" class="form-control" name="facebook" value="{{$Editdata->facebook}}">
                           </div>
                           <div class="form-group">
                              <label for="linkedin" class="control-label"><i class="fa fa-linkedin"></i> LinkedIn</label>
                              <input type="text" class="form-control" name="linkedin" value="{{$Editdata->linkln}}">
                           </div>
                           <div class="form-group">
                              <label for="skype" class="control-label"><i class="fa fa-skype"></i> Skype</label>
                              <input type="text" class="form-control" name="skype" value="{{$Editdata->skype}}">
                           </div>
                           <div class="form-group">
                              <label for="skype" class="control-label">Date Of Joining</label>
                              <input type="text" class="form-control" name="skype" value="{{$Editdata->joining_date}}">
                           </div>
                           <div class="form-group">
                              <label for="skype" class="control-label">Date of Resignation</label>
                              <input type="text" class="form-control" name="skype" value="{{$Editdata->resign_date}}">
                           </div>
                           <div class="form-group">
                              <label for="skype" class="control-label">Birth Date</label>
                              <input type="text" class="form-control" name="skype" value="{{$Editdata->birth_date}}">
                           </div>
                           <div class="form-group">
                              <label for="skype" class="control-label">Anniversary Date</label>
                              <input type="text" class="form-control" name="skype" value="{{$Editdata->anniversary_date}}">
                           </div>
                           
                           
                           
                           <!-- fake fields are a workaround for chrome autofill getting the wrong fields -->
                           
                           <p class="text-muted">Note: if you populate this field, password will be changed on this member.</p>
                        </div>
						
                        <div role="tabpanel" class="tab-pane" id="tab_staff_permissions">
                           
                           <hr>
                           <h4 class="font-medium mbot15 bold">Permissions</h4>
                           <div class="table-responsive">
						    <form class="form-horizontal"action="{{ url('permission-save') }}" id="add_manager" method="post">
							   <input type="hidden"   id="id" value="{{$Editdata->staff_id}}" name="staff_id" > 
                              <table class="table table-bordered roles no-margin">
                                 <thead>
                                    <tr>
                                       <th class="bold">Permission</th>
                                       <th class="text-center bold">View (Global)</th>
                                       <th class="text-center bold">View (Own)</th>
                                       <th class="text-center bold">Add</th>
                                       <th class="text-center bold">Edit</th>
                                       <th class="text-center text-danger bold">Delete</th>
                                    </tr>
                                 </thead>
								
                                 <tbody>
                                    
                                    <tr data-id="1" data-name="contracts">
                                       <td>
                                          Contracts  
                                          <input type="hidden"value="1" name="contract">										  
                                       </td>
									    @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[0]->global_view ==0)  
                                             <input type="checkbox"  name="global1" value="1">
										 @else
											  <input type="checkbox"  name="global1" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="global1" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                       <td class="text-center">
                                          <div class="checkbox">
                                             <input type="hidden"  name="view_own1" value="0">
                                             <label></label>
                                          </div>
                                       </td>
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[0]->is_add ==0)  
                                             <input type="checkbox"  name="add1" value="1">
										 @else
											  <input type="checkbox"  name="add1" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="add1" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                              @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[0]->is_edit ==0)  
                                             <input type="checkbox"  name="edit1" value="1">
										 @else
											  <input type="checkbox"  name="edit1" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="edit1" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                              @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[0]->delete_permisson ==0)  
                                             <input type="checkbox"  name="delete1" value="1">
										 @else
											  <input type="checkbox"  name="delete1" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="delete1" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                    </tr>
                                   
                                    <tr data-id="8" data-name="customers">
                                       <td>
                                          Customers       
                                      <input type="hidden"value="2" name="customer">										  
                                       </td>
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[1]->global_view ==0)  
                                             <input type="checkbox"  name="global2" value="1">
										 @else
											  <input type="checkbox"  name="global2" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="global2" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                       <td class="text-center">
                                          <div class="checkbox">
                                             <input type="hidden" name="view_own2" value="1">
                                             <label></label>
                                          </div>
                                       </td>
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[1]->is_add ==0)  
                                             <input type="checkbox"  name="add2" value="1">
										 @else
											  <input type="checkbox"  name="add2" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="add2" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                              @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[1]->is_edit ==0)  
                                             <input type="checkbox"  name="edit2" value="1">
										 @else
											  <input type="checkbox"  name="edit2" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="edit2" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                       <td class="text-center">
                                          <div class="checkbox checkbox-danger">
                                             <input type="hidden" name="delete2" value="1">
                                             <label></label>
                                          </div>
                                       </td>
                                    </tr>
									<tr data-id="8" data-name="customers">
                                       <td>
                                          Items      
                                      <input type="hidden"value="3" name="item">										  
                                       </td>
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[2]->global_view ==0)  
                                             <input type="checkbox"  name="global3" value="1">
										 @else
											  <input type="checkbox"  name="global3" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="global3" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                       <td class="text-center">
                                          <div class="checkbox">
                                             <input type="hidden" name="view_own3" value="1">
                                             <label></label>
                                          </div>
                                       </td>
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[2]->is_add ==0)  
                                             <input type="checkbox"  name="add3" value="1">
										 @else
											  <input type="checkbox"  name="add3" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="add3" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                              @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[2]->is_edit ==0)  
                                             <input type="checkbox"  name="edit3" value="1">
										 @else
											  <input type="checkbox"  name="edit3" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="edit3" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[2]->delete_permisson ==0)  
                                             <input type="checkbox"  name="delete3" value="1">
										 @else
											  <input type="checkbox"  name="delete3" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="delete3" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                    </tr>
									 	<tr data-id="8" data-name="customers">
                                       <td>
                                          Leads      
                                      <input type="hidden"value="4" name="lead">										  
                                       </td>
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[3]->global_view ==0)  
                                             <input type="checkbox"  name="global4" value="1">
										 @else
											  <input type="checkbox"  name="global4" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="global4" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                        @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[3]->own_view ==0)  
                                             <input type="checkbox"  name="view_own4" value="1">
										 @else
											  <input type="checkbox"  name="view_own4" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="view_own4" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[3]->is_add ==0)  
                                             <input type="checkbox"  name="add4" value="1">
										 @else
											  <input type="checkbox"  name="add4" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="add4" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                              @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[3]->is_edit ==0)  
                                             <input type="checkbox"  name="edit4" value="1">
										 @else
											  <input type="checkbox"  name="edit4" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="edit4" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                      
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="hidden"  name="delete4" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									  
                                    </tr>
                                  	<tr data-id="8" data-name="customers">
                                       <td>
                                          Staff      
                                      <input type="hidden"value="5" name="staff">										  
                                       </td>
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[4]->global_view ==0)  
                                             <input type="checkbox"  name="global5" value="1">
										 @else
											  <input type="checkbox"  name="global5" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="global5" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                        @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[4]->own_view ==0)  
                                             <input type="checkbox"  name="view_own5" value="1">
										 @else
											  <input type="checkbox"  name="view_own5" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="view_own5" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[4]->is_add ==0)  
                                             <input type="checkbox"  name="add5" value="1">
										 @else
											  <input type="checkbox"  name="add5" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="add5" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                              @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[4]->is_edit ==0)  
                                             <input type="checkbox"  name="edit5" value="1">
										 @else
											  <input type="checkbox"  name="edit5" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="edit5" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                      
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="hidden"  name="delete5" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									  
                                    </tr>
									<tr data-id="8" data-name="customers">
                                       <td>
                                          Task      
                                      <input type="hidden"value="6" name="task">										  
                                       </td>
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[5]->global_view ==0)  
                                             <input type="checkbox"  name="global6" value="1">
										 @else
											  <input type="checkbox"  name="global6" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="global6" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                        @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[5]->own_view ==0)  
                                             <input type="checkbox"  name="view_own6" value="1">
										 @else
											  <input type="checkbox"  name="view_own6" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="view_own6" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                       @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[5]->is_add ==0)  
                                             <input type="checkbox"  name="add6" value="1">
										 @else
											  <input type="checkbox"  name="add6" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="add6" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                              @if(!empty($permissiondata))
                                       <td class="text-center">
                                          <div class="checkbox">
										   @if($permissiondata[5]->is_edit ==0)  
                                             <input type="checkbox"  name="edit6" value="1">
										 @else
											  <input type="checkbox"  name="edit6" value="0" checked>
										  @endif
                                             <label></label>
                                          </div>
                                       </td>
									   @else
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="checkbox"  name="edit6" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									   @endif
                                      
										   <td class="text-center">
                                          <div class="checkbox">
                                             <input type="hidden"  name="delete6" value="1">
                                             <label></label>
                                          </div>
                                       </td>
									  
                                    </tr>
                                 
                                    
									
                                  
                                 </tbody>
								
								
                              </table>
							   <button type="submit"onclick="return formValidationAdd();" class="btn btn-primary">Submit</button>
							   </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="card col-md-7" style="margin-top:20px; padding-top:10px;">
               <div class="panel-body">
                  <h4 class="no-margin">
                     Notes               
                  </h4>
                  <hr class="hr-panel-heading">
                  <a href="#" class="btn btn-success" onclick="slideToggle('.usernote'); return false;">New Note</a>
                  <div class="clearfix"></div>
                  <hr class="hr-panel-heading">
                  <div class="mbot15 usernote hide inline-block full-width">
                     <form action="http://leadsmanagement.online/btninfosolution/admin/misc/add_note/1/staff" method="post" accept-charset="utf-8">
                        <input type="hidden" name="csrf_token_name" value="6e7a6faae770de96b7a9d2533cfbd925">                                                  
                        <!--<div class="form-group" app-field-wrapper="description"><label for="description" class="control-label">Note description</label><textarea id="description" name="description" class="form-control" rows="5"></textarea></div> 
                           <button class="btn btn-info pull-right mbot15">Save</button>-->
                     </form>
                  </div>
                  <div class="clearfix"></div>
                  <div class="mtop15">
                     <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer app_dt_empty">
                        <div class="row pt--10" style="width:100%;">
                           <div class="col-md-6">
                              <div class="dataTables_length" id="DataTables_Table_0_length">
                                 <label>
                                    <select name="DataTables_Table_0_length" aria-controls="DataTables_Table_0" class="form-control input-sm">
                                       <option value="10">10</option>
                                       <option value="25">25</option>
                                       <option value="50">50</option>
                                       <option value="100">100</option>
                                       <option value="-1">All</option>
                                    </select>
                                 </label>
                              </div>
                              <div class="dt-buttons btn-group"><a class="btn btn-default buttons-collection btn-default-dt-options" tabindex="0" aria-controls="DataTables_Table_0" href="#"><span>Export</span></a></div>
                           </div>
                           <div class="col-md-6">
                              <div id="DataTables_Table_0_filter" class="dataTables_filter">
                                 <label>
                                    <div class="search-box pull-left">
                                       <form action="#">
                                          <input type="text" name="search" placeholder="Search..." required>
                                          <i class="ti-search"></i>
                                       </form>
                                    </div>
                                 </label>
                              </div>
                           </div>
                           <div id="DataTables_Table_0_processing" class="dataTables_processing panel panel-default" style="display: none;">
                              <div class="dt-loader"></div>
                           </div>
                        </div>
                        <div class="table-responsive">
                           <table class="table dt-table scroll-responsive dt-no-serverside dataTable no-footer" data-order-col="2" data-order-type="desc" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info">
                              <thead>
                                 <tr role="row">
                                    <th width="50%" class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Note activate to sort column ascending">Note</th>
                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Added From activate to sort column ascending">Added From</th>
                                    <th class="sorting_desc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="descending" aria-label="Date Added activate to sort column ascending">Date Added</th>
                                    <th class="sorting not-export" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Options activate to sort column ascending">Options</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <tr class="odd">
                                    <td valign="top" colspan="4" class="dataTables_empty">No entries found</td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="panel-body pt--100">
                  <h4 class="no-margin"> Timesheets & Reports  </h4>
                  <hr class="hr-panel-heading">
                  <a href="#" class="btn btn-success" onclick="slideToggle('.usernote'); return false;">New Note</a>
                  <div class="clearfix"></div>
                  <hr class="hr-panel-heading">
                  <div class="mbot15 usernote hide inline-block full-width">
                     <form action="http://leadsmanagement.online/btninfosolution/admin/misc/add_note/1/staff" method="post" accept-charset="utf-8">
                        <input type="hidden" name="csrf_token_name" value="6e7a6faae770de96b7a9d2533cfbd925">                                                  
                        <!--<div class="form-group" app-field-wrapper="description"><label for="description" class="control-label">Note description</label><textarea id="description" name="description" class="form-control" rows="5"></textarea></div> 
                           <button class="btn btn-info pull-right mbot15">Save</button>-->
                     </form>
                  </div>
                  <div class="clearfix"></div>
                  <div class="mtop15">
                     <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer app_dt_empty">
                        <div class="row pt--10" style="width:100%;">
                           <div class="col-md-6">
                              <div class="dataTables_length" id="DataTables_Table_0_length">
                                 <label>
                                    <select name="DataTables_Table_0_length" aria-controls="DataTables_Table_0" class="form-control input-sm">
                                       <option value="10">10</option>
                                       <option value="25">25</option>
                                       <option value="50">50</option>
                                       <option value="100">100</option>
                                       <option value="-1">All</option>
                                    </select>
                                 </label>
                              </div>
                              <div class="dt-buttons btn-group"><a class="btn btn-default buttons-collection btn-default-dt-options" tabindex="0" aria-controls="DataTables_Table_0" href="#"><span>Export</span></a></div>
                           </div>
                           <div class="col-md-6">
                              <div id="DataTables_Table_0_filter" class="dataTables_filter">
                                 <label>
                                    <div class="search-box pull-left">
                                       <form action="#">
                                          <input type="text" name="search" placeholder="Search..." required>
                                          <i class="ti-search"></i>
                                       </form>
                                    </div>
                                 </label>
                              </div>
                           </div>
                           <div id="DataTables_Table_0_processing" class="dataTables_processing panel panel-default" style="display: none;">
                              <div class="dt-loader"></div>
                           </div>
                        </div>
                        <div class="table-responsive">
                           <table class="table dt-table scroll-responsive dt-no-serverside dataTable no-footer" data-order-col="2" data-order-type="desc" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info">
                              <thead>
                                 <tr role="row">
                                    <th width="50%" class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Note activate to sort column ascending">Note</th>
                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Added From activate to sort column ascending">Added From</th>
                                    <th class="sorting_desc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="descending" aria-label="Date Added activate to sort column ascending">Date Added</th>
                                    <th class="sorting not-export" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Options activate to sort column ascending">Options</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <tr class="odd">
                                    <td valign="top" colspan="4" class="dataTables_empty">No entries found</td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="panel-body pt--100">
                  <h4 class="no-margin">
                     Projects             
                  </h4>
                  <div class="clearfix"></div>
                  <hr class="hr-panel-heading">
                  <div class="mbot15 usernote hide inline-block full-width">
                     <form action="http://leadsmanagement.online/btninfosolution/admin/misc/add_note/1/staff" method="post" accept-charset="utf-8">
                        <input type="hidden" name="csrf_token_name" value="6e7a6faae770de96b7a9d2533cfbd925">                                                  
                        <!--<div class="form-group" app-field-wrapper="description"><label for="description" class="control-label">Note description</label><textarea id="description" name="description" class="form-control" rows="5"></textarea></div> 
                           <button class="btn btn-info pull-right mbot15">Save</button>-->
                     </form>
                  </div>
                  <div class="clearfix"></div>
                  <div class="mtop15">
                     <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer app_dt_empty">
                        <div class="row pt--10" style="width:100%;">
                           <div class="col-md-6">
                              <div class="dataTables_length" id="DataTables_Table_0_length">
                                 <label>
                                    <select name="DataTables_Table_0_length" aria-controls="DataTables_Table_0" class="form-control input-sm">
                                       <option value="10">10</option>
                                       <option value="25">25</option>
                                       <option value="50">50</option>
                                       <option value="100">100</option>
                                       <option value="-1">All</option>
                                    </select>
                                 </label>
                              </div>
                              <div class="dt-buttons btn-group"><a class="btn btn-default buttons-collection btn-default-dt-options" tabindex="0" aria-controls="DataTables_Table_0" href="#"><span>Export</span></a></div>
                           </div>
                           <div class="col-md-6">
                              <div id="DataTables_Table_0_filter" class="dataTables_filter">
                                 <label>
                                    <div class="search-box pull-left">
                                       <form action="#">
                                          <input type="text" name="search" placeholder="Search..." required>
                                          <i class="ti-search"></i>
                                       </form>
                                    </div>
                                 </label>
                              </div>
                           </div>
                           <div id="DataTables_Table_0_processing" class="dataTables_processing panel panel-default" style="display: none;">
                              <div class="dt-loader"></div>
                           </div>
                        </div>
                        <div class="table-responsive">
                           <table class="table dt-table scroll-responsive dt-no-serverside dataTable no-footer" data-order-col="2" data-order-type="desc" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info">
                              <thead>
                                 <tr role="row">
                                    <th width="50%" class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Note activate to sort column ascending">Note</th>
                                    <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Added From activate to sort column ascending">Added From</th>
                                    <th class="sorting_desc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-sort="descending" aria-label="Date Added activate to sort column ascending">Date Added</th>
                                    <th class="sorting not-export" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" aria-label="Options activate to sort column ascending">Options</th>
                                 </tr>
                              </thead>
                              <tbody>
                                 <tr class="odd">
                                    <td valign="top" colspan="4" class="dataTables_empty">No entries found</td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2018. All right reserved. Template by <a href="https://colorlib.com/wp/">Colorlib</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
      <div class="offset-area">
         <div class="offset-close"><i class="ti-close"></i></div>
         <ul class="nav offset-menu-tab">
            <li><a class="active" data-toggle="tab" href="#activity">Activity</a></li>
            <li><a data-toggle="tab" href="#settings">Settings</a></li>
         </ul>
         <div class="offset-content tab-content">
            <div id="activity" class="tab-pane fade in show active">
               <div class="recent-activity">
                  <div class="timeline-task">
                     <div class="icon bg1">
                        <i class="fa fa-envelope"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-check"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Added</h4>
                        <span class="time"><i class="ti-time"></i>7 Minutes Ago</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>You missed you Password!</h4>
                        <span class="time"><i class="ti-time"></i>09:20 Am</span>
                     </div>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="fa fa-bomb"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Member waiting for you Attention</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="ti-signal"></i>
                     </div>
                     <div class="tm-title">
                        <h4>You Added Kaji Patha few minutes ago</h4>
                        <span class="time"><i class="ti-time"></i>01 minutes ago</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg1">
                        <i class="fa fa-envelope"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Ratul Hamba sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Hello sir , where are you, i am egerly waiting for you.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="fa fa-bomb"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="ti-signal"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
               </div>
            </div>
            <div id="settings" class="tab-pane fade">
               <div class="offset-settings">
                  <h4>General Settings</h4>
                  <div class="settings-list">
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Notifications</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch1" />
                              <label for="switch1">Toggle</label>
                           </div>
                        </div>
                        <p>Keep it 'On' When you want to get all the notification.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show recent activity</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch2" />
                              <label for="switch2">Toggle</label>
                           </div>
                        </div>
                        <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show your emails</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch3" />
                              <label for="switch3">Toggle</label>
                           </div>
                        </div>
                        <p>Show email so that easily find you.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show Task statistics</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch4" />
                              <label for="switch4">Toggle</label>
                           </div>
                        </div>
                        <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Notifications</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch5" />
                              <label for="switch5">Toggle</label>
                           </div>
                        </div>
                        <p>Use checkboxes when looking for yes or no answers.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- offset area end -->
      <!-- jquery latest version -->
      <script src="{{asset('public/assets/js/vendor/jquery-2.2.4.min.js')}}"></script>
      <!-- bootstrap 4 js -->
      <script src="{{asset('public/assets/js/popper.min.js')}}"></script>
      <script src="{{asset('public/assets/js/bootstrap.min.js')}}"></script>
      <script src="{{asset('public/assets/js/owl.carousel.min.js')}}"></script>
      <script src="{{asset('public/assets/js/metisMenu.min.js')}}"></script>
      <script src="{{asset('public/assets/js/jquery.slimscroll.min.js')}}"></script>
      <script src="{{asset('public/assets/js/jquery.slicknav.min.js')}}"></script>
      <!-- Start datatable js -->
      <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
      <!-- others plugins -->
      <script src="{{asset('public/assets/js/plugins.js')}}"></script>
      <script src="{{asset('public/assets/js/scripts.js')}}"></script>
   </body>
</html>