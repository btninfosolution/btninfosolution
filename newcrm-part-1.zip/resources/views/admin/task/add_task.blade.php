
<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
   @include('admin/admin_head') 
   <head>
   <style>
   .footer {
          position: fixed;
          padding-right: 300px;
          border-top: 0.1%;
          text-align: center;
          width: 100%;
   }
   div.footer {
          border-top: 0;
           text-align: center;
   }

   </style>
   </head>
   <body class="bg-theme bg-theme1">
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      @include('admin/admin_leftpanel')
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      @include('admin/admin_header')
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
         <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
               <div class="col-sm-9">
                  <h4 class="page-title">Task</h4>
               </div>
               <div class="col-sm-3">
                  <div class="btn-group float-sm-right">
                     <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
                     <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
                     <span class="caret"></span>
                     </button>
                     <div class="dropdown-menu">
                        <a href="javaScript:void();" class="dropdown-item">Action</a>
                        <a href="javaScript:void();" class="dropdown-item">Another action</a>
                        <a href="javaScript:void();" class="dropdown-item">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a href="javaScript:void();" class="dropdown-item">Separated link</a>
                     </div>
                  </div>
               </div>
            </div>
            <!-- End Breadcrumb-->
            <hr>
            <div class="row">
               <div class="col-lg-12">
                  <div class="card">
                     <div class="card-body">
                        <ul class="nav nav-tabs nav-tabs-primary">
                           <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#tabe-1"><i class="icon-home"></i> <span class="hidden-xs">Task Details</span></a>
                           </li>
                        </ul>
                         <form action="{{ url('save-task') }}" class="form-material" id="formData" name="create_task" method="post" >
                        {{csrf_field()}}
                        @if (count($errors) > 0)
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                              @endforeach
                           </ul>
                        </div>
                        @endif
                       <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                             <div class="form-row">
                                
                          <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Subject <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="subject" placeholder="Subject" name="subject" value="{{old('subject')}}">
                                    
                                 </div>
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Hourly Rate </label>
                                    <input type="text" class="form-control" id="hourly_rate" placeholder="Hourly Rate" name="hourly_rate" value="{{old('hourly_rate')}}">
                                   
                                 </div>
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Start Date <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="start_date" placeholder="Start Date"  name="start_date" value="{{old('start_date')}}">
                                    
                                 </div>

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Due Date </label>
                                    <input type="date" class="form-control" id="due_date" placeholder="Due Date" name="due_date" value="{{old('due_date')}}">
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Priority</label>
                                 
                                    <select id="priority" name="priority"class=""style="width:100%" >
                                       <option value='Low'> Low</option>
                                       <option value="Medium" selected='true'>Medium</option>
                                       <option value="High">High</option>
                                       <option value="Urgent">Urgent</option>
                                       
                                    </select>
                                    
                                 </div>
                                
                                 
                                                                 
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Repeat Every</label>
                                    <select id="repeat_every" name="repeat_every"class=""style="width:100%" >
                                       <option value=''></option>
                                       <option value="Week">Week</option>
                                       <option value="2 Weeks">2 Weeks</option>
                                       <option value="1 Month">1 Month</option>
                                       <option value="2 Months">2 Months</option>
                                       <option value="3 Months">3 Months</option>
                                       <option value="6 Months">6 Months</option>
                                       <option value="1 Year">1 Year</option>
                                    </select>
                                    
                                    
                                 </div>

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Related To </label>
                                    <select id="related_to" name="related_to"class=""style="width:100%" >
                                       <option value='Project'>Project</option>
                                       <option value="Invoice">Invoice</option>
                                       <option value="Customer">Customer</option>
                                       <option value="Estimate">Estimate</option>
                                       <option value="Contract">Contract</option>
                                       <option value="Ticket">Ticket</option>
                                       <option value="Expense">Expense</option>
                                       <option value="Lead">Lead</option>
                                       <option value="Proposal">Proposal</option>
                                    </select>
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Staff <span class="text-danger">*</span></label>
                                   
                                    <select id="staff_id" name="staff_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @foreach ($stafflist as $group) 
                                       <option value="{{$group->staff_id}}">{{$group->first_name}} {{$group->last_name}}</option>
                                       @endforeach
                                    </select>
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Tags </label>
                                    <select id="tag_id" name="tag_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @foreach ($taglist as $group) 
                                       <option value="{{$group->tag_id}}">{{$group->tag_name}}</option>
                                       @endforeach
                                    </select>
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Status</label>
                                    <select id="status" name="status"class=""style="width:100%" >
                                       <option value=''>Please select</option>
                                       <option value="1">Not Started</option>
                                       <option value="2">In Progress</option>
                                       <option value="4">Testing</option>
                                       <option value="3">Completed</option>
                                    </select>
                                    
                                    
                                 </div>
                                 
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Description </label>
                                    <textarea type="text" class="form-control" id="description" placeholder="Description" name="description" value="{{old('description')}}"></textarea>
                                    
                                   
                                 </div>
                              </div>
                           </div>
                          
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>



            <!--End Row-->
            <!--End Row-->
             <div class="overlay"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      <div class="footer">
      @include('admin/admin_footer')
     </div>
      <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
      <script type="text/javascript">
         $("#formData").validate({
           rules: {
             category_name: {
               	required:true,
             },
            
            
            
          
           },
         messages: {
          category_name:{
               required:"{{ trans('messages.366') }}",
             } ,
            
            
             
         
           
           }
         });
      </script>
   </body>
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>
