
<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
   @include('admin/admin_head') 
   <body class="bg-theme bg-theme1">
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      @include('admin/admin_leftpanel')
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      @include('admin/admin_header')
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
         <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
               <div class="col-sm-9">
                  <h4 class="page-title">Task</h4>
               </div>
               <div class="col-sm-3">
                  <div class="btn-group float-sm-right">
                     <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
                     <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
                     <span class="caret"></span>
                     </button>
                     <div class="dropdown-menu">
                        <a href="javaScript:void();" class="dropdown-item">Action</a>
                        <a href="javaScript:void();" class="dropdown-item">Another action</a>
                        <a href="javaScript:void();" class="dropdown-item">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a href="javaScript:void();" class="dropdown-item">Separated link</a>
                     </div>
                  </div>
               </div>
            </div>
            <!-- End Breadcrumb-->
            <hr>
            <div class="row">
               <div class="col-lg-12">
                  <div class="card">
                     <div class="card-body">
                        <ul class="nav nav-tabs nav-tabs-primary">
                           <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#tabe-1"><i class="icon-home"></i> <span class="hidden-xs">Task Details</span></a>
                           </li>
                        </ul>
                        <form action="{{ url('update-task') }}" class="form-material" id="formData" name="create_task" method="post" >
                        {{csrf_field()}}
                        @if (count($errors) > 0)
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                              @endforeach
                           </ul>
                        </div>
                        @endif
                        <input type="hidden" id="id" name="id" value="{{$Editdata->task_id}}">
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                
                          <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Subject <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="subject" placeholder="Subject" name="subject" value="{{$Editdata->subject}}">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Hourly Rate </label>
                                    <input type="text" class="form-control" id="hourly_rate" placeholder="Hourly Rate" name="hourly_rate" value="{{$Editdata->hourly_rate}}">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Start Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="start_date" placeholder="Start Date"  name="start_date" value="{{$Editdata->start_date}}">
                                    
                                 </div>

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Due Date </label>
                                    <input type="date" class="form-control" id="due_date" placeholder="Due Date" name="due_date" value="{{$Editdata->due_date}}">
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Priority</label>
                                 
                                    <select id="priority" name="priority"class=""style="width:100%" >
                                       <option value='Low' {{ $Editdata->priority == "Low"  ? 'selected' : ''}}> Low</option>
                                       <option value="Medium" {{ $Editdata->priority == "Medium"  ? 'selected' : ''}} >Medium</option>
                                       <option value="High" {{ $Editdata->priority == "High"  ? 'selected' : ''}} >High</option>
                                       <option value="Urgent" {{ $Editdata->priority == "Urgent"  ? 'selected' : ''}}>Urgent</option>
                                       
                                    </select>
                                    
                                 </div>
                                
                                                                 
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Repeat Every</label>
                                    <select id="repeat_every" name="repeat_every"class=""style="width:100%" >
                                       <option value='' {{ $Editdata->repeat_every == ""  ? 'selected' : ''}}></option>
                                       <option value="Week" {{ $Editdata->repeat_every == "Week"  ? 'selected' : ''}}>Week</option>
                                       <option value="2 Weeks" {{ $Editdata->repeat_every == "2 Weeks"  ? 'selected' : ''}}>2 Weeks</option>
                                       <option value="1 Month" {{ $Editdata->repeat_every == "1 Month"  ? 'selected' : ''}}>1 Month</option>
                                       <option value="2 Months" {{ $Editdata->repeat_every == "2 Months"  ? 'selected' : ''}}>2 Months</option>
                                       <option value="3 Months" {{ $Editdata->repeat_every == "3 Months"  ? 'selected' : ''}}>3 Months</option>
                                       <option value="6 Months" {{ $Editdata->repeat_every == "6 Months"  ? 'selected' : ''}}>6 Months</option>
                                       <option value="1 Year" {{ $Editdata->repeat_every == "1 Year"  ? 'selected' : ''}}>1 Year</option>
                                    </select>
                                    
                                    
                                 </div>

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Related To </label>
                                    <select id="related_to" name="related_to"class=""style="width:100%" >
                                       <option value='Project' {{ $Editdata->related_to == "Project"  ? 'selected' : ''}}>Project</option>
                                       <option value="Invoice" {{ $Editdata->related_to == "Invoice"  ? 'selected' : ''}}>Invoice</option>
                                       <option value="Customer" {{ $Editdata->related_to == "Customer"  ? 'selected' : ''}}>Customer</option>
                                       <option value="Estimate" {{ $Editdata->related_to == "Estimate"  ? 'selected' : ''}}>Estimate</option>
                                       <option value="Contract" {{ $Editdata->related_to == "Contract"  ? 'selected' : ''}}>Contract</option>
                                       <option value="Ticket" {{ $Editdata->related_to == "Ticket"  ? 'selected' : ''}}>Ticket</option>
                                       <option value="Expense" {{ $Editdata->related_to == "Expense"  ? 'selected' : ''}}>Expense</option>
                                       <option value="Lead" {{ $Editdata->related_to == "Lead"  ? 'selected' : ''}}>Lead</option>
                                       <option value="Proposal" {{ $Editdata->related_to == "Proposal"  ? 'selected' : ''}}>Proposal</option>
                                    </select>
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Staff <span class="text-danger">*</span></label>
                                   
                                    <select id="staff_id" name="staff_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @foreach ($stafflist as $group) 
                                       <option value="{{$group->staff_id}}" {{ $Editdata->staff_id == $group->staff_id  ? 'selected' : ''}}>{{$group->first_name}} {{$group->last_name}}</option>
                                       @endforeach
                                    </select>
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Tags </label>
                                    <select id="tag_id" name="tag_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @foreach ($taglist as $group) 
                                       <option value="{{$group->tag_id}}" {{ $Editdata->tag_id == $group->tag_id  ? 'selected' : ''}}>{{$group->tag_name}}</option>
                                       @endforeach
                                    </select>
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Status</label>
                                    <select id="status" name="status"class=""style="width:100%" >
                                       <option value=''>Please select</option>
                                       <option value="1"{{ $Editdata->task_status == "1"  ? 'selected' : ''}}>Not Started</option>
                                       <option value="2"{{ $Editdata->task_status == "2"  ? 'selected' : ''}}>In Progress</option>
                                       <option value="4"{{ $Editdata->task_status == "4"  ? 'selected' : ''}}>Testing</option>
                                       <option value="3"{{ $Editdata->task_status == "3"  ? 'selected' : ''}}>Completed</option>
                                    </select>
                                    
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Description </label>
                                    <textarea type="text" class="form-control" id="description" placeholder="Description" name="description">{{$Editdata->description}}</textarea>
                                    
                                   
                                 </div>
                              </div>
                           </div>
                          
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--End Row-->
            <!--End Row-->
            <div class="overlay"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      @include('admin/admin_footer')
      <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
      <script type="text/javascript">
         $("#formData").validate({
           rules: {
             category_name: {
               	required:true,
             },
            
            
            
          
           },
         messages: {
          category_name:{
               required:"{{ trans('messages.366') }}",
             } ,
            
            
             
         
           
           }
         });
      </script>
   </body>
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>

