<!DOCTYPE html>
<html lang="en">
   @include('admin/admin_head') 
   <body class="bg-theme bg-theme1">
      <!-- start loader -->
      <div id="pageloader-overlay" class="visible incoming">
         <div class="loader-wrapper-outer">
            <div class="loader-wrapper-inner" >
               <div class="loader"></div>
            </div>
         </div>
      </div>
      <!-- end loader -->
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      @include('admin/admin_leftpanel')
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      @include('admin/admin_header')
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
      <div class="container-fluid">
      <div class="row mt-3">
      <h4 class="page-title pull-left">Expense Summary</h4>
      <div class="col-md-12">
         <div class="row" style="padding-top:20px;">
            <!--<button type="button" class="btn btn-primary mb-3">New Customer</button>-->
             <a class="btn btn-primary mb-3" href="{{url('add-expense')}}"></i> New Expense</a>
         </div>
         @include('admin/admin_alert') 
      </div>
      
      <div class="card">
      <div class="card-body">
         <h5 class="card-title">Expense</h5>
         <div class="table-responsive">
            <table class="table footable"  id="dataTable" class="text-center" >
               <thead>
                  <tr>
            
					 <th scope="col">Category</th>
                      <th scope="col">Amount</th>
                       <th scope="col">Name</th>
                        <th scope="col">Expense Date</th>
                         <th scope="col">Customer</th>
                         <th scope="col">Reference</th>
                         <th scope="col">Payment Mode</th>
                         <th scope="col">Action</th>
                  </tr>
               </thead>
               <tbody>
                 <?php $i = 1; ?>
                                    @if (!empty($expenselist))
                                    @foreach($expenselist as $expense) 
                                    <?php   $id= Crypt::encrypt($expense->expense_id );?> 
                                    <tr>
                                       <td>{{$expense->expense_catogory_name}}</td>
                                       <td>{{$expense->amount}}</td>
                                       <td>{{$expense->name}} </td>
                                       <td>{{$expense->expence_date}}</td>

                                       <td>{{$expense->company_name}}</td>
                                       <td>{{$expense->reference}}</td>
                                       <td>{{$expense->payment_mode}}</td>
                           
                                       <td> <a href="{{url('expense-edit').'/'.$id}}" title="Edit" data-toggle="tooltip"><span class="badge badge-pill badge-primary">Edit</span></a>|
									    <a data-id="{{ $expense->is_deleted }}"href="{{ url('delete-record') }}?status_data={{Crypt::encrypt($expense->expense_id.'&tbl_expense&expense_id&'.$expense->is_deleted.'&expense'.'&0') }}" title="Delete" onclick="return confirm('Are you sure you want to delete this Expense ?');" data-toggle="tooltip"><span class="badge badge-pill badge-danger">Delete</span></a> 
									   </td>
                                    </tr>
                                    <?php $i++; ?>
                                    @endforeach
                                    @endif 
               </tbody>
               <tfoot class="hide-if-no-paging">
                  <td colspan="5">
                     <div class="pagination"></div>
                  </td>
               </tfoot>
            </table>
            <!--start overlay-->
            <div class="overlay toggle-menu"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      @include('admin/admin_footer')
      <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
</html>
</body>