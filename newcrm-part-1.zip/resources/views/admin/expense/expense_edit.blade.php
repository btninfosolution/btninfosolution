<!doctype html>
<html class="no-js" lang="en">
   @include('admin/admin_head') 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         @include('admin/admin_leftpanel')
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            @include('admin/admin_header')
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Expense</h4>
                     </div>
                  </div>
                  @include('admin/page_title')
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Add New Expense</a>
                           <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Advance Option</a>
                        </div>
                     </nav>
                     <form action="{{ url('update-expense') }}" class="form-material" id="formData" name="create_expense" method="post" >
                        {{csrf_field()}}
                        @if (count($errors) > 0)
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                              @endforeach
                           </ul>
                        </div>
                        @endif
                        <input type="hidden" id="id" name="id" value="{{$Editdata->expense_id}}">

                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Name</label>
                                    <input type="text" class="form-control" id="name" placeholder="Name" name="name" value="{{$Editdata->name}}">
                                  </div>
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Note<span class="text-danger">*</span></label>
                                    <textarea type="text" class="form-control" id="note" placeholder="Note" name="note">{{$Editdata->note}}</textarea>
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Expense Category</label>
                                    <select id="expense_catogory_id" name="expense_catogory_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @foreach ($expense_catogorylist as $group) 
                                       <option value="{{$group->expense_catogory_id}}" {{ $Editdata->expense_catogory_id == $group->expense_catogory_id  ? 'selected' : ''}}>{{$group->expense_catogory_name}}</option>
                                       @endforeach
                                    </select>
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Expense Date <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="expence_date" placeholder="Expense Date" name="expence_date" value="{{$Editdata->expence_date}}">
                                   
                                 </div>
                                
              
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Amount</label>
                                    <input type="text" class="form-control" id="amount" name="amount" placeholder="Amount" value="{{$Editdata->amount}}">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Customer</label>
                                    <select id="customer_id" name="customer_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       @foreach ($customerlist as $group) 
                                       <option value="{{$group->id}}" {{ $Editdata->customer_id == $group->id  ? 'selected' : ''}}>{{$group->company_name}}</option>
                                       @endforeach
                                    </select>
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                              <div class="form-row">
                                 
                                 
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Currency</label>
                                    <input type="text" class="form-control" id="currency" name="currency" placeholder="Currency" value="{{$Editdata->currency}}" readonly="">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Tax 1</label>
                                    <input type="text" class="form-control" id="tax1" name="tax1" placeholder="Tax 1" value="{{$Editdata->tax1}}" >
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Tax 2</label>
                                    <input type="text" class="form-control" id="tax2" name="tax2" placeholder="Tax 2" value="{{$Editdata->tax2}}" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Payment Mode</label>
                                    <select id="payment_mode" name="payment_mode"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <option value="Bank" {{ $Editdata->payment_mode == "Bank"  ? 'selected' : ''}}>Bank</option>
                                       <option value="Google Pay"  {{ $Editdata->payment_mode == "Google Pay"  ? 'selected' : ''}}>Google Pay</option>
                                    </select>
                                    <!-- <input type="text" class="form-control" id="payment_mode" name="payment_mode" placeholder="Payment Mode" value="{{$Editdata->payment_mode}}"> -->
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Reference</label>
                                    <input type="text" class="form-control" id="reference" name="reference" placeholder="Reference" value="{{$Editdata->reference}}">
                                    
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <button type="submit" class="btn btn-primary next" id="expense_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      @include('admin/admin_footer')
       <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
  $("#formData").validate({
    rules: {
        name: {
          required:true,
      },
      amount: {
          required:true,
          digits:true,
           
      },
     
     
    
    },
  messages: {
      name:{
        required:"{{ trans('messages.600') }}",
      } ,
      amount:{
        required:"{{ trans('messages.601') }}",
        digits:"{{ trans('messages.602') }}",
      } ,
     
      
   
    
    }
  });
</script>
   </body>
</html>