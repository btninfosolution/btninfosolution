<!DOCTYPE html>
<html lang="en">
  @include('admin/admin_head') 


<body class="bg-theme bg-theme1">

   <!-- start loader -->
   <div id="pageloader-overlay" class="visible incoming"><div class="loader-wrapper-outer"><div class="loader-wrapper-inner" ><div class="loader"></div></div></div></div>
   <!-- end loader -->

<!-- Start wrapper-->
 <div id="wrapper">
 
   <!--Start sidebar-wrapper-->
     @include('admin/admin_leftpanel')
   <!--End sidebar-wrapper-->

<!--Start topbar header-->
@include('admin/admin_header')
<!--End topbar header-->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
    
    <div class="mt-3">
      <div id='calendar'></div>
    </div>
			
		<!--start overlay-->
		  <div class="overlay toggle-menu"></div>
		<!--end overlay-->	
			
    </div>
    <!-- End container-fluid-->
   </div><!--End content-wrapper-->
   
  <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
	<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2018 Dashtreme Admin
        </div>
      </div>
    </footer>
	<!--End footer-->
	
	<!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">

      <p class="mb-0">Gaussion Texture</p>
      <hr>
      
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>

      <p class="mb-0">Gradient Background</p>
      <hr>
      
      <ul class="switcher">
        <li id="theme7"></li>
        <li id="theme8"></li>
        <li id="theme9"></li>
        <li id="theme10"></li>
        <li id="theme11"></li>
        <li id="theme12"></li>
		<li id="theme13"></li>
        <li id="theme14"></li>
        <li id="theme15"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->
   
  </div><!--End wrapper-->


  <!-- Bootstrap core JavaScript-->
  
  <script src="{{asset('public/assets/js/jquery.min.js')}}"></script>
  <script src="{{asset('public/assets/js/popper.min.js')}}"></script>
  <script src="{{asset('public/assets/js/bootstrap.min.js')}}"></script>
	
  <!-- simplebar js -->
  <script src="{{asset('public/assets/plugins/simplebar/js/simplebar.js')}}"></script>
  <!-- sidebar-menu js -->
  <script src="{{asset('public/assets/js/sidebar-menu.js')}}"></script>
  
  <!-- Custom scripts -->
  <script src="{{asset('public/assets/js/app-script.js')}}"></script>
  
  <!-- Full Calendar -->
  <script src="{{asset('public/assets/plugins/fullcalendar/js/moment.min.js')}}"></script>
  <script src="{{asset('public/assets/plugins/fullcalendar/js/fullcalendar.min.js')}}"></script>
 <script>
 $(document).ready(function() {



$('#calendar').fullCalendar({

  header: {

    left: 'prev,next today',

    center: 'title',

    right: 'month,agendaWeek,agendaDay'

  },

  defaultDate: '2018-03-12',

  navLinks: true, // can click day/week names to navigate views

  selectable: true,

  selectHelper: true,

  select: function(start, end) {

    var title = prompt('Event Title:');

    var eventData;

    if (title) {

      eventData = {

        title: title,

        start: start,

        end: end

      };

      $('#calendar').fullCalendar('renderEvent', eventData, true); // stick? = true

    }

    $('#calendar').fullCalendar('unselect');

  },

  editable: true,

  eventLimit: true, // allow "more" link when too many events

  events: [
<?php for ($i=0; $i <count($countOfArray); $i++) { ?> 

    {

      title: 'All Day Event',

      start: '2018-03-01'

    },
<?php } ?>

   

  ]

});



});
</script>
	
</body>
</html>
