@extends('layouts/template_pdf')
@section('content')
@if(!empty($consignments))
<table>
    <thead>
        <tr>
            <th>Id</th>
            <th>Date</th>
            <th>Cost</th>
            <th>Customer Name</th>
            <th>Trunsaction Number</th>
            <th>Trunsaction Date</th>
            <th>Trunsaction Amount</th>
        </tr>
    </thead>
    <tbody>
    @php 
    $i=0;
    @endphp
    @foreach($consignments as $consign)
    <tr>
        <td>{{ $consign->consignment_id }}</td>
        <td>{{ date("d-m-Y H:i:s",strtotime($consign->pickup_date_time)) }}</td>
        <td>{{round($consign->payable_cost,2)}}</td>
        <td>{{ucfirst($consign->cust_name)}}</td>
        <td>{{$consign->refund_transaction_number}}</td>
        <td>{{date("d-m-Y",strtotime($consign->refund_date_time))}}</td>
        <td>{{$consign->refund_amount}}</td>
    </tr>
    @if(++$i%45 == 0)
    </tbody>
    </table>
    <div class="page-break"></div>
    <table>
        <tr>
            <th>Id</th>
            <th>Date</th>
            <th>Cost</th>
            <th>Customer Name</th>
            <th>Trunsaction Number</th>
            <th>Trunsaction Date</th>
            <th>Trunsaction Amount</th>
        </tr>
    <tbody>
    @endif
    @endforeach
    </tbody>
</table>
@endif

@endsection