<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <title>{{@$pageTitle}}</title>
        <meta name="description" content="mobile first, app, web app, responsive, admin dashboard, flat, flat ui">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <link rel="stylesheet" href="{{asset('public/assets/admin/css/bootstrap-datepicker.min.css')}}">
        <!--<link rel="stylesheet" href="{{asset('public/assets/admin/css/daterangepicker.css')}}">-->
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/bootstrap.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/bootstrap.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/select2.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/font-awesome.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/font.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/style.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/plugin.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{asset('public/assets/admin/css/owl.theme.default.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/loader.css')}}">
       <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">-->
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/menu-fonts.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/menu-style.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/vertical-menu.min.css')}}">
        <link rel="stylesheet" href="{{asset('public/assets/admin/css/new-custm-menu.css')}}">

        <!--[if lt IE 9]>
            <script src="js/ie/respond.min.js"></script>
            <script src="js/ie/html5.js"></script>
        <![endif]-->

    </head>

<body data-open="click" data-menu="vertical-menu" data-col="2-columns" class="vertical-layout vertical-menu 2-columns fixed-navbar pace-done menu-expanded">
<!-- Loader Start -->
<div class="animationload" style="display: none;">
  <div class="osahanloading"></div>
</div>
<!-- Loader End --> 

<!-- fixed-top-->
    @include('admin/common/header')

<!-- ////////////////////////////////////////////////////////////////////////////-->

    <!-- Left side column. contains the logo and sidebar -->
<<div class="main-menu menu-fixed menu-accordion menu-shadow menu-light" data-scroll-to-active="true">
  <div class="main-menu-content">
  @include('admin/common/sidebar')
  </div>
</div>
<!-- ////////////////////////////////////////////////////////////////////////////-->
<div id="wrapper" class="">
  
	  <div id="page-content-wrapper">
		  <section id="content">
				<section class="main padder">
					<div class="clearfix">
						<h4>{{$pageTitle}}</h4>
						<ul class="breadcrumb">
							<li><a href="#"><!--<i class="fa fa-home"></i>-->{{env('SITE_TITLE')}}</a></li>
							<li class="active">{{$pageTitle}}</li>
						</ul>
					</div>
					@yield('content')

				</section>
		  </section>
	</div>
</div>

<!-- footer -->
<footer id="footer">
  <div class="text-center padder clearfix">
    <p> <small>&copy; {{env("SITE_TITLE")}}{{date('Y')}}</small></p>
      <br>
    </p>
  </div>
</footer>
<!-- / footer -->
<!-- / .modal --> 

		@yield('modal')
		@include('admin/common/footer')
        @yield('extra_js')

    </body>

</html>