<!DOCTYPE html>
<html lang="en">
   <meta http-equiv="content-type" content="text/html;charset=utf-8" />
   <head>
      <meta charset="utf-8" />
      @yield('title')
      <meta content="width=device-width, initial-scale=1.0" name="viewport" />
      <meta name="description" content="City Infra" />
      <meta name="keywords" content="City Infra" />
      <meta name="author" content="" />
      <meta name="MobileOptimized" content="320" />
      <!--start theme style -->
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/animate.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/bootstrap.min.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/meanmenu.css') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/slicknav.min.css') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/font-awesome.min.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/owl.carousel.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/jquery-ui.min.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/venobox/css/venobox.css') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/owl.theme.default.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/flaticon.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/fonts.css') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/camera.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/style.css') }}" />
      <!--<link type="text/css" rel="stylesheet" href="css/style1.css">-->
      <link type="text/css" rel="stylesheet" href="{{ asset('public/assets/web/css/color.css') }}">
      <link rel="stylesheet" type="text/css" href="{{ asset('public/assets/web/css/responsive.css') }}" />
      <link rel="stylesheet" type="text/css" href="{{asset('public/assets/web/select2/dist/css/select2.min.css')}}">
      <style>
         .pricing_section .col-md-4{padding-left:0;padding-right:0;width:31%;}
         .pricing_section .col-md-3{padding-left:0;padding-right:0;width:17%}
         .pricing_cont li{padding: 15px;border-bottom: 1px solid #eee;margin-top:0}
      </style>
      <!-- favicon link-->
      <!--<link rel="shortcut icon" type="image/icon" href="images/favicon.png" />-->
      @yield('custom_css')
   </head>
   <body>
      <!-- preloader Start -->
      <!--<div id="preloader">
         <div id="status">
         
             <img src="images/preloader.gif" id="preloader_image" alt="loader">
         
         </div>
         
         </div>-->
      <!-- tb header Start -->
	  @php use \App\Http\Controllers\web\CmsController; 
 use App\Http\Requests;
 use Illuminate\Http\Request;
 @endphp
@php
    $setting = CmsController::setting_data();
	//print_r($setting);die;
    @endphp
    
      <header>
         <div class="serach-header">
            <div class="searchbox">
               <button class="close">×</button>
               <form>
                  <input type="search" placeholder="Search …">
                  <button type="submit"><i class="fa fa-search"></i></button>
               </form>
            </div>
         </div>
         <div class="topbar inner_topbar">
            <div class="container">
               <div class="row">
                  <div class="topheader_bg topheader_bg_2">
                     <div class="top_header_add top_header_add_2 hidden-xs hidden-sm">
                        <ul>
                           <li><i class="fa fa-phone" aria-hidden="true"></i> {{'('.substr($setting->phone, 0, 3).') '.substr($setting->phone, 3, 3).'-'.substr($setting->phone,6)}}</li>
                           <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i> {{$setting->email}}</a></li>
                        </ul>
                     </div>
                     <!-- Social Icon -->
                     <div class="social_links_wrapper">
                        <div class="social_links">
                           <ul>
                              <li><a href="{{$setting->facebook_link}}"><i class="fa fa-facebook-square"></i></a></li>
                              <li><a href="{{$setting->twitter_link}}"><i class="fa fa-twitter-square"></i></a></li>
                              <li><a href="{{$setting->instagram_link}}"><i class="fa fa-instagram"></i></a></li>
                              <li class="hidden-xs"><a href="{{$setting->youtube_link}}"><i class="fa fa-youtube-square"></i></a></li>
                              <li class="hidden-xs"><a href="{{$setting->pinterest_link}}"><i class="fa fa-pinterest-square"></i></a></li>
                              <li class="dropdown">
                                 <a href="#" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="{{ asset('public/assets/web/images/flag.png')}}" alt="Flag" title="Flag"><!-- <i class="fa fa-caret-down"></i> -->
                                 </a>
                                 <!-- <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" style="overflow-x: hidden;height: 200px;overflow-y: scroll;line-height:34px">
                                    <a href="" class="dropdown-item" data-lang="sq">
                                    
                                    Albanian
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="ar">
                                    
                                    Arabic
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="bg">
                                    
                                    Bulgarian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="ca">
                                    
                                    Catalan
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="zh-CN">
                                    
                                    Chinese (Simplified)
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="zh-TW">
                                    
                                    Chinese (Traditional)
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="hr">
                                    
                                    Croatian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="cs">
                                    
                                    Czech
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="da">
                                    
                                    Danish
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="nl">
                                    
                                    Dutch
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="en">
                                    
                                    English
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="et">
                                    
                                    Estonian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="tl">
                                    
                                    Filipino
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="fi">
                                    
                                    Finnish
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="fr">
                                    
                                    French
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="gl">
                                    
                                    Galician
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="de">
                                    
                                    German
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="el">
                                    
                                    Greek
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="iw">
                                    
                                    Hebrew
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="hi">
                                    
                                    Hindi
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="hu">
                                    
                                    Hungarian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="id">
                                    
                                    Indonesian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="it">
                                    
                                    Italian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="ja">
                                    
                                    Japanese
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="ko">
                                    
                                    Korean
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="lv">
                                    
                                    Latvian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="lt">
                                    
                                    Lithuanian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="mt">
                                    
                                    Maltese
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="no">
                                    
                                    Norwegian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="fa">
                                    
                                    Persian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="pl">
                                    
                                    Polish
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="pt">
                                    
                                    Portuguese
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="ro">
                                    
                                    Romanian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="ru">
                                    
                                    Russian
                                    
                                    </a>
                                    
                                    
                                    
                                    <a href="" class="dropdown-item" data-lang="sr">
                                    
                                    Serbian
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="sk">
                                    
                                    Slovak
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="sl">
                                    
                                    Slovenian
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="es">
                                    
                                    Spanish
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="sv">
                                    
                                    Swedish
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="th">
                                    
                                    Thai
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="tr">
                                    
                                    Turkish
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="uk">
                                    
                                    Ukrainian
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="vi">
                                    
                                    Vietnamese
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="af">
                                    
                                    Afrikaans
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="be">
                                    
                                    Belarusian
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="is">
                                    
                                    Icelandic
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="ga">
                                    
                                    Irish
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="mk">
                                    
                                    Macedonian
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="ms">
                                    
                                    Malay
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="sw">
                                    
                                    Swahili
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="cy">
                                    
                                    Welsh
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="yi">
                                    
                                    Yiddish
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="af">
                                    
                                    Afrikaans
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="be">
                                    
                                    Belarusian
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="is">
                                    
                                    Icelandic
                                    
                                    </a>
                                    
                                    <a href="" class="dropdown-item" data-lang="zu">
                                    
                                    Zulu
                                    
                                    </a> 
                                    
                                    </div> -->
                              </li>
                           </ul>
                        </div>
                        <!-- /.Social Button -->
                        <div class="pst_btn_form hidden-xs hidden-sm">
                           <ul>
                              <li>
                                 <?php
                                    if(session('id'))
                                    
                                    {
                                    
                                    ?>
                                 <a href="{{ url('dashboard') }}">
                                 <i class="fa fa-sign-in"></i>My Account
                                 </a>
                                 <?php
                                    }
                                    
                                    else
                                    
                                    {
                                    
                                    ?>
                                 <a href="{{ url('login') }}">
                                 <i class="fa fa-sign-in"></i>Sign in / Signup
                                 </a>
                                 <?php
                                    }
                                    
                                    ?>
                              </li>
                           </ul>
                        </div>
                        <div class="header_btn header_btn_full visible-xs visible-sm response_add_property">
                           <a href="#">
                              <!--<i class="fa fa-plus"></i>--> Membership
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!--bottom header wrappper start-->
         <div class="transparent-menu inner_menu header-area hidden-menu-bar stick">
            <div class="container">
               <div class="row">
                  <div class="bt_main_menu_wrapper">
                     <div class="main-menu-wrapper main_menu_wrapper_2 clear-fix">
                        <div class="logo float-left">
                           <a href="{{ url('/') }}"><img src="{{ asset('public/assets/web/images/logo.png')}}" alt="LOGO" height="46"></a>
                        </div>
                        <div class="serach-header bt_search_wrapper_respnsive hidden-lg hidden-md">
                           <button class="searchd"><i class="fa fa-search"></i></button>
                           <div class="searchbox">
                              <button class="close">×</button>
                              <form>
                                 <input type="search" placeholder="Search …">
                                 <button type="submit"><i class="fa fa-search"></i></button>
                              </form>
                           </div>
                        </div>
                     </div>
                     <div class="sc_navigation hidden-sm hidden-xs">
                        <!--search -->
                        <nav id="primary-nav" class="dropdown nav_left_margin">
                           <!-- search code end -->
                           <ul class="dropdown menu cart_dropdown_wrapper">
                              <li><a href="{{ url('/') }}" title="">home</a>
                              </li>
                              <li class="dropdown">
                                 <a href="{{ url('buy-your-business') }}" title="">Buy a Business</a>
                                 <ul class="dropdown_header">
                                    <li><a href="{{ url('search-business-to-buy') }}" title=""> Search Business to buy</a>
                                    </li>
                                    <li><a href="{{ url('business-wanted') }}" title="">Business wanted</a>
                                    </li>
                                    <li><a href="{{ url('directory') }}" title="">Directory</a>
                              </li>
                                 </ul>
                              </li>
                              <li><a href="{{ url('buy-franchise') }}" title="">Buy a Franchise</a>
                              </li>
                              
                              <li>
                                 <a href="#" title="">Service on Demand</a>
                                 <ul class="dropdown_header">
                                    <li class=""><a href="{{ url('full-service') }}">Full Service</a></li>
                                    <li class=""><a href="{{ url('buyer-service') }}">Buyer service</a></li>
                                    <li class=""><a href="{{ url('listing-service') }}">Listing Service</a></li>
                                    <li class=""><a href="{{ url('make-an-offer-and-negotiation-service') }}">Make an offer and negotiation service</a></li>
                                    <li class=""><a href="{{ url('due-diligent-service') }}">Due diligent service</a></li>
                                    <li class=""><a href="{{ url('document-review') }}">Document review</a></li>
                                    <li class=""><a href="{{ url('preparation-and-processing-service') }}">Preparation and processing Service</a></li>
                                    <li class=""><a href="{{ url('inventory-service') }}">Inventory service</a></li>
                                    <li class=""><a href="{{ url('permit-and-license-service') }}">Permit and license Service</a></li>
                                    <li class=""><a href="{{ url('walk-thru-service') }}">Walk Thru Service</a></li>
                                 </ul>
                              </li>
                              <li>
                                 <a href="#" title="">How To</a>
                                 <ul class="dropdown_header">
                                    <li class=""><a href="{{ url('pricing') }}">Pricing</a></li>
                                    <li class=""><a href="{{ url('sell-your-business') }}">Sell your business</a></li>
                                    <li class=""><a href="{{ url('buy-your-business') }}">Buy your business</a></li>
                                    <li class=""><a href="{{ url('negotiating') }}">Negotiating</a></li>
                                    <li class=""><a href="{{ url('deal-process') }}">Deal Process</a></li>
                                    <li class=""><a href="{{ url('due-diligence') }}">Due diligence</a></li>
                                 </ul>
                              </li>
                              <!-- <li><a href="{{ url('penny-purchase-lounge') }}">Penny Pincher's Lounge</a></li>-->
                              <li class="dropdown">
                                 <a href="{{ url('penny-purchase-lounge') }}" title="">Penny Pincher's Lounge</a>
                                 <ul class="dropdown_header">
                                    <li><a href="{{ url('search-penny-to-buy') }}" title=""> Search Penny Pincher's to buy</a>
                                    </li>
                                 </ul>
                              </li>
                              <li>
                                 <a href="#" title="">Broker </a>
                                 <ul class="dropdown_header">
                                    <!-- <li class=""><a href="broker-registration.html">Broker Registration</a></li> -->
                                    <li class=""><a href="{{ url('broker-ibbr') }}">Broker Qualification – IBBR certificate</a></li>
                                    <li class=""><a href="{{ url('broker-demand') }}">Service on Demand offer sheet</a></li>
                                    <li class=""><a href="{{ url('broker-obligfrm') }}">Listing evaluation obligation form</a></li>
                                    <li class=""><a href="{{ url('consent-forms') }}">Broker consent form for participating with site</a></li>
                                 </ul>
                              </li>
                              <li><a href="{{ url('blogs') }}" title="">blog</a>
                              </li>
                              <li>
                                 <button class="searchd inner_login"><i class="fa fa-search"></i></button>
                              </li>
                              <li>
                                 <div class="header_btn header_btn_full">
                                    <a href="{{ url('membership') }}"> Membership</a>
                                 </div>
                              </li>
                           </ul>
                        </nav>
                        <!-- Menu -->
                     </div>
                     <!-- /.main-menu-wrapper -->
                     <!-- mobile menu area start -->
                     <div class="mobile-menu-area visible-sm visible-xs">
                        <div class="container">
                           <div class="row">
                              <div class="col-xs-12 cc_menu_top_margin">
                                 <!-- mobile menu start -->
                                 <div class="mobile-menu">
                                    <nav>
                                       <ul class="nav">
                                          <li><a href="{{ url('/') }}" title="">home</a>
                                          </li>
                                          <li class="dropdown">
                                             <a href="buy-ur-business.html" title="">Buy a Business</a>
                                             <ul class="dropdown_header">
                                                <li><a href="search-business.html" title=""> Search Business to buy</a></li>
                                                <li><a href="business-wanted.html" title="">Business wanted</a></li>
                                             </ul>
                                          </li>
                                          <li><a href="buy-franchise.html" title="">Buy a Franchise</a>
                                          </li>
                                          <li>
                                             <a href="#" title="">Service on Demand</a>
                                             <ul class="dropdown_header">
                                                <li class=""><a href="service1.html">Full Service</a></li>
                                                <li class=""><a href="service2.html">Buyer service</a></li>
                                                <li class=""><a href="service3.html">Listing Service</a></li>
                                                <li class=""><a href="service4.html">Make an offer and negotiation service</a></li>
                                                <li class=""><a href="service5.html">Due diligent service</a></li>
                                                <li class=""><a href="service6.html">Document review</a></li>
                                                <li class=""><a href="service7.html">Preparation and processing Service</a></li>
                                                <li class=""><a href="service8.html">Inventory service</a></li>
                                                <li class=""><a href="service9.html">Permit and license Service</a></li>
                                                <li class=""><a href="service10.html">Walk Thru Service</a></li>
                                             </ul>
                                          </li>
                                          <li>
                                             <a href="#" title="">How To</a>
                                             <ul class="dropdown_header">
                                                <li class=""><a href="how-pricing.html">Pricing</a></li>
                                                <li class=""><a href="sell-ur-business.html">Sell your business</a></li>
                                                <li class=""><a href="buy-ur-business.html">Buy your business</a></li>
                                                <li class=""><a href="negotiating.html">Negotiating</a></li>
                                                <li class=""><a href="deal-process.html">Deal Process</a></li>
                                                <li class=""><a href="due-diligence.html">Due diligence</a></li>
                                             </ul>
                                          </li>
                                          <li><a href="penny-lounge.html">Penny Pincher's Lounge</a></li>
                                          <li>
                                             <a href="#" title="">Broker </a>
                                             <ul class="dropdown_header">
                                                <li class=""><a href="broker-registration.html">Broker Registration</a></li>
                                                <li class=""><a href="broker-ibbr.html">Broker Qualification – IBBR certificate</a></li>
                                                <li class=""><a href="broker-demand.html">Service on Demand offer sheet</a></li>
                                                <li class=""><a href="broker-obligfrm.html">Listing evaluation obligation form</a></li>
                                                <li class=""><a href="broker-site.html">Broker consent form for participating with site</a></li>
                                             </ul>
                                          </li>
                                          <li><a href="blog-list.html" title="">blog</a></li>
                                          <li>
                                             <a href="{{ url('login') }}">
                                             <i class="fa fa-sign-in"></i>Sign in / Signup
                                             </a>
                                          </li>
                                       </ul>
                                    </nav>
                                 </div>
                                 <!-- mobile menu end -->
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- mobile menu area end -->
                  </div>
                  <!-- /.main-menu-wrapper -->
               </div>
            </div>
         </div>
         <!--header section end-->
      </header>
      <!-- tb header end -->
      @yield('content')
      <!-- enquiry wrapper start -->
      <div class="dreams-area">
         <div class="container">
            <div class="row">
               <div class="col-lg-9 col-md-9 col-xs-12 col-sm-12">
                  <div class="dreams-title">
                     <h2>
                        do you have any questions , doubts or enquiry ?
                     </h2>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                  <div class="abt_btn enquiry_btn">
                     <ul>
                        <li>
                           <a href="{{ url('contact-us') }}">
                           contact us
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- enquiry wrapper start -->
      <!--footer wrapper start-->
       @include('web/user/footer')
      <div class="close_wrapper">
      </div>
      <!-- section-3 end -->
      <!--footer wrapper end-->
      <!--main js files-->
      <script src="{{ asset('public/assets/web/js/jquery_min.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/bootstrap.min.js') }}"></script>
      <script type="text/javascript" src="{{ asset('public/assets/web/js/plugins.js') }}"></script>
      <script type="text/javascript" src="{{ asset('public/assets/web/js/scripts.js') }}"></script>   
      <script src="{{ asset('public/assets/web/js/jqu_menu.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/jqu_slickmenu.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/jquery.inview.min.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/isotope.pkgd.min.js') }}"></script>
      <script src="{{ asset('public/assets/web/venobox/js/venobox.min.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/jquery.mixitup.min.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/jquery.countTo.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/testimonial.min.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/jquery-ui.min.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/wow.min.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/jquery.easing.1.3.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/owl.carousel.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/camera.min.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/Chart.bundle.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/datepicker.js') }}"></script>
      <script src="{{ asset('public/assets/web/js/custom.js') }}"></script>
      <script src="{{asset('public/assets/web/js/jquery-validation/dist/jquery.validate.min.js')}}"></script>
      <script src="{{asset('public/assets/web/js/jquery-validation/dist/additional-methods.js')}}"></script>
      <script src="{{asset('public/assets/web/select2/dist/js/select2.full.min.js')}}"></script>
      <script src="{{asset('public/assets/web/select2/dist/js/select2.min.js')}}"></script>
      <!--js code-->
      <script>
         $("#range-price").slider({
         
             range: true,
         
             min: 0,
         
             max: 9000,
         
             values: [100, 9000],
         
             slide: function(event, ui) {
         
                 $("#price").val("sq" + ui.values[0] + " - " + " sq" + ui.values[1]);
         
             }
         
         });
         
         
         
         $("#price").val("sq" + $("#range-price").slider("values", 0) +
         
             " - " + " sq" + $("#range-price").slider("values", 1));
         
      </script>
      <script>
         $("#range-price_2").slider({
         
             range: true,
         
             min: 0,
         
             max: 2000,
         
             values: [100, 2000],
         
             slide: function(event, ui) {
         
                 $("#price_2").val("$" + ui.values[0] + " - " + " $" + ui.values[1]);
         
             }
         
         });
         
         
         
         $("#price_2").val("$" + $("#range-price_2").slider("values", 0) +
         
             " - " + " $" + $("#range-price_2").slider("values", 1));
         
      </script>
      <script>
         $("#range-price_5").slider({
         
             range: true,
         
             min: 0,
         
             max: 9000,
         
             values: [100, 9000],
         
             slide: function(event, ui) {
         
                 $("#price_5").val("sq" + ui.values[0] + " - " + " sq" + ui.values[1]);
         
             }
         
         });
         
         
         
         $("#price_5").val("sq" + $("#range-price_5").slider("values", 0) +
         
             " - " + " sq" + $("#range-price_5").slider("values", 1));
         
      </script>
      <script>
         $("#range-price_6").slider({
         
             range: true,
         
             min: 0,
         
             max: 2000,
         
             values: [100, 2000],
         
             slide: function(event, ui) {
         
                 $("#price_6").val("$" + ui.values[0] + " - " + " $" + ui.values[1]);
         
             }
         
         });
         
         
         
         $("#price_6").val("$" + $("#range-price_6").slider("values", 0) +
         
             " - " + " $" + $("#range-price_6").slider("values", 1));
         
         
         $("#range-price_7").slider({
            range: true,
            min: 0,
            max: 2000,
            values: [100, 2000],
            slide: function(event, ui) {
                $("#price_7").val("$" + ui.values[0] + " - " + " $" + ui.values[1]);
            }
         });
         
         $("#price_7").val("$" + $("#range-price_7").slider("values", 0) +
            " - " + " $" + $("#range-price_7").slider("values", 1));
         
         $("#range-price_8").slider({
            range: true,
            min: 0,
            max: 2000,
            values: [100, 2000],
            slide: function(event, ui) {
                $("#price_8").val("$" + ui.values[0] + " - " + " $" + ui.values[1]);
            }
         });
         
         $("#price_8").val("$" + $("#range-price_8").slider("values", 0) +
            " - " + " $" + $("#range-price_8").slider("values", 1));
         
      </script>
      <!-- <script>
         var ctx = document.getElementById("logloss").getContext("2d");
         
         // Global Options:
         
         Chart.defaults.global.defaultFontColor = 'darkgrey';
         
         Chart.defaults.global.defaultFontSize = 12;
         
         
         
         // Data with datasets options
         
         
         
         //'indigo purple crimson tomato khaki teal'
         
         var data = {
         
             labels: [112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129],
         
             datasets: [
         
         
         
                 {
         
                     steppedLine: false,
         
                     label: "elizabeth",
         
                     fill: true,
         
                     // borderColor: 'rgba(139,155,90,1)',
         
                     borderColor: "#b7b7b7",
         
                     borderWidth: 1,
         
                     pointStyle: 'circle',
         
                     pointRadius: 4,
         
                     pointBorderColor: '#b7b7b7',
         
                     pointBackgroundColor: '#b7b7b7',
         
                     data: [0.692317, 0.693087, 0.692808, 0.693024, 0.69354, 0.692314, 0.693095, 0.692827, 0.693513, 0.692313, 0.694447, 0.69375, 0.695148, 0.695035, 0.693672, 0.694544, 0.693816, 0.695199, 0.6926]
         
                 }, {
         
                     steppedLine: false,
         
                     label: "ken",
         
                     fill: true,
         
                     // borderColor: 'rgba(139,155,90,1)',
         
                     borderColor: "#29abff",
         
                     borderWidth: 1,
         
                     pointStyle: 'circle',
         
                     pointRadius: 4,
         
                     pointBorderColor: '#29abff',
         
                     pointBackgroundColor: '#29abff',
         
                     data: [0.69503, 0.694704, 0.693785, 0.694081, 0.693271, 0.693703, 0.693931, 0.691942, 0.692283, 0.69303, 0.693626, 0.692787, 0.693439, 0.69341, 0.693436, 0.693006, 0.691057, 0.690571]
         
                 }
         
             ]
         
         };
         
         
         
         var chart = new Chart(ctx, {
         
             type: 'line',
         
             data: data,
         
         
         
             options: {
         
                 title: {
         
                     fontSize: 20,
         
                     display: false,
         
                     text: ''
         
                 },
         
                 elements: {
         
                     line: {
         
                         tension: 0.000001
         
                     }
         
                 },
         
                 legend: {
         
                     display: false
         
                 },
         
                 //   tooltips: {
         
                 //     callbacks: {
         
                 //        label: function(tooltipItem) {
         
                 //               return tooltipItem.xLabel;
         
                 //        }
         
                 //     }
         
                 // },
         
                 annotation: {
         
                     annotations: [{
         
                         type: 'line',
         
                         mode: 'horizontal',
         
                         scaleID: 'y-axis-0',
         
                         value: 0.693,
         
                         borderColor: 'rgba(255, 255, 255, 1)',
         
                         borderWidth: 1
         
                     }]
         
                 }
         
             }
         
         })
         
         </script> -->
      @yield('custom_js')
   </body>
</html>