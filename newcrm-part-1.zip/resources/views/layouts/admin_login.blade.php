<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>{{env('APP_NAME')}} :: Login</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" type="text/css" href="{{asset('public/assets/admin/css/login/bootstrap.min.css')}}">
		<link rel="stylesheet" type="text/css" href="{{asset('public/assets/admin/css/font-awesome.min.css')}}">
		<link rel="stylesheet" type="text/css" href="{{asset('public/assets/admin/css/login/login.css')}}">
	</head>
	<body class="sign-in">
		<div class="wrapper">		
			<div class="sign-in-page">
				<div class="signin-popup">
					<div class="signin-pop">
						@yield('content')
					</div>
				</div>
			</div>
		</div>
		<script src="{{asset('public/assets/admin/js/jquery.min.js')}}"></script> 
		<script src="{{asset('public/assets/admin/js/jquery.validate.min.js')}}"></script> 

		@yield('extra_js')
	</body>
</html>
