-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2019 at 11:57 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargo_courier_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cca_governerartes`
--

CREATE TABLE `cca_governerartes` (
  `governerartes_id` int(11) NOT NULL,
  `governerartes_name` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime NOT NULL,
  `is_blocked` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cca_governerartes`
--

INSERT INTO `cca_governerartes` (`governerartes_id`, `governerartes_name`, `created_at`, `updated_at`, `deleted_at`, `is_blocked`, `is_deleted`) VALUES
(1, 'Asma Governorate', '2019-08-06 00:00:00', '2019-08-06 00:00:00', '0000-00-00 00:00:00', 0, 0),
(2, 'Jahra Governorate', '2019-08-06 00:00:00', '2019-08-06 00:00:00', '0000-00-00 00:00:00', 0, 0),
(3, 'Ahmadi Governorate', '2019-08-06 00:00:00', '2019-08-06 00:00:00', '0000-00-00 00:00:00', 0, 0),
(4, 'Hawalli Governorate', '2019-08-06 00:00:00', '2019-08-06 00:00:00', '0000-00-00 00:00:00', 0, 0),
(5, 'Mubarak Alkabeer Goverorate', '2019-08-06 00:00:00', '2019-08-06 00:00:00', '0000-00-00 00:00:00', 0, 0),
(6, 'Farwaniya Goverorate', '2019-08-06 00:00:00', '2019-08-06 00:00:00', '0000-00-00 00:00:00', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cca_governerartes`
--
ALTER TABLE `cca_governerartes`
  ADD PRIMARY KEY (`governerartes_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cca_governerartes`
--
ALTER TABLE `cca_governerartes`
  MODIFY `governerartes_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
