-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2019 at 09:32 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargo_courier_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cca_consignments`
--

CREATE TABLE `cca_consignments` (
  `consignment_id` int(11) UNSIGNED NOT NULL,
  `customer_id` int(11) UNSIGNED NOT NULL,
  `manager_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `driver_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `consignment_status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '0=n/a, 1=driver assign',
  `pickup_address` varchar(300) NOT NULL,
  `pickup_latitude` varchar(30) NOT NULL,
  `pickup_longitude` varchar(30) NOT NULL,
  `number_of_delivery` tinyint(2) UNSIGNED NOT NULL DEFAULT '1',
  `consignment_cost` double UNSIGNED NOT NULL DEFAULT '0',
  `coupon_code` varchar(10) NOT NULL DEFAULT '',
  `coupon_amount` double UNSIGNED NOT NULL DEFAULT '0',
  `payable_cost` double NOT NULL,
  `pickup_date_time` datetime NOT NULL,
  `is_blocked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cca_consignments`
--
ALTER TABLE `cca_consignments`
  ADD PRIMARY KEY (`consignment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cca_consignments`
--
ALTER TABLE `cca_consignments`
  MODIFY `consignment_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
