-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2019 at 03:57 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargo_courier_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cca_user_addresses`
--

CREATE TABLE `cca_user_addresses` (
  `user_address_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address_lat` varchar(255) DEFAULT NULL,
  `address_lon` varchar(255) DEFAULT NULL,
  `block` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `avenue` varchar(255) NOT NULL,
  `building_no` varchar(255) NOT NULL,
  `buildinr_type` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is_deleted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cca_user_addresses`
--
ALTER TABLE `cca_user_addresses`
  ADD PRIMARY KEY (`user_address_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
