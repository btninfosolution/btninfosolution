-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2019 at 03:59 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargo_courier_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cca_users`
--

CREATE TABLE `cca_users` (
  `user_id` int(11) UNSIGNED NOT NULL,
  `user_type` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=n/a, 1= admin, 2=sub admin, 3=manager, 4=driver',
  `full_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `phone_no` varchar(10) NOT NULL,
  `country_calling_code` varchar(5) NOT NULL DEFAULT '+965',
  `licence_no` varchar(255) DEFAULT NULL,
  `email` varchar(300) NOT NULL DEFAULT '',
  `password` varchar(300) NOT NULL,
  `parent_user_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `otp` smallint(4) UNSIGNED NOT NULL,
  `is_otp_verified` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `admin_verify_status` tinyint(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT '0=n/a, 1=approved, 2=reject',
  `is_blocked` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cca_users`
--
ALTER TABLE `cca_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cca_users`
--
ALTER TABLE `cca_users`
  MODIFY `user_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
