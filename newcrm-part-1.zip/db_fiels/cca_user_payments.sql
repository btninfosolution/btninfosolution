-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2019 at 09:46 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargo_courier_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cca_user_payments`
--

CREATE TABLE `cca_user_payments` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payer_id` int(11) NOT NULL,
  `pay_amount` float NOT NULL,
  `pay_type` varchar(100) NOT NULL,
  `pay_date` date NOT NULL,
  `is_blocked` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cca_user_payments`
--

INSERT INTO `cca_user_payments` (`payment_id`, `user_id`, `payer_id`, `pay_amount`, `pay_type`, `pay_date`, `is_blocked`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 14, 4, 100, 'cash', '2019-07-04', 0, 0, '2019-07-04', '0000-00-00'),
(2, 14, 0, 246, 'cash', '0000-00-00', 0, 0, '2019-07-04', '2019-07-04'),
(3, 14, 4, 134, 'cheque', '0000-00-00', 0, 0, '2019-07-04', '2019-07-04'),
(4, 14, 4, 32, 'cheque', '2019-07-04', 0, 0, '2019-07-04', '2019-07-04'),
(5, 15, 4, 50, 'cheque', '2019-07-04', 0, 0, '2019-07-04', '2019-07-04'),
(6, 14, 4, 12, 'cheque', '2019-07-03', 0, 0, '2019-07-04', '2019-07-04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cca_user_payments`
--
ALTER TABLE `cca_user_payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cca_user_payments`
--
ALTER TABLE `cca_user_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
