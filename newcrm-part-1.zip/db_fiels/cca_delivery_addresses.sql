-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2019 at 09:33 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargo_courier_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cca_delivery_addresses`
--

CREATE TABLE `cca_delivery_addresses` (
  `delivery_id` int(11) UNSIGNED NOT NULL,
  `consignment_id` int(11) UNSIGNED NOT NULL,
  `address_id` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `drop_off_address` varchar(300) NOT NULL,
  `drop_off_latitude` varchar(30) NOT NULL,
  `drop_off_longitude` varchar(30) NOT NULL,
  `drop_off_distance` decimal(10,0) NOT NULL DEFAULT '0',
  `drop_off_date_time` datetime DEFAULT NULL,
  `drop_off_status` tinyint(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=in process,2=delivered, 3=failed',
  `delivery_comment` varchar(300) NOT NULL DEFAULT '',
  `is_blocked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='consignments delivery addresses';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cca_delivery_addresses`
--
ALTER TABLE `cca_delivery_addresses`
  ADD PRIMARY KEY (`delivery_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cca_delivery_addresses`
--
ALTER TABLE `cca_delivery_addresses`
  MODIFY `delivery_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
