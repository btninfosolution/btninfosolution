<?php $__env->startSection('content'); ?>

<div class="login-box-body">
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
<?php if(!empty($error)): ?>
<div class="alert alert-danger">
<ul>

<li><?php echo e($error); ?></li>

</ul>
</div>
<?php endif; ?>
    

    <form action="<?php echo e(url('Admin/change-password')); ?>" method="post" id="formData1" >
        <?php echo e(csrf_field()); ?>

	
      <div class="form-group has-feedback">
        <input type="number" class="form-control" name="phone_no" id="phone_no" value="<?php echo e($phoneno); ?>" readonly>
        <span class="glyphicon glyphicon-phone form-control-feedback"></span>
      </div>
	  
	  <div class="form-group has-feedback">
        <input type="number" class="form-control" name="otp" id="otp" placeholder="Otp">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
		<span class="otpErr error" style="color: red;"></span>
      </div>
	  <div class="form-group has-feedback">
        <input type="password" class="form-control" name="newpass" id="newpass" placeholder="New Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
		<span class="newpassErr error" style="color: red;"></span>
      </div>
	   <div class="form-group has-feedback">
        <input type="password" class="form-control" name="conpass" id="conpass" placeholder="Confirm Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
		<span class="conpassErr error" style="color: red;"></span>
      </div>

      <div class="row">
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" onclick="return formValidationAdd();"  class="btn btn-primary btn-block btn-flat">Submit</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cus-js'); ?>
<script>
				function formValidationAdd(){
				 var data = new FormData($('#formData1')[0]);	
				 var otp = $("#otp").val();	
				 var newpass = $("#newpass").val();
				 var conpass = $("#conpass").val();
                 $(".otpErr").html("");
              	 $(".otpErr").hide("");
             	  $(".newpassErr").html("");
              	 $(".newpassErr").hide("");
				  $(".conpassErr").html("");
              	 $(".conpassErr").hide("");
             	if(otp==""){
               		$(".otpErr").slideDown('slow');
               		$(".otpErr").html(" otp is required.");
               		$("#otp").focus();
               		return false;
               	}
             	 if(newpass==""){
               		$(".newpassErr").slideDown('slow');
               		$(".newpassErr").html(" Password is required.");
               		$("#newpass").focus();
               		return false;
				   }
			 if( newpass.length < 8){
        $(".newpassErr").slideDown('slow');
        $(".newpassErr").html("Password must be greater than 7 character.");
        $("#newpass").focus();
        return false;
             	}
				 if(conpass==""){
               		$(".conpassErr").slideDown('slow');
               		$(".conpassErr").html(" Confirm Password is required.");
               		$("#conpass").focus();
               		return false;
               	}
				if(conpass!=newpass){
               		$(".conpassErr").slideDown('slow');
               		$(".conpassErr").html(" Password Mismatch.");
               		$("#conpass").focus();
               		return false;
               	}
		
				
				}</script>	
				



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_one', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>