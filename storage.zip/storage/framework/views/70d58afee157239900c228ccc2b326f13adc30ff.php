<?php $__env->startSection('page-css'); ?>
<style>
    .ui-datepicker-calendar {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panle</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header"></div>
        <form action="<?php echo e(url('Admin/monthly-report')); ?>" method="POST" autocomplete="off">
            <div class="box-body">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-3" >
                    <label>Consignment Status</label>
                        <select name="consignment_status"  class="form-control">
                            <option value="-1" selected>Select status</option>
                            <?php if(!empty($status_values)): ?>
                            <?php foreach($status_values as $ky=>$vl): ?>
                                <?php if($ky==$consignment_status): ?>
                                    <option value="<?php echo e($ky); ?>" selected><?php echo e($vl); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($ky); ?>"><?php echo e($vl); ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </select>                
                </div>
                <div class="form-group col-md-3" >
                    <label>Payment Status</label>
                    <select name="is_manager_paid" id="is_manager_paid" class="form-control">
                        <option value="-1" selected>Select status</option>
                        <?php if(!empty($manager_paid_status)): ?>
                        <?php foreach($manager_paid_status as $ky=>$vl): ?>
                            <?php if($ky==$is_manager_paid): ?>
                                <option value="<?php echo e($ky); ?>" selected><?php echo e($vl); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($ky); ?>"><?php echo e($vl); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group col-md-3" >
                    <label>Consingment Type</label>
                    <select name="consignment_type" id="consignment_type" class="form-control">
                        <option value="-1" selected>Select type</option>
                        <?php if(!empty($consignment_types)): ?>
                        <?php foreach($consignment_types as $ky=>$vl): ?>
                            <?php if($ky==$consignment_type): ?>
                                <option value="<?php echo e($ky); ?>" selected><?php echo e($vl); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($ky); ?>"><?php echo e($vl); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group col-md-3" >
                    <label>Month</label>
                    <input type="text" class="form-control" value="<?php echo e($month_of); ?>" name="month_of" id="month_of">
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="filter" value="1">Filter</button>
                <button type="submit" class="btn btn-info" name="filter" value="2" >Reset</button>
                <button type="submit" class="btn btn-warning" name="filter" value="3" >Download</button>
            </div>
        </form>    
    </div>

    <div class="box">
        <div class="box-body">
            <div style="width:100%; overflow-y:auto;">
            <table class="table table-bordered">
                <tr>
                    <th>Consignment Id</th>
                    <th>Consignment Type</th>
                    <th>Consignment Date</th>
                    <th>Consignment Cost</th>
                    <th>Consignment Status</th>
                    <th>Payment Mode</th>
                    <th>Customer Name</th>
                    <th>Admin  Earning</th>
                    <th>Manager  Earning</th>
                    <th>Manager Name</th>
                    <th>Driver Name</th>
                    <th>Manager Earn Status</th>
                    <th>Manager Trunsaction Number</th>
                </tr>
                <?php foreach($consignments as $consign): ?>
                <tr>
                    <td><?php echo e($consign->consignment_id); ?></td>
                    <td><?php echo e(@$consignment_types[$consign->is_schedule]); ?></td>
                    <td><?php echo e(date("d-m-Y H:i:s",strtotime($consign->pickup_date_time))); ?></td>
                    <td><?php echo e(round($consign->payable_cost,2)); ?></td>
                    <td><?php echo e(@$status_values[$consign->consignment_status]); ?></td>
                    <td><?php echo e(@$payment_modes[$consign->transaction_for]); ?></td>
                    <td><?php echo e(ucfirst($consign->cust_name)); ?></td>
                    <td><?php echo e(round($consign->admin_payment_cost,2)); ?></td>
                    <td><?php echo e(round($consign->manager_payment_cost,2)); ?></td>
                    <td><?php echo e($consign->mng_name); ?></td>
                    <td><?php echo e($consign->drv_name); ?></td>
                    <td><?php if($consign->manager_id>0): ?>
                         <?php echo e(@$manager_paid_status[$consign->is_manager_paid]); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                       <?php if($consign->is_manager_paid): ?>
                       <?php echo e($consign->transaction_number); ?>

                       <?php endif; ?>
                    </td>
                </tr>  
                
                <?php endforeach; ?>
            </table>
            </div>
        </div>
        <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$consignments->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
    $(function() {
        $( "#month_of" ).datepicker({
            changeMonth: true,
            changeYear: true,
            //dateFormat: 'yy-mm',
            maxDate:0,
            showButtonPanel: true,
            dateFormat: 'M yy',
            onClose: function(dateText, inst) {
                $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>