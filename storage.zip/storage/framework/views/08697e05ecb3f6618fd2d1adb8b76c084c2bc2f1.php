 <?php if(session('success')): ?>
<div class="callout alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
   <span style="color: green;"><?php echo e(session('success')); ?></span>
</div>
<?php endif; ?>
<?php if(session('danger')): ?>
<div class="callout alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <span style="color: red;"><?php echo e(session('danger')); ?></span>
</div>
<?php endif; ?>