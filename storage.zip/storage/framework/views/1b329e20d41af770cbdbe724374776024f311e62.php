<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/availble-area')); ?>"><i class="fa fa-user-secret"></i> Area List</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
			
           <form action="<?php echo e(url('Admin/addavailblearea')); ?>" method="POST" id="formData1">
		    <?php echo e(csrf_field()); ?>

			<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
		
		
              <div class="box-body">
			  <div class="form-group">
                        <label class="exampleInputEmail1"><?php echo e('Governerartes'); ?>&nbsp; :</label>
                        <!--<div class="form-control" >   -->                  
                            <select  id="govarea"  class="form-control select2"style="width: 100%;" name="govarea" >
                                <option value="">Select Governerartes</option>
                                <?php foreach($governerarea as $val): ?>
                                 <option value="<?php echo e($val->governerartes_id); ?>"><?php echo e($val->governerartes_name); ?></option>
                                <?php endforeach; ?>
                            </select>    
                       <span class="govErr error" style="color: red;"></span>							
                        <!--</div>-->
                    </div>
              <div class="form-group"  id="pickup_address_div">
                  <label for="exampleInputEmail1">Available Area</label>
                  <input type="text" class="form-control"  id="pickup_address" name="pickup_address" placeholder="Area Name">
				  <span class="addressErr error" style="color: red;"></span>
                </div>
			 
                <div class="form-group" >
                  <label >Area Radius(km)</label>
                  <input type="text" class="form-control" id="radius" name="radius" placeholder="Enter Radius">
				  <span class="radiusErr error" style="color: red;"></span>
                </div>
                
				<input type="hidden"   id="pickup_latitude" name="pickup_latitude" >
				<input type="hidden"   id="pickup_longitude" name="pickup_longitude" > 
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  onclick="return formValidationAdd();"class="btn btn-primary">Submit</button>
                <button type="reset"  class="btn btn-primary">Reset</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
          </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('google_api_key')); ?>&libraries=places"></script>
<script type="text/javascript">
	$(document).ready(function(){
		using_autocomplete();
	});
	

	function formValidationAdd(){			
		var data = new FormData($('#formData1')[0]);
		var address = $("#pickup_address").val();
		var govarea = $("#govarea").val();
    var latitude = $("#pickup_latitude").val();
		var radius = $("#radius").val();
		$(".govErr").html("");
		$(".addressErr").html("");
		//$(".addressErr").hide("");
		$(".radiusErr").html("");
	//	$(".radiusErr").hide("");
	if(govarea==0){
			//$(".addressErr").slideDown('slow');
			$(".govErr").html("Select Governerartes.").show();
			$(".addressErr").html("Enter Availble Area.").show();
			//$(".radiusErr").slideDown('slow');
			$(".radiusErr").html("Enter Availble Area Radius.").show();
			$("#govarea").focus();
			return false;
		}

		if(address==""){
			//$(".addressErr").slideDown('slow');
			$(".addressErr").html("Enter Availble Area.").show();
			//$(".radiusErr").slideDown('slow');
			$(".radiusErr").html("Enter Availble Area Radius.").show();
			$("#pickup_address").focus();
			return false;
		}
    if(latitude==""){
			//$(".addressErr").slideDown('slow');
			$(".addressErr").html("Please select correct address.").show();
			$(".radiusErr").html("Enter Availble Area Radius.").show();
			$("#pickup_address").focus();
			return false;
		}
        if(radius==""){
			//$(".radiusErr").slideDown('slow');
			$(".radiusErr").html("Enter Availble Area Radius.").show();
			$("#radius").focus();
			return false;
		}
    if(isNaN(radius)){
			//$(".radiusErr").slideDown('slow');
			$(".radiusErr").html("Plesae enter valid no.").show();
			$("#radius").focus();
			return false;
		}
    if(radius == 0){
			//$(".radiusErr").slideDown('slow');
			$(".radiusErr").html("Radius always gretaer than 0.").show();
			$("#radius").focus();
			return false;
		}
    if(radius >20){
			//$(".radiusErr").slideDown('slow');
			$(".radiusErr").html("Radius always less than 20 Km.").show();
			$("#radius").focus();
			return false;
		}
		
		
	
		
	}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>