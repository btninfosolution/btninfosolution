<div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="index.html"><img src="<?php echo e(asset('public/assets/images/icon/btnlogo.png')); ?>" alt="logo"></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
						<?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'customer'||$segment == 'add-customer'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('customer')); ?>"><i class="fa fa-user"></i> <span>Customers</span>
						  </a>
						  </li>
                          
                          
                         
                          
                          <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>Master</span></a>
                                <ul class="collapse">
                                <li class="<?php if($segment == 'group'||$segment == 'add-group'||$segment == 'group-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('group')); ?>"><i class="fa fa-list-alt"></i> <span>Group</span>
						  </a>
						  </li>
                          <li class="<?php if($segment == 'tags'||$segment == 'add-tags'||$segment == 'tag-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('tags')); ?>"><i class="fa fa-list-alt"></i> <span>Tags</span>
						  </a>
						  </li>
                          <li class="<?php if($segment == 'tax'||$segment == 'add-tax'||$segment == 'tax-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('tax')); ?>"><i class="fa fa-list-alt"></i> <span>Tax Rate</span>
						  </a>
						  </li>
                          <li class="<?php if($segment == 'item'||$segment == 'add-item'||$segment == 'item-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('item')); ?>"><i class="fa fa-list-alt"></i> <span>Items</span>
						  </a>
						  </li>
                                    
                                </ul>
                            </li>
                          
                          
                          <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>Contract</span></a>
                                <ul class="collapse">
                                <li class="<?php if($segment == 'contract-type'||$segment == 'add-contract'||$segment == 'contract-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('contract-type')); ?>"><i class="fa fa-list-alt"></i> <span>Contract Type</span>
						  </a>
						  </li>
                          <li class="<?php if($segment == 'contractm'||$segment == 'add-contractm'||$segment == 'contractm-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('contractm')); ?>"><i class="fa fa-list-alt"></i> <span>Contract</span>
						  </a>
						  </li>
                                    
                                </ul>
                            </li>
                          
                          
                          
                          <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>Expense</span></a>
                                <ul class="collapse">
                                <li class="<?php if($segment == 'expense-category'||$segment == 'add-expense-category'||$segment == 'expense-category-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('expense-category')); ?>"><i class="fa fa-list-alt"></i> <span>Expense Category</span>
						  </a>
						  </li>
                          <?php if(session('user_type')==1): ?>
                          <li class="<?php if($segment == 'expense'||$segment == 'add-expense'||$segment == 'expense-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('expense')); ?>"><i class="fa fa-list-alt"></i> <span>Expense</span>
						  </a>
						  </li>
                          <?php endif; ?>
                                    
                                </ul>
                            </li>
                          
                          
                          <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>Leads</span></a>
                                <ul class="collapse">
                                <li class="<?php if($segment == 'status'||$segment == 'add-status'||$segment == 'status-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('status')); ?>"><i class="fa fa-list-alt"></i> <span>Lead Status</span>
						  </a>
						  </li>
                          <li class="<?php if($segment == 'sources'||$segment == 'add-sources'||$segment == 'sources-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('sources')); ?>"><i class="fa fa-list-alt"></i> <span>Lead Sources</span>
						  </a>
						  </li>
                          <li class="<?php if($segment == 'leads'||$segment == 'add-leads'||$segment == 'leads-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('leads')); ?>"><i class="fa fa-list-alt"></i> <span>Leads</span>
						  </a>
						  </li>
                                    
                                </ul>
                            </li>
                        
                          <li class="<?php if($segment == 'task'||$segment == 'add-task'||$segment == 'task-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('task')); ?>"><i class="fa fa-list-alt"></i> <span>Task</span>
						  </a>
						  </li>
                          <?php if(session('user_type')==1): ?>
                          <li class="<?php if($segment == 'log-history'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('log-history')); ?>"><i class="fa fa-list-alt"></i> <span>Log history</span>
						  </a>
						  </li>
                          <?php endif; ?>
                          <li class="<?php if($segment == 'staff'||$segment == 'add-staff'||$segment == 'staff-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('staff')); ?>"><i class="fa fa-list-alt"></i> <span>Staff</span>
						  </a>
						  </li>
                          <?php if(session('user_type')==1): ?>
                          <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard"></i><span>Proposal</span></a>
                                <ul class="collapse">
                                    <li class="<?php if($segment == 'proposal'||$segment == 'add-proposal'){ echo 'active';} ?>" ><a href="<?php echo e(url('lead-proposal')); ?>">Lead Proposal</a></li>
                                    <li><a href="<?php echo e(url('customer-proposal')); ?>">Customer Proposal</a></li>
                                    
                                </ul>
                            </li>
                            <?php endif; ?>
                           <!--   <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Sidebar
                                        Types
                                    </span></a>
                                <ul class="collapse">
                                    <li><a href="index.html">Left Sidebar</a></li>
                                    <li><a href="index3-horizontalmenu.html">Horizontal Sidebar</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Charts</span></a>
                                <ul class="collapse">
                                    <li><a href="barchart.html">bar chart</a></li>
                                    <li><a href="linechart.html">line Chart</a></li>
                                    <li><a href="piechart.html">pie chart</a></li>
                                </ul>
                            </li>-->
                           
                            
                        </ul>
                    </nav>
                </div>
            </div>
        </div>