<!doctype html>
<html class="no-js" lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Lead</h4>
                     </div>
                  </div>
				  <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  
               </div>
            </div>
            <!-- page title area end -->
             <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Lead Details</a>
                           
                        </div>
                     </nav>
                     <form action="<?php echo e(url('update-leads')); ?>" class="form-material" id="formData" name="create_leads" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
						  <input type="hidden" id="id" name="id" value="<?php echo e($Editdata->leads_id); ?>">
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                 
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Status<span class="text-danger">*</span></label>
                                    <select id="status" name="status"class=""style="width:100%" >
                                       <option value="<?php echo e($Editdata->leads_status); ?>" selected='true'>Please Select </option>
                                       <?php foreach($leadslist as $status): ?> 
									    <option value="<?php echo e($status->leads_status); ?>" <?php echo e(( $status->leads_status == $Editdata->leads_status ) ? 'selected': ''); ?> ><?php echo e($status->status_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
									</div>
								 
								 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Source<span class="text-danger">*</span></label>
                                    <select id="sources" name="sources"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($sourcelist as $sources): ?> 
                                       <option value="<?php echo e($sources->sources_id); ?>" <?php echo e(( $sources->sources_id == $Editdata->leads_source ) ? 'selected': ''); ?>><?php echo e($sources->sources_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                 </div>
							  
							  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Tags</label>
                                    <select id="tag" name="tag"class=""style="width:100%" >
                                       <option value="<?php echo e($Editdata->tag_id); ?>" selected='true'>Please Select </option>
                                       <?php foreach($taglist as $tag): ?> 
                                       <option value="<?php echo e($tag->tag_id); ?>" <?php echo e(( $tag->tag_id == $Editdata->tag_id ) ? 'selected': ''); ?>><?php echo e($tag->tag_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                 </div>
							  
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Assigned</label>
                                    <select id="staff" name="staff"class=""style="width:100%" >
                                    <option value='' selected='true'>Please Select </option>
                                      <?php if(!empty($stafflist)): ?>
                                       <?php foreach($stafflist as $staff): ?> 
                                       <option value="<?php echo e($staff->staff_id); ?>" <?php echo e(( $staff->staff_id == $Editdata->leads_assigned ) ? 'selected': ''); ?>><?php echo e($staff->first_name); ?> <?php echo e($staff->last_name); ?></option>
                                       <?php endforeach; ?>
                                       <?php endif; ?>
                                       </select>
                                 </div>
							  
								 
								 
								<div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="name" value="<?php echo e($Editdata->name); ?>" placeholder="Name" name="name">
                                  </div>
								  
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Address</label>
                                    <input type="text" class="form-control" id="address" value="<?php echo e($Editdata->address); ?>" placeholder="address" name="address">
                                  </div>
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Company</label>
                                    <input type="text" class="form-control" id="company" value="<?php echo e($Editdata->company); ?>" placeholder="company" name="company">
                                  </div>
								  
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Position</label>
                                    <input type="text" class="form-control" id="position" value="<?php echo e($Editdata->position); ?>" placeholder="position" name="position">
                                  </div>
								  
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">City</label>
                                    <input type="text" class="form-control" id="city" value="<?php echo e($Editdata->city); ?>" placeholder="city" name="city">
                                  </div>
								  
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Email</label>
                                    <input type="text" class="form-control" id="email" value="<?php echo e($Editdata->email); ?>" placeholder="email" name="email">
                                  </div>
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">State</label>
                                    <input type="text" class="form-control" id="state" value="<?php echo e($Editdata->state); ?>" placeholder="state" name="state">
                                  </div>
								  
								   <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Country</label>
                                    <input type="text" class="form-control" id="country" value="<?php echo e($Editdata->country); ?>" placeholder="country" name="country">
                                  </div>
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Website</label>
                                    <input type="text" class="form-control" id="website" value="<?php echo e($Editdata->website); ?>" placeholder="website" name="website">
                                  </div>
								  
								 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Phone</label>
                                    <input type="text" class="form-control" id="phone" value="<?php echo e($Editdata->phone); ?>" placeholder="phone" name="phone">
                                  </div>
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Zip Code</label>
                                    <input type="text" class="form-control" id="zipcode" value="<?php echo e($Editdata->zipcode); ?>" placeholder="zipcode" name="zipcode">
                                  </div> 
								  
								
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Description</label>
                                    <textarea id="description" name="description"    class="form-control" rows="4"><?php echo e($Editdata->description); ?></textarea>
								 </div> 

                 <div class="col-md-6 mb-3">
                    <label for="validationCustom03">Add As Customer</label>
                       <?php if($Editdata->add_as_user == '1'): ?>
                      <input type="checkbox" id="add_as_user" name="add_as_user" value="<?php echo e($Editdata->add_as_user); ?>" onclick="return false;" <?php echo e(( $Editdata->add_as_user == '1' ) ? 'checked': ''); ?>>
                      <?php else: ?>
                      <input type="checkbox" id="add_as_user" name="add_as_user" value="1">
                      <?php endif; ?>
                      <input type="hidden" id="check_as_user" name="check_as_user" value="<?php echo e($Editdata->add_as_user); ?>">


                 </div> 
								  
								  
								  
                              </div>
                           </div>
                           
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     
       <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
   $("#formData").validate({
    rules: {
        name: {
        	required:true,
      },
     
     status: {
		 required:true,
      },
	  
	  sources: {
		 required:true,
      },
    },
  messages: {
    name:{
        required:"<?php echo e(trans('messages.386')); ?>",
      } ,
      
      status: {
		 required:"<?php echo e(trans('messages.387')); ?>",
      },
      
	 sources:{
		 required:"<?php echo e(trans('messages.388')); ?>",
      },
      
    
    }
  });
</script>
   </body>
</html>