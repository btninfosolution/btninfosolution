<?php $__env->startSection('page-css'); ?>
<style rel="stylesheet/text">
.msg_err {
  color:red;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small> Of <?php echo e($manager->full_name); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/managers')); ?>"><i class="fa fa-user-secret"></i> Managers</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $manager_id = Crypt::encrypt($manager->user_id);?>

        <div class="box">
            <div class="box-header"></div>
            <form action="<?php echo e(url('Admin/manager-consignment-list/'.$manager_id)); ?>" method="POST" autocomplete="off">
                <div class="box-body">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group col-md-3" >
                        <label>Consignment Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="-1" selected>Select status</option>
                                <?php if(!empty($status_values)): ?>
                                <?php foreach($status_values as $ky=>$vl): ?>
                                    <?php if($ky==$status): ?>
                                        <option value="<?php echo e($ky); ?>" selected><?php echo e($vl); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($ky); ?>"><?php echo e($vl); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </select>                
                    </div>
                    
                    <div class="form-group col-md-3" >
                        <label>Payment Status</label>
                        <select name="is_manager_paid" id="is_manager_paid" class="form-control">
                            <option value="-1" selected>Select status</option>
                            <?php if(!empty($manager_paid_status)): ?>
                            <?php foreach($manager_paid_status as $ky=>$vl): ?>
                                <?php if($ky==$is_manager_paid): ?>
                                    <option value="<?php echo e($ky); ?>" selected><?php echo e($vl); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($ky); ?>"><?php echo e($vl); ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-3" >
                        <label>Date From</label>
                        <input type="text" class="form-control" value="<?php echo e($date_from); ?>" id="date_from" name="date_from" placeholder="Enter From Date">
                    </div>
                    <div class="form-group col-md-3" >
                        <label>Date To</label>
                        <input type="text" class="form-control" value="<?php echo e($date_to); ?>" id="date_to" name="date_to" placeholder="Enter To Date">
                    </div>
                </div>
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary" name="filter" value="1">Filter</button>
                    <button type="submit" class="btn btn-info" name="filter" value="2" >Reset</button>
                </div>
            </form>    
        </div>

        <div class="box">
            <button type="button" class="btn btn-sm btn-warning pull-right" id="assign_payment">Assign Payment</button>
            <div class="box-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Consignment Id</th>
                        <th>Customer Name</th>
                        <th>Pickup Date</th>
                        <th>Consignment Status</th>
                        <th>Manager Received</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    <?php foreach($consignments as $consign): ?>
                    <tr>
                        <td><?php echo e($consign->consignment_id); ?></td>
                        <td><?php echo e(ucfirst($consign->cust_name)); ?></td>
                        <td><?php echo e(date("d-m-Y H:i:s",strtotime($consign->pickup_date_time))); ?></td>
                        <td><?php echo e(@$status_values[$consign->consignment_status]); ?></td>
                        <td><?php echo e($consign->manager_payment_cost); ?></td>
                        <td><?php if($consign->is_manager_paid): ?>
                                Paid
                            <?php else: ?>
                                Unpaid
                            <?php endif; ?>
                        </td>
                        <?php $consignment_id = Crypt::encrypt($consign->consignment_id);?>
                        <td>
                            <?php if(!$consign->is_manager_paid): ?>
                                <input type="checkbox" name="consignment" class="payment_consignment" value="<?php echo e($consign->consignment_id); ?>" data-amount="<?php echo e($consign->manager_payment_cost); ?>">
                            <?php endif; ?>
                        </td>
                    </tr>  
                    
                    <?php endforeach; ?>
                </table>
            </div>
            <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$consignments->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

<!-- modal section --> 
    <div class="modal fade" id="modal-payment">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">You will be paid to <span id="paidAmount"></span></h4>
                </div>
                <form method="POST" id="consignemntpayment" action="<?php echo e(url('Admin/manager-consignment-payment-update/'.$manager_id)); ?>">
                <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <label >Transaction Number<span class="text-danger">*</span></label>
                            <input type="text" name="transaction_number" class="form-control"  placeholder="Enter Transaction Number">
                            <span id="err-transaction_number" class="msg_err"></span>
                        </div>
                        <input type="hidden" name="consignment_ids" id="consignment_ids" class="form-control">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<!-- end modal --> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
    $(function() {
        $( "#date_from" ).datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'yy-mm-dd',
            maxDate:0,
        });
        $( "#date_to" ).datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'yy-mm-dd',
            maxDate:0,
        });
    });
    $(document).ready(function(){
        $("#assign_payment").bind("click",function(e){
            e.preventDefault();
            var len = $(".payment_consignment:checked").length;
            if(len > 0){
                $("#consignment_ids").val('');
                let consignment_ids='';
                let total_amount=0;
                $("#paidAmount").html('');
                $.each($(".payment_consignment:checked"),function(i,item){
                    if(consignment_ids.length==0){
                        consignment_ids = $(item).val();
                    }
                    else{
                        consignment_ids +=","+$(item).val();
                    }
                    total_amount = total_amount+parseInt($(item).data('amount'));
                });
                $("#paidAmount").html(' amount '+total_amount);
                $("#consignment_ids").val(consignment_ids);
                $("#modal-payment").modal("show");
            }
            else{
                alert("Please choose atleast one consigment for assign payment details");
            }
        });
        $("#consignemntpayment").validate({
            rules:{
                transaction_number:{
                    required:true,
                    maxlength:20,
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>