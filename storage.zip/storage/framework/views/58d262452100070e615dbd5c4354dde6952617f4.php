<div class="list-group">
                                    <a href="<?php echo e(url('customer-detail').'/'.$enc_type); ?>" class="list-group-item list-group-item-action">
                                    <i class="fa fa-user"></i>&nbsp;
                                    Profile</a>
                                    
                                    <a href="<?php echo e(url('contact-detail').'/'.$id); ?>" class="list-group-item list-group-item-action">
                                    <i class="fa fa-phone"></i>&nbsp;
                                    Contacts</a>
                                    
                                    <a href="<?php echo e(url('note-detail').'/'.$id); ?>" class="list-group-item list-group-item-action">
                                    <i class="ti-layout-sidebar-left"></i>&nbsp;
                                    Notes</a>
                                    
                                    <a href="<?php echo e(url('invoice-detail').'/'.$id); ?>" class="list-group-item list-group-item-action">
                                    <i class="fa fa-file"></i>&nbsp;
                                    Invoice</a>
                                    
                                    
                                     <a href="<?php echo e(url('payment-detail').'/'.$id); ?>" class="list-group-item list-group-item-action">
                                    <i class="fa fa-money"></i>&nbsp;
                                    Payment</a>
                                    
                                    <a href="<?php echo e(url('statement-detail').'/'.$id); ?>" class="list-group-item list-group-item-action">
                                    <i class="fa fa-file"></i>&nbsp;
                                    Statement</a>
                                    
                                    <a href="<?php echo e(url('proposal-detail').'/'.$id); ?>" class="list-group-item list-group-item-action">
                                    <i class="ti-layout-sidebar-left"></i>&nbsp;
                                    Proposal</a>
                                    
                                   
                                    
                                   
                                </div>