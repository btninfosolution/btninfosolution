<?php $__env->startSection('page-css'); ?>
<style>
label.error {
  color:red;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
<form action="<?php echo e(url('Admin/managers')); ?>" method="POST"  id="user_filter" >
<?php echo e(csrf_field()); ?>

<div class="box-body">
    <div class="form-group col-md-4">
                    <label >Phone or Email <span class="text-danger">*</span></label>
                    <input type="text" name="keyword" id="keyword"  class="form-control"  placeholder="Enter Phone Number Or Email" value="<?php if(isset($keyword)): ?><?php echo e($keyword); ?><?php endif; ?>">

    </div>
</div>
    <div class="box-footer">
                    <button type="submit"   class="btn btn-primary">Filter</button>
                    <button type="button" id="reset_btn"  class="btn btn-primary">Reset</button>
    </div>

</form>
</div>
    <div class="row">
        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Name</th>
                        <th>Phone Number</th>
                        <th>Email</th>
                        <th>Company Name</th>
                        <th>Admin Commision</th>
                        <th>Admin Service Fees</th>
                        <th>Register at</th>
                        <th>Status</th>
                        <th>Approval Status</th>
                        <th>Documents</th>
                        <th>Action</th>
                    </tr>
                    <?php $no = ($managers->currentpage()-1)* $managers->perpage() + 1; ?>
                    <?php foreach($managers as $manager): ?>
                    <tr>
                        <td><?php echo e($no); ?></td>
                        <td><?php echo e(ucfirst($manager->full_name)); ?></td>
                        <td><?php echo e($manager->phone_no); ?></td>
                        <td><?php echo e($manager->email); ?></td>
                        <td><?php echo e(ucfirst($manager->company_name)); ?></td>
                        <td><?php echo e($manager->admin_commision); ?></td>
                        <td><?php echo e($manager->admin_servicefees); ?></td>
                        <td><?php echo e(date("d-m-Y H:i:s",strtotime($manager->created_at))); ?></td>
                        <td><?php if($manager->is_blocked == 1): ?> Blocked <?php else: ?> Unblocked <?php endif; ?></td>
                        <td><?php if($manager->admin_verify_status == 1): ?> Approved <?php elseif($manager->admin_verify_status == 2): ?> Reject <?php else: ?> Pending <?php endif; ?></td>
                        <td><?php if($manager->is_driver): ?>
                            <?php if(!empty($manager->driver_license_path)): ?>
                                <a href="javascript:void(0);" class="show-document" data-link="<?php echo e(url('public/uploads/driving_license/'.$manager->driver_license_path)); ?>">License</a>
                            <?php endif; ?>
                        <?php endif; ?></td>
                        <?php $manager_id = Crypt::encrypt($manager->user_id);?>
                        <td>
                            <a href="<?php echo e(url('Admin/edit-manager').'/'.$manager_id); ?>" data-toggle="tooltip" title="Edit">
                                <span class="glyphicon glyphicon-pencil"></span>
                            </a>

                            <a href="<?php echo e(url('Admin/delete-manager').'/'.$manager_id.'/'.$manager->user_type); ?>" data-toggle="tooltip" title="Delete" onclick="return confirm('Are you sure you want to delete this user ?');">
                                <span class="glyphicon glyphicon-trash"></span>  
                            </a>
                            <?php if($manager->is_blocked == 1): ?>
                            <a href="<?php echo e(url('Admin/block-manager').'/'.$manager_id.'/'.$manager->user_type.'/0'); ?>" data-toggle="tooltip" title="Unblocked" onclick="return confirm('Are you sure you want to Unblocked this user ?');">
                            <span class="glyphicon glyphicon-ban-circle"></span>
                            </a>
                            <?php else: ?>
                            <a href="<?php echo e(url('Admin/block-manager').'/'.$manager_id.'/'.$manager->user_type.'/1'); ?>" data-toggle="tooltip" title="Blocked" onclick="return confirm('Are you sure you want to blocked this user ?');">
                            <span class="glyphicon glyphicon-check"></span>
                            </a>
                            <?php endif; ?>
                            <?php if($manager->admin_verify_status == 0): ?>
                            <a href="<?php echo e(url('Admin/approve-manager').'/'.$manager_id.'/'.$manager->user_type.'/1'); ?>" data-toggle="tooltip" title="Approve" onclick="return confirm('Are you sure you want to Approved this user ?');">
                            <span class="glyphicon glyphicon-ok"></span>
                            </a>
                        
                            <a href="<?php echo e(url('Admin/approve-manager').'/'.$manager_id.'/'.$manager->user_type.'/2'); ?>" data-toggle="tooltip" title="Reject" onclick="return confirm('Are you sure you want to Reject this user ?');">
                            <span class="glyphicon glyphicon-remove"></span>
                            </a>
                            <?php endif; ?>
                            <a href="<?php echo e(url('Admin/driver-list').'/'.$manager_id); ?>" data-toggle="tooltip" title="Driver List"><span class="glyphicon glyphicon-th-list"></span></a>
                            <a href="<?php echo e(url('Admin/manager-consignment-list').'/'.$manager_id); ?>" data-toggle="tooltip" title="Consignment List"><span class="glyphicon glyphicon-list-alt"></span></a>
                            <a href="<?php echo e(url('Admin/manager-payment-list').'/'.$manager_id); ?>" data-toggle="tooltip" title="Payment History"><span class="glyphicon glyphicon-usd"></span></a>

                        </td>
                        
                    </tr>  
                    <?php $no++; ?>
                    <?php endforeach; ?>
                   
                </table>
                
            </div>
            <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$managers->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

<!-- document viewer modal section --> 
<div class="modal fade" id="document-viwer">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <embed id="fileviwercontant" src="" width="100%;" height="100%;"/>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary download">Download</button>
            </div>
        </div>
    </div>
</div>
<!-- end viwer modal --> 

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
    var downloadurl = "<?php echo e(url('Admin/file-download?file_path=')); ?>";
    $(document).ready(function(){
        $(".show-document").bind('click',function(e){
            e.preventDefault();
            let fileLink = $(this).data('link');
            $("#fileviwercontant").attr('src','');
            if(fileLink.length > 0){
                $("#fileviwercontant").attr('src',fileLink);
            }
            $("#document-viwer").modal('show');
        });
        $(".download").bind('click',function(e){
            let fileLink = $("#fileviwercontant").attr('src');
            if(fileLink.length > 0){
                let dlink=downloadurl+fileLink;
                window.open(dlink);
            }
        });
    });
$("#user_filter").validate({
    rules: {
        keyword: "required",
    }
});

$("#reset_btn").click(function(){
    //$("#user_filter")[0].reset();
    $("#keyword").val("");
    window.location.href = "<?php echo e(url('Admin/managers')); ?>";
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>