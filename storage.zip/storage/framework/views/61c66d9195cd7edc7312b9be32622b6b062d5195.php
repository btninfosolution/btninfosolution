<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <head>
   <style>
  .footer {
          position: fixed;
          padding-right: 300px;
          border-top: 0.1%;
          text-align: center;
          width: 100%;
   }
   div.footer {
          border-top: 0;
           text-align: center;
   }
  
   </style>
   </head>
   <body class="bg-theme bg-theme1">
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
         <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
               <div class="col-sm-9">
                  <h4 class="page-title">Staff</h4>
               </div>
               <div class="col-sm-3">
                  <div class="btn-group float-sm-right">
                     <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
                     <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
                     <span class="caret"></span>
                     </button>
                     <div class="dropdown-menu">
                        <a href="javaScript:void();" class="dropdown-item">Action</a>
                        <a href="javaScript:void();" class="dropdown-item">Another action</a>
                        <a href="javaScript:void();" class="dropdown-item">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a href="javaScript:void();" class="dropdown-item">Separated link</a>
                     </div>
                  </div>
               </div>
            </div>
            <!-- End Breadcrumb-->
            <hr>
            <div class="row">
               <div class="col-lg-12">
                  <div class="card">
                     <div class="card-body">
                        <ul class="nav nav-tabs nav-tabs-primary">
                           <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#tabe-1"><i class="icon-home"></i> <span class="hidden-xs">Staff Details</span></a>
                           </li>
                        </ul>
                        <form action="<?php echo e(url('save-staff')); ?>" class="form-material" id="formData" name="create_customer" method="post"enctype="multipart/form-data"  >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
                        
						
						
						
						
						<div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
							  
							  <div class="col-md-6 mb-3">
                       <label for="validationCustom05">First Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="first_name" placeholder="First Name" name="first_name" value="<?php echo e(old('first_name')); ?>">
                                </div>
                                 <div class="col-md-6 mb-3">
                                 <label for="validationCustom03">Last Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="last_name" placeholder="Last Name" name="last_name" value="<?php echo e(old('last_name')); ?>">
                                 </div>
							  
							  <div class="col-md-6 mb-3">
                       <label for="validationCustom03">Email <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                                 </div>
							  
							   <div class="col-md-6 mb-3">
                        <label for="validationCustom03">Phone <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" value="<?php echo e(old('phone')); ?>">
                                 </div>
							  
							  
                                 <div class="col-md-6 mb-3">
                                 <label for="validationCustom03">Birth date </label>
                                    <input type="date" class="form-control" id="birth_date" placeholder="Birth Date" name="birth_date" value="<?php echo e(old('birth_date')); ?>">
                                    
                                 </div>
								  <div class="col-md-6 mb-3">
                          <label for="validationCustom03">Anniversary date </label>
                                    <input type="date" class="form-control" id="anniversary" placeholder="Anniversary" name="anniversary" value="<?php echo e(old('anniversary')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                 <label for="validationCustom03">Date Of Joining </label>
                                    <input type="date" class="form-control"  placeholder="Date Of Joining" name="join_date" value="<?php echo e(old('join_date')); ?>">
                                 </div>
                                 <div class="col-md-6 mb-3">
                                 <label for="validationCustom03">Date of Resignation </label>
                                    <input type="date" class="form-control"  placeholder="Date of Resignation" name="resign_date" value="<?php echo e(old('resign_date')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                 <label for="validationCustom03">Hourly Rate </label>
                                    <input type="text" class="form-control" id="hourly_rate" placeholder="Hourly Rate" name="hourly_rate" value="<?php echo e(old('hourly_rate')); ?>">
                                   
                                 </div>
                                
								
								<div class="col-md-6 mb-3">
                        <label for="validationCustom03">Password<span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="password" placeholder="Password" name="password" value="<?php echo e(old('password')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                 <label for="validationCustom03">Facebook </label>
                                    <input type="text" class="form-control" id="facebook" placeholder="facebook" name="facebook" value="<?php echo e(old('facebook')); ?>">
                                   
                                 </div>
								
																
								 <div class="col-md-6 mb-3">
                         <label for="validationCustom03">Linkedin </label>
                                    <input type="text" class="form-control" id="linkln" placeholder="Linkedin" name="linkln" value="<?php echo e(old('linkln')); ?>">
	                             </div>
								 
                                <div class="col-md-6 mb-3">
                                <label for="validationCustom03">Twitter </label>
                                    <input type="text" class="form-control" id="twitter" placeholder="Twitter " name="twitter" value="<?php echo e(old('twitter')); ?>">
                                 </div>
                                 
								 <div class="col-md-6 mb-3">
                         <label for="validationCustom03">Skype </label>
                                    <input type="text" class="form-control" id="skype" placeholder="Skype" name="skype" value="<?php echo e(old('skype')); ?>">
                                 </div>
								 
								  <div class="col-md-6 mb-3">
                          <label for="profile_image" class="profile-image">Profile image</label>
                                    <input type="file" name="profile_image" class="form-control" id="profile_image">
                                 </div>
								 
								 
								 
								 
								 <div class="col-md-6 mb-3">
                         <label for="profile_image" class="profile-image">Upload CV</label>
                                    <input type="file" name="cv"onchange="fileValidation(this)" class="form-control" id="cv">
                                 </div> 
                                 
                                 

								 
								 
                              </div>
                           </div>
                          
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--End Row-->
            <!--End Row-->
            <div class="overlay"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
<div class="footer">
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     </div>
     <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
        $("#formData").validate({
          rules: {
            first_name: {
              required:true,
            },
            last_name: {
              required:true,
            },
            email: {
              required:true,
              email:true,
            },
            phone: {
             required:true,
             digits:true,
             minlength:10,
             maxlength:10, 
            },
            hourly_rate: {
              
                digits:true,
            },
            password: {
                required:true,
                minlength:6,
                maxlength:16, 
            },
     
     
	  
    },
  messages: {
      first_name:{
        required:"<?php echo e(trans('messages.500')); ?>",
      } ,
      last_name:{
        required:"<?php echo e(trans('messages.501')); ?>",
      } ,
      email:{
         required:"<?php echo e(trans('messages.301')); ?>",
          email:"<?php echo e(trans('messages.302')); ?>",
      } ,
      phone:{
        required:"<?php echo e(trans('messages.305')); ?>",
        digits:"<?php echo e(trans('messages.306')); ?>",
        minlength:"<?php echo e(trans('messages.306')); ?>",
        maxlength:"<?php echo e(trans('messages.306')); ?>",
      } ,
     
      password:{
        required:"<?php echo e(trans('messages.5')); ?>",
        minlength:"<?php echo e(trans('messages.317')); ?>",
        maxlength:"<?php echo e(trans('messages.318')); ?>",

      } ,
     
      
	 
    
    }
  });
</script>
<script>
                    function fileValidation(e){
                      
        //var fileInput = document.getElementById('file');
        var fileInput = e;
      //  alert(filePath);
        var filePath = fileInput.value;
        console.log('e = ' + e.files[0].size)
        var allowedExtensions = /(\.pdf)$/i;
        if(!allowedExtensions.exec(filePath)){
          alert('Please upload file having extensions .pdf only.');
          fileInput.value = '';
          return false;
        } else if (e.files[0].size > 2000000) {
          alert('File size cannot be greater than 2 MB');
          fileInput.value = '';
          return false;
        } else {
          readURL(e);
          return true;
        }
      }
      </script>
   </body>
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>

