<!DOCTYPE html>
<html lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <body class="bg-theme bg-theme1">
      <!-- start loader -->
      <div id="pageloader-overlay" class="visible incoming">
         <div class="loader-wrapper-outer">
            <div class="loader-wrapper-inner" >
               <div class="loader"></div>
            </div>
         </div>
      </div>
      <!-- end loader -->
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
      <div class="container-fluid">
      <div class="row mt-3">
      <h4 class="page-title pull-left">Customers Summary</h4>
      <div class="col-md-12">
         <div class="row" style="padding-top:20px;">
            <!--<button type="button" class="btn btn-primary mb-3">New Customer</button>-->
            <?php if(!empty($addpermission)): ?>
                   
                   <?php else: ?>
                     <a class="btn btn-primary mb-3" href="<?php echo e(url('add-customer')); ?>"></i> New Customer</a>
                     <?php endif; ?>
         </div>
         <?php echo $__env->make('admin/admin_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      </div>
      <div class="row" style="padding-top:20px;">
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd"><?php echo e($users); ?></h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">Total Customer</span></h4>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd"><?php echo e($active_users); ?></h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">Active Customer</span></h4>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd"><?php echo e($inactive_users); ?></h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">Inactive Customer</span></h4>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd">0</h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">Active Contacts</span></h4>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd">0</h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">Inactive Contacts</span></h4>
                        </div>
                     </div>
                  </div>
                  
               </div>
      
      <div class="card">
      <div class="card-body">
         <h5 class="card-title">Customers</h5>
         <div class="table-responsive">
            <table class="table footable"  id="dataTable" class="text-center" >
               <thead>
                  <tr>
                     <th scope="col">#</th>
                     <th scope="col">Name</th>
                                       <th scope="col">Phone</th>
                                       <th scope="col">Website</th>
                                       <th scope="col">Active</th>
                                     <!--  <th>Groups</th>-->
                                       <th scope="col">Date Created</th>
                                       <th scope="col">Action</th>
                  </tr>
               </thead>
               <tbody>
               <?php $i = 1; ?>
                                    <?php if(!empty($customerlist)): ?>
                                    <?php foreach($customerlist as $cus): ?> 
                                    <?php   $id= Crypt::encrypt($cus->id );?> 
                                    <tr>
                                       
                                       <td><?php echo e($i); ?></td>
                                       <td><?php echo e($cus->client_name); ?></td>
                                       <td><?php echo e($cus->phone); ?></td>
                                       <td><?php echo e($cus->website); ?></td>
                                       <!-- <td><label class="switch"><input type="checkbox" checked><span class="slider round"></span></label></td>-->
                                       <?php if($cus->is_blocked==0): ?>  
                                       <td> <a data-id="<?php echo e($cus->is_blocked); ?>" class="" href="<?php echo e(url('change-status')); ?>?status_data=<?php echo e(Crypt::encrypt('id='.$cus->id.'&tbl=users&field=id&is_blocked='.$cus->is_blocked.'&request_url=customer')); ?>" title="" data-original-title="Active"onclick="return confirm('Are you sure you want to change this status  ?');"><i class="fa fa-check fa-lg text-success"></i></a></td>
                                       <?php else: ?>
                                       <td>   <a data-id="<?php echo e($cus->is_blocked); ?>" class="" href="<?php echo e(url('change-status')); ?>?status_data=<?php echo e(Crypt::encrypt('id='.$cus->id.'&tbl=users&field=id&is_blocked='.$cus->is_blocked.'&request_url=customer')); ?>"  title="" data-original-title="Inactive"onclick="return confirm('Are you sure you want to change this status  ?');"><i class="fa fa-ban fa-lg text-danger"></i></a></td>
                                       <?php endif; ?>
                                     <!--  <td><?php echo e($cus->group_name); ?></td>-->
                                       <td><?php echo e($cus->created_at); ?></td>
                                       <td> <?php if(session('user_type')==1): ?>
                                       <a href="<?php echo e(url('customer-detail').'/'.$id); ?>" title="Details" data-toggle="tooltip"><span class="badge badge-pill badge-primary">View</span></a>
                                       <?php endif; ?>
                                  </td>
                                    </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; ?>
                                    <?php endif; ?> 
               </tbody>
               <tfoot class="hide-if-no-paging">
                  <td colspan="5">
                     <div class="pagination"></div>
                  </td>
               </tfoot>
            </table>
            <!--start overlay-->
            <div class="overlay toggle-menu"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
</html>
</body>