
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" type="image/png" sizes="16x16" href="https://lh3.googleusercontent.com/-ve9CCJ_jk5g/XVzwYa6ys6I/AAAAAAAAAsQ/4GaZiUUr8AQQUxLzYr4JAYgbzFy10AjTwCK8BGAs/s0/2019-08-21.png">
  <title>Cargo |  Page </title>

  <!-- Bootstrap core CSS -->
  <link href="http://3.18.172.254/public/assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="http://3.18.172.254/public/assets/css/business-frontpage.css" rel="stylesheet">
   <link href="http://3.18.172.254/public/assets/css/style.css" rel="stylesheet">

</head>

<body>

 

  <!-- Header -->
  <!--<header class="bg-primary py-5 mb-5">
    <div class="container h-100">
      <div class="row align-items-center">
        <div class="col-lg-12">
         <h1 class="logo"><img src="https://lh3.googleusercontent.com/-ve9CCJ_jk5g/XVzwYa6ys6I/AAAAAAAAAsQ/4GaZiUUr8AQQUxLzYr4JAYgbzFy10AjTwCK8BGAs/s0/2019-08-21.png"> Cargo</h1>
         
        </div>
      </div>
    </div>
  </header>-->
  
  
    <!-- Page Content -->
<div class="container page terms">
    <div class="row">
      <div class="col-md-12 mb-5">
        <h2>Terms & Conditions</h2>
        <hr>
          <p>
          These Terms of Use (&quot;Terms&quot;, &quot;Terms of Use&quot;) govern your relationship with
www.letcargo.com website and Cargo mobile application (the &quot;Service&quot;) operated by Cargo
LLC (&quot;us&quot;, &quot;we&quot;, or &quot;our&quot;).
Please read these Terms of Use carefully before using our website and Cargo mobile
application (the &quot;Service&quot;).
Your access to and use of the Service is conditioned on your acceptance of and compliance
with these Terms. These Terms apply to all visitors, users and others who access or use the
Service.
By accessing or using the Service you agree to be bound by these Terms. If you disagree
with any part of the terms then you may not access the Service.
</p>

        <h5> Purchases</h5>
        <p>
          
        If you wish to purchase any product or service made available through the Service ("Purchase"), you may be asked to supply certain information relevant to your Purchase including, without limitation, your credit card number, the expiration date of your credit card, your billing address, and your shipping information.
You represent and warrant that: (i) you have the legal right to use any credit card(s) or other payment method(s) in connection with any Purchase; and that (ii) the information you supply to us is true, correct and complete.
By submitting such information, you grant us the right to provide the information to third parties for purposes of facilitating the completion of Purchases.
We reserve the right to refuse or cancel your order at any time for certain reasons including but not limited to: product or service availability, errors in the description or price of the product or service, error in your order or other reasons.
We reserve the right to refuse or cancel your order if fraud or an unauthorised or illegal transaction is suspected.


        </p>



        <h5>Availability, Errors and Inaccuracies</h5>

        <p>

        We are constantly updating our offerings of products and services on the Service. The products or services available on our Service may be mispriced, described inaccurately, or unavailable, and we may experience delays in updating information on the Service and in our advertising on other web sites.
We cannot and do not guarantee the accuracy or completeness of any information, including prices, product images, specifications, availability, and services. We reserve the right to change or update information and to correct errors, inaccuracies, or omissions at any time without prior notice.


        </p>
        <h5>Contests, Sweepstakes and Promotions</h5>

        <p>

        Any contests, sweepstakes or other promotions (collectively, "Promotions") made available through the Service may be governed by rules that are separate from these Terms. If you participate in any Promotions, please review the applicable rules as well as our Privacy Policy. If the rules for a Promotion conflict with these Terms, the Promotion rules will apply.

        </p>
        <h5>Subscriptions</h5>

        <p>

        Some parts of the Service are billed on a subscription basis ("Subscription(s)"). You will be billed in advance on a recurring and periodic basis ("Billing Cycle"). Billing cycles are set either on a monthly or annual basis, depending on the type of subscription plan you select when purchasing a Subscription.
At the end of each Billing Cycle, your Subscription will automatically renew under the exact same conditions unless you cancel it or Cargo LLC cancels it. You may cancel your Subscription renewal either through your online account management page or by contacting Cargo LLC customer support team.
A valid payment method, including credit card, is required to process the payment for your Subscription. You shall provide Cargo LLC with accurate and complete billing information including full name, address, state, zip code, telephone number, and a valid payment method information. By submitting such payment information, you automatically authorize Cargo LLC to charge all Subscription fees incurred through your account to any such payment instruments.
Should automatic billing fail to occur for any reason, Cargo LLC will issue an electronic invoice indicating that you must proceed manually, within a certain deadline date, with the full payment corresponding to the billing period as indicated on the invoice.


        </p>
        <h5>Fee Changes</h5>

        <p>

        Cargo LLC, in its sole discretion and at any time, may modify the Subscription fees for the Subscriptions. Any Subscription fee change will become effective at the end of the then-current Billing Cycle.
Cargo LLC will provide you with a reasonable prior notice of any change in Subscription fees to give you an opportunity to terminate your Subscription before such change becomes effective.
Your continued use of the Service after the Subscription fee change comes into effect constitutes your agreement to pay the modified Subscription fee amount.



        </p>
        <h5>Refunds</h5>

<p>

Certain refund requests for Subscriptions may be considered by Cargo LLC on a case-by-case basis and granted in sole discretion of Cargo LLC.


</p>
<h5>Content</h5>

<p>

Our Service allows you to post, link, store, share and otherwise make available certain information, text, graphics, videos, or other material ("Content"). You are responsible for the Content that you post to the Service, including its legality, reliability, and appropriateness.
By posting Content to the Service, you grant us the right and license to use, modify, perform, display, reproduce, and distribute such Content on and through the Service. You retain any and all of your rights to any Content you submit, post or display on or through the Service and you are responsible for protecting those rights.
You represent and warrant that: (i) the Content is yours (you own it) or you have the right to use it and grant us the rights and license as provided in these Terms, and (ii) the posting of your Content on or through the Service does not violate the privacy rights, publicity rights, copyrights, contract rights or any other rights of any person.



</p>
<h5>Accounts</h5>

<p>

When you create an account with us, you must provide us information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.
You are responsible for safeguarding the password that you use to access the Service and for any activities or actions under your password, whether your password is with our Service or a third-party service.
You agree not to disclose your password to any third party. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.
You may not use as a username the name of another person or entity or that is not lawfully available for use, a name or trade mark that is subject to any rights of another person or entity other than you without appropriate authorization, or a name that is otherwise offensive, vulgar or obscene.




</p>
<h5>Intellectual Property</h5>

<p>

The Service and its original content (excluding Content provided by users), features and functionality are and will remain the exclusive property of Cargo LLC and its licensors. The Service is protected by copyright, trademark, and other laws of both the Kuwait and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of Cargo LLC.


</p>
<h5>Links To Other Web Sites</h5>

<p>

Our Service may contain links to third-party web sites or services that are not owned or controlled by Cargo LLC.
Cargo LLC has no control over, and assumes no responsibility for, the content, privacy policies, or practices of any third party web sites or services. You further acknowledge and agree that Cargo LLC shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such web sites or services.
We strongly advise you to read the terms and conditions and privacy policies of any third-party web sites or services that you visit.



</p>
<h5>Termination</h5>

<p>

We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
Upon termination, your right to use the Service will immediately cease. If you wish to terminate your account, you may simply discontinue using the Service.




</p>
<h5>Limitation Of Liability</h5>

<p>

In no event shall Cargo LLC, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from (i) your access to or use of or inability to access or use the Service; (ii) any conduct or content of any third party on the Service; (iii) any content obtained from the Service; and (iv) unauthorized access, use or alteration of your transmissions or content, whether based on warranty, contract, tort (including negligence) or any other legal theory, whether or not we have been informed of the possibility of such damage, and even if a remedy set forth herein is found to have failed of its essential purpose




</p>
<h5>Disclaimer</h5>

<p>

Your use of the Service is at your sole risk. The Service is provided on an "AS IS" and "AS AVAILABLE" basis. The Service is provided without warranties of any kind, whether express or implied, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose, non-infringement or course of performance.
Cargo LLC its subsidiaries, affiliates, and its licensors do not warrant that a) the Service will function uninterrupted, secure or available at any particular time or location; b) any errors or defects will be corrected; c) the Service is free of viruses or other harmful components; or d) the results of using the Service will meet your requirements.


</p>
<h5>Governing Law</h5>

<p>

These Terms shall be governed and construed in accordance with the laws of Kuwait, without regard to its conflict of law provisions.
Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect. These Terms constitute the entire agreement between us regarding our Service, and supersede and replace any prior agreements we might have between us regarding the Service.


</p>
<h5>Changes</h5>

<p>

We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, please stop using the Service.


</p>
<h5>Contact Us</h5>

<p>

If you have any questions about these Terms, please contact us.


</p>
        
      </div>
      
    </div>
</div>
<!-- /.container -->

  

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center ">Copyright &copy; 2019 Cargo. All rights reserved.</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="http://3.18.172.254/public/assets/js/jquery.min.js"></script>
  <script src="http://3.18.172.254/public/assets/js/bootstrap.bundle.min.js"></script>

</body>

</html>
