<?php $__env->startSection('page-css'); ?>
<style>
label.error,span.phn_err,.msg_err {
  color:red;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/managers')); ?>"><i class="fa fa-user-secret"></i> Manager List</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
            <form action="<?php echo e(url('Admin/edit-manager')); ?>" method="post"  id="manager_edit" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php if(count($errors) > 0): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php foreach($errors->all() as $error): ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; ?>
                  </ul>
              </div>
            <?php endif; ?>
              <div class="box-body">
              <div class="form-group">
                  <label >Company Name<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo e(old('company_name',$user->company_name)); ?>">
                </div>
                <div class="form-group">
                  <label >Name<span class="text-danger">*</span></label>
                  <input type="text" name="full_name" class="form-control"  placeholder="Enter Name" value="<?php echo e(old('full_name',$user->full_name)); ?>">
                </div>
                <div class="form-group">
                  <label >Email address<span class="text-danger">*</span></label>
                  <input type="email" name="email" id="email" class="form-control"  placeholder="Enter Email" value="<?php echo e(old('email',$user->email)); ?>">
                  <span id="err-mail" class="msg_err"></span>
                </div>
                <div class="form-group">
                  <label >Commision<span class="text-danger">*</span></label>
                  <input type="number" name="admin_commision" id="admin_commision" class="form-control"  placeholder="Enter commision" value="<?php echo e(old('admin_commision',$user->admin_commision)); ?>">
                  <span id="err-commision" class="msg_err"></span>
                </div>
                <div class="form-group">
                  <label >Service Fees<span class="text-danger">*</span></label>
                  <input type="text" name="admin_servicefees" id="admin_servicefees" class="form-control"  placeholder="Enter servicefees" value="<?php echo e(old('admin_servicefees',$user->admin_servicefees)); ?>">
                  <span id="err-servicefees" class="msg_err"></span>
                </div>
                <div class="form-group">
                  <label >Phone Number<span class="text-danger">*</span></label>
                  <div class="input-group">
                  <span class="input-group-addon">
                  <?php echo e($user->country_calling_code); ?>

                  </span>
                  <input type="number" readonly name="phone_number"  id="phone" class="form-control" placeholder="Enter Phone Number" value="<?php echo e(old('phone_number',$user->phone_no)); ?>">
                
                  </div>
                </div>
                <span id="phn_err" class="text-danger"></span>
                <?php 
                $display ="none";
                if($user->is_driver == 1){
                  $display ="block";
                }
                if(old('is_driver')== true){
                  $display ="block";
                }
                ?>

                 <div class="checkbox">
                  <label>
                    <input type="checkbox" id="is_driver" name="is_driver" <?php echo ($user->is_driver==1 || old('is_driver')== true ? 'checked' : '');?>> Is Driver
                  </label>
                </div>


                <div id="driver_div" style="display:<?php echo e($display); ?>;">
                <div class="form-group">
                    <label >Licence Number<span class="text-danger">*</span></label>
                    <input type="text" name="licence" class="form-control" id="licence"  placeholder="Enter Licence Number" value="<?php echo e(old('licence',$user->licence_no)); ?>" >
                    <span id="err-license" class="msg_err text-danger"></span>
                  </div>
                  <div class="form-group">
                  <label>Vehical Type<span class="text-danger">*</span></label>
                  <select name="vehical_type_id" id="vehical_type_id" class="form-control select2" >    
                    <?php if($user->vehical_type_id != "" || $user->vehical_type_id != NULL): ?> 
                      <?php foreach($vehicals as $veh): ?>
                        <option value="<?php echo e($veh->vehical_type_language_id); ?>"  <?php echo e($veh->vehical_type_language_id == $user->vehical_type_id || $veh->vehical_type_language_id == old('vehical_type_id') ? 'selected' : ''); ?> ><?php echo e($veh->type); ?></option>
                      <?php endforeach; ?>
                    <?php else: ?>
                    <option value="">Please select</option> 
                    <?php foreach($vehicals as $veh): ?>
                        <option value="<?php echo e($veh->vehical_type_language_id); ?>"><?php echo e($veh->type); ?></option>
                      <?php endforeach; ?>
                    <?php endif; ?>
                  </select> 
                 
                </div>
                  <div class="form-group">
                    <label>Vehical Registration No.<span class="text-danger">*</span></label>
                    <input name="vehical_reg_no" id="vehical_reg_no" type="text" class="form-control" placeholder="Enter Vehical Registration No." value="<?php echo e(old('vehical_reg_no',$user->vehical_reg_no)); ?>" >
                    <span id="err-vehical_reg" class="msg_err text-danger"></span>
                  </div>
                  <div class="form-group">
                    <label>Vehical Color<span class="text-danger">*</span></label>
                    <input name="vehical_color" type="text" class="form-control" placeholder="Enter Vehical Color" value="<?php echo e(old('vehical_color',$user->vehical_color)); ?>">
                  </div>
                 
                  <?php if($user->img_path!='' || $user->img_path!=NULL): ?>
                  <div class="form-group">
                    <label>Driver Image<span class="text-danger">*</span></label>
                 
                    <img  src="<?php echo e(url('public/uploads/profile').'/'.$user->img_path); ?>" style="width:100px;height:100px;" alt="Image" / >
                
                  </div>
                  <?php endif; ?>
                  <div class="form-group">
                  <label>Change Driver Image</label>
                  <input type="file" id="image" name="driver_image" accept="image/*" class="form-group">
                  </div>
                  <input type="hidden" id="driver_img" value="($user->img_path!='' || $user->img_path!=NULL) ? '1':'0'">
             
				</div>	
                <input name="user_id" type="hidden" value="<?php echo e(Crypt::encrypt($user->user_id)); ?>">
                <input name="user_type" type="hidden" value="<?php echo e($user->user_type); ?>">
               
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="<?php echo e(url('Admin/managers')); ?>" class="btn btn-danger"> Cancel</a>
              </div>
			  </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
     
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
var regNOok = true;
    $("#is_driver").click(function(){
      if($('#is_driver').is(':checked') == true){
        $('#driver_div').show();
      }
      else{
        $('#driver_div').hide();
      }
    });

jQuery.validator.addMethod("noSpace", function(value, element) { 
  return value.indexOf(" ") < 0 && value != ""; 
}, "No space please and don't leave it empty");
  $("#manager_edit").validate({
      rules: {
        company_name:{
          required:true,
           maxlength:250
        },
        full_name: {         
           required:true,
           maxlength:250
        },
        email: {
          required:true,
           email:true
        },
        phone_number: {
          required:true,
          digits: true,
          maxlength:8,
          minlength:8
        },
        admin_commision: {
          required:true,
//digits: true
         
        },
        admin_servicefees: {
          required:true,
         // digits: true
         
        },
      
      vehical_type_id:{
          required: function(){
            if($("#is_driver").is(':checked')){
              return true;
            }
            else{
              return false;
            }
          }
        },
        licence:{
          required: function(){
            if($("#is_driver").is(':checked')){
              return true;
            }
            else{
              return false;
            }
          },
          maxlength: function(){
              if($("#is_driver").is(':checked')){
                return 20;
              }
              else{
                return false;
              }
          },
            noSpace: function(){
            if($("#is_driver").is(':checked')){
              return true;
            }
            else{
              return false;
            }
          }
        },
        vehical_reg_no:{
          required: function(){
            if($("#is_driver").is(':checked')){
              return true;
            }
            else{
              return false;
            }
          },
            maxlength: function(){
              if($("#is_driver").is(':checked')){
                return 20;
              }
              else{
                return false;
              }
          },
            noSpace: function(){
            if($("#is_driver").is(':checked')){
              return true;
            }
            else{
              return false;
            }
          }
        
        } ,
        vehical_color:{
          required: function(){
            if($("#is_driver").is(':checked')){
              return true;
            }
            else{
              return false;
            }
          }
        },
        driver_image:{
          required: function(){
            if($("#is_driver").is(':checked') && $("#driver_img").val()==0){
              return true;
            }
            else{
              return false;
            }
          },
          accept: function(){
            if($("#is_driver").is(':checked')  && $("#driver_img").val()==0){
              return "image/*";
            }
            else{
              return false;
            }
          },
          filesize: function(){
            if($("#is_driver").is(':checked')  && $("#driver_img").val()==0){
              return 200000;
            }
            else{
              return false;
            }
          }
        } 

      }
    }); 

    $("#phone").blur(function(){
      var phone = $("#phone").val();
      var ajax_url = "<?php echo e(url('Admin/phone_exist_edit')); ?>";
      var user_id = <?php echo e($user->user_id); ?>;
      $.ajax({
               type:'POST',
               url: ajax_url,
               data: { "_token": "<?php echo e(csrf_token()); ?>", "phone": phone,"user_id":user_id },
               success:function(data) {
                 if(data == 1){
                  $("#phone").val("");
                  $("#err-phn").html("Phone Number has already taken.");
                  return false;
                 }
                 else{
                  $("#err-phn").html("");
                 }
               }
            });
    });
    $("#email").blur(function(){
      var email = $("#email").val();
      var user_id = <?php echo e($user->user_id); ?>;
      var ajax_url = "<?php echo e(url('Admin/email_exist')); ?>";
      $.ajax({
        type:'POST',
        url: ajax_url,
        data: { "_token": "<?php echo e(csrf_token()); ?>", "email": email,"userId":user_id },
        success:function(data) {
          if(data == 1){
          $("#email").val("");
          $("#err-mail").html("Email address has already taken.");
          }
          else{
          $("#err-mail").html("");
          }
        }
      });
    });

    $("#licence").blur(function(){
      var licence = $("#licence").val();
      var user_id = <?php echo e($user->user_id); ?>;
      var ajax_url = "<?php echo e(url('Admin/licence-exist')); ?>";
      $.ajax({
               type:'POST',
               url: ajax_url,
               data: { "_token": "<?php echo e(csrf_token()); ?>", "licence": licence, "userId":user_id},
               success:function(data) {
                 if(data == 1){
                  //$("#licence").val("");
                  $("#err-license").html("License Number has already taken.");
                  return false;
                 }
                 else{
                  $("#err-license").html("");
                 }
               }
            });
    });
    $("#vehical_reg_no").blur(function(){
      var vehical_reg_no = $("#vehical_reg_no").val();
      var user_id = <?php echo e($user->user_id); ?>;
      var ajax_url = "<?php echo e(url('Admin/vehical-reg-exist')); ?>";
      $.ajax({
               type:'POST',
               url: ajax_url,
               data: { "_token": "<?php echo e(csrf_token()); ?>", "vehical_reg": vehical_reg_no, "userId":user_id},
               success:function(data) {
                 if(data == 1){
                  //$("#vehical_reg_no").val("");
                  $("#err-vehical_reg").html("Vehical Registration Number has already taken.");
                  regNOok = false;
                 }
                 else{
                  regNOok = true;
                  $("#err-vehical_reg").html("");
                 }
               }
            });
    });
    $("#vehical_reg_no").focus(function(){
      $("#err-vehical_reg").html("");
    });
    $("#licence").focus(function(){
      $("#err-license").html("");
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>