<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/building')); ?>"><i class="fa fa-user-secret"></i>Building Type</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
           <form action="<?php echo e(url('Admin/save-building')); ?>" method="POST" id="formData1">
		    <?php echo e(csrf_field()); ?>

			<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
              <div class="box-body">
			  
                  
              <?php foreach($vehiclelanguage as $val): ?>
              <div class="form-group" >
                  <label for="exampleInputEmail1">Language</label>

                 <input type="text" id="language"name="language_name[]"  value="<?php echo e($val->language_name); ?>" placeholder="Enter title" class="form-control" readonly />
 
				</div>
       <input type="hidden" id="language"name="language[]"  value="<?php echo e($val->language_id); ?>" placeholder="Enter title" class="form-control" readonly />	
							
					 <div class="form-group" >
                  <label >Building Type</label>		

                <input type="text" id="type"name="type[]" placeholder="Enter Building Type" class="form-control type_cls" />
				<span class="typeErr error" style="color: red;"></span>
				</div>
				 
							
							

               
           
			 <?php endforeach; ?>

       

              </div>
	
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  onclick="return formValidationAdd();"class="btn btn-primary">Submit</button>
                <button type="reset"  class="btn btn-primary">Reset</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
          </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script type="text/javascript">

   

    var i = 0;

       

    $("#add").click(function(){

   

        ++i;

   

        $("#dynamicTable").append('<tr><td><input type="text" name="title[]" placeholder="Enter title" class="form-control" /></td><td><textarea name="content[]" placeholder="Enter Description" class="form-control" ></textarea></td>/<td><button type="button" class="btn btn-danger remove-tr">Remove</button></td></tr>');
    });

   

    $(document).on('click', '.remove-tr', function(){  

         $(this).parents('tr').remove();

    });  

   

</script>
<script>
				function formValidationAdd1(){
					
				 var data = new FormData($('#formData1')[0]);
				 //var hid = $("#id").val();
				 var type = $("#type").val();
                
             	  $(".typeErr").html("");
              	// $(".typeErr").hide("");
             	
             	 if(type==""){
               	//	$(".typeErr").slideDown('slow');
               		$(".typeErr").html("Building Type is required.").show();
               		$("#type").focus();
               		return false;
               	}
				
             	
				
             	
				}</script>	
        <script>
				function formValidationAdd(){
					
				 var data = new FormData($('#formData1')[0]);
				 //var hid = $("#id").val();
			//	 var title = $("#title").val();
				// var content = $("#content").val();
         $(".titleErr").html("");
				  $(".contentErr").html("");
          var check = true;
         $(".type_cls").each(function(){ 
           //yourArray.push($(this).val()); 
           var type = $(this).val();
           if(type==""){
            check = false;
          	$(".typeErr").html("English and Arabic Both Building Type required.").show();
               	//	$("#title").focus();
                  
           }
          
          
           });
           if (check==false) {
    return false;
}
                
 
				}</script>	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>