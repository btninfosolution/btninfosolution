<!doctype html>
<html class="no-js" lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Profile</h4>
                     </div>
                  </div>
                  <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Customer Details</a>
                           <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Billing & Shipping</a>
                        </div>
                     </nav>
                     <form action="<?php echo e(url('save-customer')); ?>" class="form-material" id="formData" name="create_customer" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Company Name</label>
                                    <input type="text" class="form-control" id="company_name" placeholder="company Name" name="company_name">
                                    
                                 </div>
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Client Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="client_name" placeholder="Client Name" name="client_name">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">GST No</label>
                                    <input type="text" class="form-control" id="gst" name="gst" placeholder="GSTN" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Phone <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone">
                                   
                                 </div>
                                
								 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Group</label>
                                    <select id="group" name="group[]"class="form-control"yle="width:100%"multiple="" >
                                      
                                       <?php foreach($grouplist as $group): ?> 
                                       <option value="<?php echo e($group->group_id); ?>"><?php echo e($group->group_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Country</label>
                                    <select id="country" name="country"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($countrylist as $country): ?> 
                                       <option value="<?php echo e($country->country_id); ?>"><?php echo e($country->country_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">State</label>
                                    <input type="text" class="form-control" id="state" name="state" placeholder="state">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">City</label>
                                    <input type="text" class="form-control" id="city" name="city"placeholder="city" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Website</label>
                                    <input type="text" class="form-control" id="website" name="website" placeholder="" >
                                    
                                 </div>
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Address</label>
                                    <textarea id="address" name="address" class="form-control" rows="4"></textarea>
                                    
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                              <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <h5 class="no-mtop">Billing Address <a href="#" class="pull-right billing-same-as-customer"><small class="font-medium-xs"></small></a></h5>
                                    <hr>
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <h5 class="no-mtop">Billing Address <a href="#" class="pull-right billing-same-as-customer"><small class="font-medium-xs"></small></a></h5>
                                    <hr>
                                 </div>
                                 <div class="clearfix"></div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">City</label>
                                    <input type="text" class="form-control" id="billing_city" name="billing_city" placeholder="" >
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">State</label>
                                    <input type="text" class="form-control" id="billing_state" name="billing_state" placeholder="" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Country</label>
                                    <select id="bill_country" name="bill_country"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($countrylist as $country): ?> 
                                       <option value="<?php echo e($country->country_id); ?>"><?php echo e($country->country_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Zip</label>
                                    <input type="text" class="form-control" id="bill_zip" name="bill_zip" placeholder="" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Address</label>
                                    <textarea id="address" name="bill_address" class="form-control" rows="4"></textarea>
                                    
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
  $("#formData").validate({
    rules: {
        client_name: {
        	required:true,
      },
      phone: {
        	required:true,
         digits:true,
         minlength:10,
         maxlength:10,  
      },
     
     
	  
    },
  messages: {
    client_name:{
        required:"<?php echo e(trans('messages.304')); ?>",
      } ,
      phone:{
        required:"<?php echo e(trans('messages.305')); ?>",
       digits:"<?php echo e(trans('messages.306')); ?>",
         minlength:"<?php echo e(trans('messages.306')); ?>",
        maxlength:"<?php echo e(trans('messages.306')); ?>",
      } ,
     
      
	 
    
    }
  });
</script>
   </body>
</html>