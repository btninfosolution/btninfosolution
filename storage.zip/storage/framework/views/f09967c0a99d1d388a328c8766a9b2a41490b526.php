<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1>Edit Vehicle
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/vehicles')); ?>"><i class="fa fa-user-secret"></i> Vechiles</a></li>
        <li class="active">Edit Vehicle</li>
    </ol>
</section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
           <form action="<?php echo e(url('Admin/update-vehicle')); ?>" method="POST" id="formData1">
		    <?php echo e(csrf_field()); ?>

        <?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<h4><?php echo e($errors->first()); ?></h4>
<?php endif; ?>
              <div class="box-body">
			  
                    
       <?php foreach($Editdata as $val): ?>
            
                <div class="form-group" >
                  <label for="exampleInputEmail1">Language</label>
               
			   <input type="text" id="language"name="language"value=" <?php echo e($val->language_name); ?> " placeholder="Enter title" class="form-control" readonly />
			
				</div>
				<input type="hidden" id="vehical_type_id "name="vehical_type_id "value="<?php echo e($val->vehical_type_id); ?>" placeholder="Enter title" class="form-control" />
					<input type="hidden" id="language_id"name="language_id[]"value="<?php echo e($val->vehical_type_language_id); ?>" placeholder="Enter title" class="form-control" />
				
                   <div class="form-group" >
                  <label for="exampleInputEmail1">Vehicle Type</label>
                <input type="text" id="type"name="type[]"value="<?php echo e($val->type); ?>" placeholder="Enter Type" class="form-control" />
				<span class="typeErr error" style="color: red;"></span></td> 
				</div>
        
			 <?php endforeach; ?>


              </div>
	
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  onclick="return formValidationAdd();"class="btn btn-primary">Submit</button>
                <a href="<?php echo e(url('Admin/vehicles')); ?>" class="btn btn-danger"> Cancel</a>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
          </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<script>
				function formValidationAdd(){
					
				 var data = new FormData($('#formData1')[0]);
				 //var hid = $("#id").val();
				 var type = $("#type").val();
                
             	  $(".typeErr").html("");
              	// $(".typeErr").hide("");
             	
             	 if(type==""){
               	//	$(".typeErr").slideDown('slow');
               		$(".typeErr").html("Vehicle Type is required.").show();
               		$("#type").focus();
               		return false;
               	}
				
             	
				
             	
				}
        </script>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>