<?php $__env->startSection('page-css'); ?>
<style>
      /* Set the size of the div element that contains the map */
    #map {
        height: 400px;  /* The height is 400 pixels */
        width: 100%;  /* The width is the width of the web page */
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/consignments')); ?>"><i class="fa fa-tty"></i> Consignments</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<input type ="hidden" id="pickup_latitude" value="<?php echo e($pickup_latitude); ?>">
<input type ="hidden" id="pickup_longitude" value="<?php echo e($pickup_longitude); ?>">
<input type ="hidden" id="driver_latitude" value="<?php echo e($driver_latitude); ?>">
<input type ="hidden" id="driver_longitude" value="<?php echo e($driver_longitude); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!--The div element for the map -->
    <div id="map"></div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<!--<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('google_api_key')); ?>&libraries=places"></script>-->
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('google_api_key')); ?>&callback=initialize">
    </script>
<script type="text/javascript">
/*function initMap() {
   // var locations = <?php echo json_encode($delivery);?>;
  // The location of Uluru
 var lat_data = parseFloat($("#pickup_latitude").val());
  var long_data = parseFloat($("#pickup_longitude").val());

 //var uluru = {lat: -25.344, lng: 131.036};
  var uluru = {lat: lat_data, lng: long_data};

  
  // The map, centered at Uluru
  var map = new google.maps.Map(
      document.getElementById('map'), {zoom: 4, center: uluru});
  // The marker, positioned at Uluru

  var marker = new google.maps.Marker({position: uluru, map: map});*/

/*  var marker, i;

for (i = 0; i < locations.length; i++) { 
    console.log(locations[i].drop_off_latitude);
    console.log(locations[i].drop_off_longitude);
    var delivery_lat =parseFloat(locations[i].drop_off_latitude);
    var delivery_long = parseFloat(locations[i].drop_off_longitude);
    //var pickoff =  {lat:delivery_lat , delivery_long};
    var pickoff = {lat: -25.344, lng: 131.036};
    var map = new google.maps.Map(
      document.getElementById('map'), {zoom: 4, center: pickoff});

   marker = new google.maps.Marker({
   position: new google.maps.LatLng(locations[i].drop_off_latitude, locations[i].drop_off_longitude),
   title: locations[i].address,
   map: map
});

}

}*/

//collaps the left panel and control the map window view
$(document).ready(function(){
    $(".sidebar-toggle").trigger('click');
    let height = $(document).height() - ($(".main-header").height() - $(".main-footer").height());
    console.log(height);
    $("#map").css({height:height});
});
</script>
<script type="text/javascript">
    var geocoder;
    var map;
    var lat_data = parseFloat($("#pickup_latitude").val());
    var long_data =  parseFloat($("#pickup_longitude").val());
    var driver_lat = parseFloat($("#driver_latitude").val());
    var driver_lon = parseFloat($("#driver_longitude").val());
    function initialize() {
        var locations = <?php echo json_encode($delivery)?>;
        var latlng = new google.maps.LatLng(lat_data, long_data); 
        var drv_location = {lat: driver_lat, lng: driver_lon}; 
        var myOptions = {
        zoom: 9,
        center: latlng,
        mapTypeControl: true,
        mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
        navigationControl: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        map = new google.maps.Map(document.getElementById("map"), myOptions);

        var drv_marker = new google.maps.Marker({position: drv_location, map: map, icon:'http://maps.google.com/mapfiles/ms/icons/green-dot.png'});

        for (i = 0; i < locations.length; i++) {
            setMarker(locations[i]);
        } 
    }

    function setMarker(locations) {
        geocoder = new google.maps.Geocoder();
        infowindow = new google.maps.InfoWindow();
        if ((locations["drop_off_latitude"] == null) || (locations["drop_off_longitude"] == 'null') || (locations["drop_off_latitude"] == '') || (locations["drop_off_longitude"] == '')) {
            geocoder.geocode({ 'address': locations["address"] }, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    latlng = new google.maps.LatLng(results[0].geometry.location.lat(), results[0].geometry.location.lng());
                    marker = new google.maps.Marker({
                        position:  results[0].geometry.location,
                        map: map,
                        draggable: false,
                        html: locations["address"],
                        //icon: "images/marker/" + people["MarkerId"] + ".png"
                    });
                    //marker.setPosition(latlng);
                    //map.setCenter(latlng);
                    google.maps.event.addListener(marker, 'click', function(event) {
                        infowindow.setContent(this.html);
                        infowindow.setPosition(event.latLng);
                        infowindow.open(map, this);
                    });
                }
                else {
                    alert(locations["address"] + ". This address couldn't be found");
                }
            });
        }
        else {
            //var latlngStr = people["LatitudeLongitude"].split(",");
            var lat = parseFloat(locations["drop_off_latitude"]);
            var lng = parseFloat(locations["drop_off_longitude"]);
            latlng = new google.maps.LatLng(lat, lng);
            marker = new google.maps.Marker({
                position: latlng,
                map: map,
                draggable: false,               // cant drag it
                html: locations["address"]    // Content display on marker click
                    
            });
            //marker.setPosition(latlng);
            //map.setCenter(latlng);
            google.maps.event.addListener(marker, 'click', function(event) {
                infowindow.setContent(this.html);
                infowindow.setPosition(event.latLng);
                infowindow.open(map, this);
            });
        } 
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>