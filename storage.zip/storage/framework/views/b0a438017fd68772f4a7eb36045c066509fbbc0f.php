<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>

<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
				
                    <tr>
                        <th >Sl No</th>
                        <th>Driver Name</th>
                        <th>Phone No</th>
                        <th>Email</th>
                        <th>Registered at</th>
                        <th>Status</th>
                        <th>Approve status</th>
					    <th>Action</th>
                        
                    </tr>
					<tbody id="tabledata">
                    
                    <?php $i = ($driverlist->currentpage()-1)* $driverlist->perpage() + 1; ?>
                    <?php foreach($driverlist as $driver): ?> 
					 <?php   $id= Crypt::encrypt($driver->user_id);?>	

                    <tr>
					<td class="center"><?php echo e($i); ?> </td>
                    <td class="center"><?php echo e($driver->full_name); ?> </td>
         <td class="center"><?php echo e($driver->phone_no); ?> </td>
					<td class="center"><?php echo e($driver->email); ?> </td>
          <td class="center" ><?php echo e($driver->created_at); ?> </td>
          <?php if($driver->is_blocked==1): ?> 
          <td class="center" ><?php echo e('Blocked '); ?> </td>
          <?php else: ?> 
          <td class="center" ><?php echo e('UnBlocked'); ?> </td>
          <?php endif; ?>
          <td><?php if($driver->admin_verify_status == 1): ?> Approved <?php elseif($driver->admin_verify_status == 2): ?> Reject <?php else: ?> Approval Pending <?php endif; ?></td>
					<td class="center"> 
				
				
						 <?php if($driver->is_blocked==1): ?>  
                            <a  href="<?php echo e(url('Admin/inactive_active_area').'/'.$driver->user_id); ?>"data-toggle="tooltip" title="Blocked" id="status"onclick="return confirm('Are you sure you want to Unblock this  ?');"  >
                            <span class="glyphicon glyphicon-ban-circle"></span>  
                            </a>
                            <?php else: ?> 
                            <a href="<?php echo e(url('Admin/inactive_active_area').'/'.$driver->user_id); ?>" data-toggle="tooltip" title="Unblocked" id="status" onclick="return confirm('Are you sure you want to Block this  ?');" >
                            <span class="glyphicon glyphicon-check"></span>     
                            </a>
                            <?php endif; ?>   
                            <?php if($driver->admin_verify_status == 0): ?>
                        <a href="<?php echo e(url('Admin/approve-driver').'/'.$id.'/'.$driver->user_type.'/1'); ?>" data-toggle="tooltip" title="Approve" onclick="return confirm('Are you sure you want to Approved this user ?');">
                        <span class="glyphicon glyphicon-ok"></span>
                        </a>
                       
                        <a href="<?php echo e(url('Admin/approve-driver').'/'.$id.'/'.$driver->user_type.'/2'); ?>" data-toggle="tooltip" title="Reject" onclick="return confirm('Are you sure you want to Reject this user ?');">
                        <span class="glyphicon glyphicon-remove"></span>
                        </a>
                        <?php endif; ?> 
						</td>
                  
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
            <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$driverlist), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script>
	function inactive(id){
		var res = confirm("Are you sure you want to change this Area status");
		    if(res == true) {
		    	url = "<?php echo e(url('Admin/inactive_active_area')); ?>";
				//alert(url);
		        $.ajax({
		          type:"POST",
		          url: url,
				  data: { "_token": "<?php echo e(csrf_token()); ?>", "id": id },
		          //data: {"id":id}, 
		          success: function(data) { 
			          //alert(data);
			          if(data == 1)
			          { 
				          alert("Status has been changed successfully");
		         			 location.reload();
			          }
		    	}
		 	});
		 }  
		  
	}
	</script>
	<script type="text/javascript">
function deletearea(id) {
	//alert(id);
	var res = confirm("Are you sure you want to delete this Area ?");
     if(res == true) {
		    	url = "<?php echo e(url('Admin/deletearea')); ?>";
				//alert(url);
		        $.ajax({
		          type:"POST",
		          url: url,
				  data: { "_token": "<?php echo e(csrf_token()); ?>", "id": id },
		          //data: {"id":id}, 
		          success: function(data) { 
			          //alert(data);
			          if(data == 1)
			          { 
				          alert("Data has been deleted successfully");
		         			 location.reload();
			          }
		    	}
		 	});
		 }  
}
</script>
<script>
function language122(val){
            var url="<?php echo e(url('Admin/changefaqlanguage')); ?>";
            //var redirectUrl
               $.ajax({
                type: "POST",
                url: url, 
                data: { "_token": "<?php echo e(csrf_token()); ?>", "id": val },
                
                cache: false,
                success: function(data)
                { alert(data);
                 
                    $("#title").html(data).show();
					$("#content").html(data).show();
					  $("#tabledata").html(data).show();
					  
                }
           });
          }
 </script>
 <script>
function language(val){
	//alert(val);
           window.location.href = "<?php echo e(url('Admin/changefaqlanguage')); ?>" + '/' + val;
          }
 </script>
  




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>