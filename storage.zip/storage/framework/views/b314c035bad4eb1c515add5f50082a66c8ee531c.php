<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php if(isset($page_title)): ?><?php echo e($page_title); ?> <?php else: ?> 'PDF' <?php endif; ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('public/pdf/css/style.css')); ?>" media="all" />
  </head>
  <body>
    <header class="clearfix">
        <div id="logo">
            <img src="<?php echo e(asset('public/pdf/image/logo.png')); ?>">
        </div>
        <h1><?php if(isset($page_title)): ?><?php echo e($page_title); ?><?php endif; ?></h1>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>
        
    </footer>
  </body>
</html>