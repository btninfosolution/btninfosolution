<?php $__env->startSection('page-css'); ?>
<style>
label.error,span.phn_err, .mail_err {
  color:red;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/sub-admins/2')); ?>"><i class="fa fa-user-secret"></i> Sub Admin List</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
            <form action="<?php echo e(url('Admin/add-subadmin')); ?>" method="post"  id="subadmin_add">
            <?php echo e(csrf_field()); ?>

            <?php if(count($errors) > 0): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php foreach($errors->all() as $error): ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; ?>
                  </ul>
              </div>
            <?php endif; ?>
              <div class="box-body">
                <div class="form-group">
                  <label >Name<span class="text-danger">*</span></label>
                  <input type="text" name="full_name" class="form-control"  placeholder="Enter Name" value="<?php echo e(old('full_name')); ?>">
                </div>
                <div class="form-group">
                  <label >Phone Number<span class="text-danger">*</span></label>
                  <div class="input-group">
                  <span class="input-group-addon">
                    +965 
                  </span>
                  <input type="number" name="phone_number" class="form-control" id="phone" placeholder="Enter Phone Number" value="<?php echo e(old('phone_number')); ?>">
                  
                </div>
                <span id="err-phn" class="phn_err"></span>
                <div>
                <div class="form-group">
                  <label >Email address<span class="text-danger">*</span></label>
                  <input type="email" name="email" class="form-control" id="email"  placeholder="Enter Email" value="<?php echo e(old('email')); ?>">
                  <span id="err-mail" class="mail_err"></span>
                </div>
                <input name="user_type" type="hidden" value="2">

              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary" id="add_manager">Submit</button>
                <button type="reset" class="btn btn-primary" id="add_manager">Reset</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
     
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
  $("#subadmin_add").validate({
      rules: {
        password: "required",
        full_name: {         
           required:true,
           maxlength:250
        },
        email: {
          required:true,
           email:true
        },
        phone_number: {
          required:true,
          digits: true,
          maxlength:8,
          minlength:8
        }
      },
    messages: {
      password: "Password is required",
      phone_number:{
          required:"Please specify Phone Number",
          digits: "Enter digits only",
          maxlength : "Maximum length of Phone Number is 8",
          minlength : "Minimum length of Phone Number is 8"
        } 
      
      }
    }); 
    $("#phone").blur(function(){
      var phone = $("#phone").val();
      var ajax_url = "<?php echo e(url('Admin/phone_exist')); ?>";
      $.ajax({
               type:'POST',
               url: ajax_url,
               data: { "_token": "<?php echo e(csrf_token()); ?>", "phone": phone },
               success:function(data) {
                 if(data == 1){
                  $("#phone").val("");
                  $("#err-phn").html("Phone Number has already taken.");
                 }
                 else{
                  $("#err-phn").html("");
                 }
               }
            });
    });
    $("#phone").focus(function(){
      $("#err-phn").html("");
    });
    $("#email").blur(function(){
      var email = $("#email").val();
      var ajax_url = "<?php echo e(url('Admin/email_exist')); ?>";
      $.ajax({
        type:'POST',
        url: ajax_url,
        data: { "_token": "<?php echo e(csrf_token()); ?>", "email": email },
        success:function(data) {
          if(data == 1){
          $("#email").val("");
          $("#err-mail").html("Email address has already taken.");
          }
          else{
          $("#err-mail").html("");
          }
        }
      });
    });
    $("#email").focus(function(){
      $("#err-mail").html("");
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>