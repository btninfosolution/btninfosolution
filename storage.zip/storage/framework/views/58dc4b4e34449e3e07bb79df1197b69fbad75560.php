<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
     <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>
   <body class="bg-theme bg-theme1">
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
         <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
               <div class="col-sm-9">
                  <h4 class="page-title">Expense</h4>
               </div>
               <div class="col-sm-3">
                  <div class="btn-group float-sm-right">
                     <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
                     <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
                     <span class="caret"></span>
                     </button>
                     <div class="dropdown-menu">
                        <a href="javaScript:void();" class="dropdown-item">Action</a>
                        <a href="javaScript:void();" class="dropdown-item">Another action</a>
                        <a href="javaScript:void();" class="dropdown-item">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a href="javaScript:void();" class="dropdown-item">Separated link</a>
                     </div>
                  </div>
               </div>
            </div>
            <!-- End Breadcrumb-->
            <hr>
            <div class="row">
               <div class="col-lg-12">
                  <div class="card">
                     <div class="card-body">
                        <ul class="nav nav-tabs nav-tabs-primary">
                           <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#tabe-1"><i class="icon-home"></i> <span class="hidden-xs">Expense Details</span></a>
                           </li>
                        </ul>
                       <form action="<?php echo e(url('save-expense')); ?>" class="form-material" id="formData" name="create_expense" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
                           <!-- Tab panes -->
                           <div class="tab-content">
                              <div id="tabe-1" class="container tab-pane active">
                                 <div class="tab-content mt-3" id="nav-tabContent">
                                    <div class="tab-pane fade active show" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                       <div class="form-row">
                                          <div class="col-md-6 mb-3">
                                             <label for="validationCustom03">Name</label>
                                              <input type="text" class="form-control form-control-rounded" id="name" placeholder="Name" name="name">
                                          </div>
										  <div class="col-md-6 mb-3">
                                             <label for="validationCustom03">Note</label>
                                               <textarea type="text" class="form-control form-control-rounded" id="note" placeholder="Note" name="note"></textarea>
                                          </div>
										   <div class="col-md-6 mb-3">
                                             <label for="validationCustom03">Expense Category</label>
                                          <select id="expense_catogory_id" name="expense_catogory_id"class="custom-select form-control-rounded""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($expense_catogorylist as $group): ?> 
                                       <option value="<?php echo e($group->expense_catogory_id); ?>"><?php echo e($group->expense_catogory_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                          </div>
										    <div class="col-md-6 mb-3">
                                             <label for="validationCustom03">Expense Date</label>
                                               <input type="text" class="form-control form-control-rounded" id="expence_date" placeholder="Expense Date" name="expence_date">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                        </form>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--End Row-->
            <!--End Row-->
            <div class="overlay"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      
     <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
  $("#formData").validate({
    rules: {
        name: {
          required:true,
      },
      amount: {
          required:true,
          digits:true,
           
      },
     
     
    
    },
  messages: {
      name:{
        required:"<?php echo e(trans('messages.355')); ?>",
      } ,
      amount:{
        required:"<?php echo e(trans('messages.356')); ?>",
        digits:"<?php echo e(trans('messages.357')); ?>",
      } ,
     
      
   
    
    }
  });
</script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/css/bootstrap-datepicker.min.css" />
	  
	  <script>
  $(document).ready(function() {
  var date = new Date();
  var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  //var end = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  $('#expence_date').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });
 

  $('#expence_date').datepicker('setDate', today);
});
</script>
   </body>
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>