<!doctype html>
<html class="no-js" lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Leads Summary</h4>
                     </div>
                  </div>
                   <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
               <div class="row" style="padding-top:20px;">
                  <div class="col-md-12">
                     <!--<button type="button" class="btn btn-primary mb-3">New Customer</button>-->
                     <?php if(!empty($addpermission)): ?>
                   
                   <?php else: ?>
                     <a class="btn btn-primary mb-3" href="<?php echo e(url('add-leads')); ?>"></i> New Lead</a>
                     <?php endif; ?>
                     </div>
               </div>
              
               </div>
               <?php echo $__env->make('admin/admin_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
               <div class="row">
                  <!-- data table start -->
                  <div class="col-12 mt-5">
                     <div class="card">
                        <div class="card-body">
                           <h4 class="header-title">Lead</h4>
                           <div class="data-tables">
                              <table id="dataTable" class="text-center">
                                 <thead class="bg-light text-capitalize">
                                    <tr>
                                       <th>
                                          <div class="custom-control custom-checkbox">
                                             <input type="checkbox" class="custom-control-input" id="customCheck1" unchecked>
                                          </div>
                                       </th>
                                       <th>#</th>
                                       <th>Status</th>
                                       <th>Source</th>
                                       <th>Assigned</th>
									   <th>Tag</th>
									   <th>Name</th>
                                       <th>Date Created</th>
                                       <th>Action</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?php $i = 1; ?>
                                    <?php if(!empty($leadslist)): ?>
                                    <?php foreach($leadslist as $cus): ?> 
                                    <?php   $id= Crypt::encrypt($cus->leads_id );?> 
                                    <tr>
                                       <td><input type="checkbox" class="custom-control-input" id="customCheck1" unchecked></td>
                                       <td><?php echo e($i); ?></td>
									    <td><?php echo e($cus->status_name); ?></td>
									    <td><?php echo e($cus->sources_name); ?></td>
										 <td><?php echo e($cus->first_name); ?> <?php echo e($cus->last_name); ?></td>
										  <td><?php echo e($cus->tag_name); ?></td>
                                       <td><?php echo e($cus->name); ?></td>
                                      
                                       <td><?php echo e($cus->created_at); ?></td>
                                       <td> 
                                       <?php if(!empty($editpermission)): ?>
                                       <?php else: ?>
                                       
                                       <a href="<?php echo e(url('leads-edit').'/'.$id); ?>" title="Edit" data-toggle="tooltip"><span class="badge badge-pill badge-primary">Edit</span></a>
                                       <?php endif; ?>
									   <a href ="" class="view" data-id="<?php echo e($cus->leads_id); ?>"  data-toggle="modal" data-target="#exampleModalCenter"><span class="badge badge-pill badge-primary">View</span></a>
									   
									 <!--   <a data-id="<?php echo e($cus->is_deleted); ?>"href="<?php echo e(url('delete-record')); ?>?status_data=<?php echo e(Crypt::encrypt($cus->leads_id.'&tbl_leads&leads_id&'.$cus->is_deleted.'&leads'.'&0')); ?>" title="Delete" onclick="return confirm('Are you sure you want to delete this lead ?');" data-toggle="tooltip"><span class="badge badge-pill badge-danger">Delete</span></a> -->
									   </td>
                                    <?php $i++; ?>
                                    <?php endforeach; ?>
                                    <?php endif; ?> 
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
		 <div class="modal fade" id="exampleModalCenter" style="display: none; padding-left:0px;" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered" role="document" style="max-width:900px;">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title">Lead Details</h5>
            <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col-md-12">
                  <input type="hidden" name="leadid" value="20">
                  <!-- Tab panes -->
                  <div class="tab-content">
                     <!-- from leads modal -->
                    <!-- <div class="lead-wrapper">
                        
                        <a data-toggle="tooltip" class="btn btn-default pull-right lead-print-btn lead-top-btn lead-view mleft5" onclick="print_lead_information(); return false;" data-placement="top" title="" href="#" data-original-title="Print">
                        <i class="fa fa-print"></i>
                        </a>
                        <div class="lead-edit hide">
                           <button type="button" class="btn btn-info pull-right mleft5 lead-top-btn lead-save-btn" onclick="document.getElementById('lead-form-submit').click();">
                           Save          </button>
                        </div>
                        <a href="#" data-toggle="tooltip" data-title="" class="btn btn-success pull-right lead-convert-to-customer lead-top-btn lead-view" onclick="convert_lead_to_customer(20); return false;" data-original-title="" title="">
                        <i class="fa fa-user-o"></i>
                        Convert to customer      </a>
                        <div class="clearfix no-margin"></div>
                        <hr class="hr-panel-heading">
                     </div>-->
                     <div class="lead-view row" id="leadViewWrapper">
                        <div class="col-md-4 col-xs-12 lead-information-col">
                           <div class="lead-info-heading">
                              <h4 class="no-margin font-medium-xs bold">
                                 Lead Information               
                              </h4>
                           </div>
                           <p class="text-muted lead-field-heading no-mtop">Name</p>
                           <p class="bold font-medium-xs lead-name" id="name"></p>
                           <p class="text-muted lead-field-heading">Position</p>
                           <p class="bold font-medium-xs"id="position"></p>
                           <p class="text-muted lead-field-heading">Email Address</p>
                           <p class="bold font-medium-xs"id="email"></p>
                           <p class="text-muted lead-field-heading"id="website">Website</p>
                           <p class="bold font-medium-xs">-</p>
                           <p class="text-muted lead-field-heading">Phone</p>
                           <p class="bold font-medium-xs" id="phone"></p>
                           <p class="text-muted lead-field-heading">Company</p>
                           <p class="bold font-medium-xs"id="company"></p>
                           <p class="text-muted lead-field-heading">Address</p>
                           <p class="bold font-medium-xs"id="address"></p>
                           <p class="text-muted lead-field-heading">City</p>
                           <p class="bold font-medium-xs"id="city"></p>
                           <p class="text-muted lead-field-heading">State</p>
                           <p class="bold font-medium-xs"id="state"></p>
                           <p class="text-muted lead-field-heading">Country</p>
                           <p class="bold font-medium-xs"id="country"></p>
                           <p class="text-muted lead-field-heading">Zip Code</p>
                           <p class="bold font-medium-xs"id="zipcode"></p>
                        </div>
                        <div class="col-md-4 col-xs-12 lead-information-col">
                           <div class="lead-info-heading">
                              <h4 class="no-margin font-medium-xs bold">
                                 General Information               
                              </h4>
                           </div>
                           <p class="text-muted lead-field-heading no-mtop">Status</p>
                           <p class="bold font-medium-xs mbot15"id="status"></p>
                           <p class="text-muted lead-field-heading">Source</p>
                           <p class="bold font-medium-xs mbot15"id="source"></p>
                           
                           <p class="text-muted lead-field-heading">Assigned</p>
                           <p class="bold font-medium-xs mbot15"id="assigned"></p>
                           <p class="text-muted lead-field-heading">Tags</p>
                           <p class="bold font-medium-xs mbot10">
                           </p>
                           <div class="tags-labels" id="tag"><span class="label label-tag tag-id-7"><span class="tag"></span></span></div>
                           <div class="clearfix"></div>
                           <p></p>
                           <p class="text-muted lead-field-heading">Created</p>
                           <p class="bold font-medium-xs"><span class="text-has-action" data-toggle="tooltip" id="created_date" ></span></p>
                           
                        </div>
                        <div class="col-md-4 col-xs-12 lead-information-col">
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-md-12">
                           <p class="text-muted lead-field-heading">Description</p>
                           <p class="bold font-medium-xs"id="description"></p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
           <!-- <button type="button" class="btn btn-primary">Save changes</button>-->
         </div>
      </div>
   </div>
</div>
		 
         <footer>
            <div class="footer-area">
               <p>© Copyright 2018. All right reserved. Template by <a href="https://colorlib.com/wp/">Colorlib</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
      <div class="offset-area">
         <div class="offset-close"><i class="ti-close"></i></div>
         <ul class="nav offset-menu-tab">
            <li><a class="active" data-toggle="tab" href="#activity">Activity</a></li>
            <li><a data-toggle="tab" href="#settings">Settings</a></li>
         </ul>
         <div class="offset-content tab-content">
            <div id="activity" class="tab-pane fade in show active">
               <div class="recent-activity">
                  <div class="timeline-task">
                     <div class="icon bg1">
                        <i class="fa fa-envelope"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-check"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Added</h4>
                        <span class="time"><i class="ti-time"></i>7 Minutes Ago</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>You missed you Password!</h4>
                        <span class="time"><i class="ti-time"></i>09:20 Am</span>
                     </div>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="fa fa-bomb"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Member waiting for you Attention</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="ti-signal"></i>
                     </div>
                     <div class="tm-title">
                        <h4>You Added Kaji Patha few minutes ago</h4>
                        <span class="time"><i class="ti-time"></i>01 minutes ago</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg1">
                        <i class="fa fa-envelope"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Ratul Hamba sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Hello sir , where are you, i am egerly waiting for you.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="fa fa-bomb"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="ti-signal"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
               </div>
            </div>
            <div id="settings" class="tab-pane fade">
               <div class="offset-settings">
                  <h4>General Settings</h4>
                  <div class="settings-list">
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Notifications</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch1" />
                              <label for="switch1">Toggle</label>
                           </div>
                        </div>
                        <p>Keep it 'On' When you want to get all the notification.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show recent activity</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch2" />
                              <label for="switch2">Toggle</label>
                           </div>
                        </div>
                        <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show your emails</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch3" />
                              <label for="switch3">Toggle</label>
                           </div>
                        </div>
                        <p>Show email so that easily find you.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show Task statistics</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch4" />
                              <label for="switch4">Toggle</label>
                           </div>
                        </div>
                        <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Notifications</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch5" />
                              <label for="switch5">Toggle</label>
                           </div>
                        </div>
                        <p>Use checkboxes when looking for yes or no answers.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- offset area end -->
      <!-- jquery latest version -->
      <script src="<?php echo e(asset('public/assets/js/vendor/jquery-2.2.4.min.js')); ?>"></script>
      <!-- bootstrap 4 js -->
      <script src="<?php echo e(asset('public/assets/js/popper.min.js')); ?>"></script>
      <script src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>
      <script src="<?php echo e(asset('public/assets/js/owl.carousel.min.js')); ?>"></script>
      <script src="<?php echo e(asset('public/assets/js/metisMenu.min.js')); ?>"></script>
      <script src="<?php echo e(asset('public/assets/js/jquery.slimscroll.min.js')); ?>"></script>
      <script src="<?php echo e(asset('public/assets/js/jquery.slicknav.min.js')); ?>"></script>
      <!-- Start datatable js -->
      <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
      <!-- others plugins -->
      <script src="<?php echo e(asset('public/assets/js/plugins.js')); ?>"></script>
      <script src="<?php echo e(asset('public/assets/js/scripts.js')); ?>"></script>
	   <script type="text/javascript">
        $( "a.view" ).on("click", function() {    
           var id = $(this).attr('data-id');
           var url = "<?php echo e(url('get-leaddata')); ?>";
           if(id){
             $.ajax({
              type: "POST",        
              url : url,
              data:({
                  "_token": "<?php echo e(csrf_token()); ?>",
                   id : id,
                  //role_id : role_id,
              }),
               cache: false,
               success: function (data) {        
                    		   
                  // if(data.response){
                  //var result = data.result; 
                   console.log(data) ;  
                   var user_general_data = data.user_general_data;     
                   $('#name').html(user_general_data.name); 
                   $('#position').html(user_general_data.position); 
                   $('#email').html(user_general_data.email);
                   $('#website').html(user_general_data.website);
                   $('#phone').html(user_general_data.phone); 
                   $('#company').html(user_general_data.company);
                   $('#address').html(user_general_data.address);
				   $('#city').html(user_general_data.city);
				   $('#state').html(user_general_data.state);
				   $('#country').html(user_general_data.country);
				   $('#zipcode').html(user_general_data.zipcode);
				   $('#description').html(user_general_data.description);
				    $('#source').html(user_general_data.sources_name);
					$('#status').html(user_general_data.status_name);
					$('#assigned').html(user_general_data.first_name);
					$('#tag').html(user_general_data.tag_name);
					$('#created_date').html(user_general_data.created_at);
                   $('#exampleModalCenter').modal('show');   
                // }
               },
               error: function(xhr, status, error) {
                 //var err = eval("(" + xhr.responseText + ")");                   
                 //console.log(err.Message);
               }
             });
           }
            
           //$('#myModal').modal('show');  
        });

        $( "a.change-status" ).on("click", function() {    
           $(this).parent().parent().find('li.active').removeClass("active");
           $(this).parent().addClass('active');
        });
      </script>
   </body>
</html>