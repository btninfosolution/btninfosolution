<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>

<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 
    <div class="row">
        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
				
                    <tr>
                        <th >Sl No</th>
                        <th>Manager Name</th>
                        <th>Total Consignment Price</th>
						 <th>Action</th>
                        
                    </tr>
					<tbody id="tabledata">
                    <?php $i = 1; ?>
                    <?php foreach($Paymentdata as $payment): ?> 
					 <?php   $id= Crypt::encrypt($payment->manager_id);?>	

                    <tr>
					<td class="center"><?php echo e($i); ?> </td>
                        <td class="center" name="title" id="title"><?php echo e($payment->full_name); ?> </td>
						<?php if($payment->sum ==""): ?> 
						<td class="center" name="content" id="content">0 </td>
						<?php else: ?> 
						<td class="center" name="content" id="content"><?php echo e($payment->sum); ?> </td>
						<?php endif; ?> 
						<td class="center">
						 <a href="<?php echo e(url('Admin/paymentdetail').'/'.$id); ?>" data-toggle="tooltip" title="Detail">
                         <span class="glyphicon glyphicon-th-list"></span>
                         </a>
						  
				
						</td>
                  
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>