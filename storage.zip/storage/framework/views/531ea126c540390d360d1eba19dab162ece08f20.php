<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="index.html">
       <img src="assets/images/logo-icon.png" class="logo-icon" alt="logo icon">
       <h5 class="logo-text">Dashtreme Admin</h5>
     </a>
   </div>
   <ul class="sidebar-menu do-nicescrol">
      <li class="sidebar-header">MAIN NAVIGATION</li>
      <li>
        <a href="<?php echo e(url('admin-dashboard')); ?>">
          <i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span>
        </a>
      </li>

             <?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'customer'||$segment == 'add-customer'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('customer')); ?>"><i class="fa fa-user"></i> <span>Customers</span>
						  </a>
						  </li>
              <?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'group'||$segment == 'add-group'||$segment == 'group-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('group')); ?>"><i class="fa fa-user"></i> <span>Group</span>
						  </a>
						  </li>
            <?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'tag'||$segment == 'add-tags'||$segment == 'tag-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('tags')); ?>"><i class="fa fa-user"></i> <span>Tags</span>
						  </a>
						  </li>
              <?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'tax'||$segment == 'add-tax'||$segment == 'tax-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('tax')); ?>"><i class="fa fa-user"></i> <span>Tax</span>
						  </a>
						  </li>
            <?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'item'||$segment == 'add-item'||$segment == 'item-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('item')); ?>"><i class="fa fa-user"></i> <span>Item</span>
						  </a>
						  </li>
              <?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'status'||$segment == 'add-status'||$segment == 'status-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('status')); ?>"><i class="fa fa-user"></i> <span>Lead Status</span>
						  </a>
						  </li>
               <?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'leads'||$segment == 'add-leads'||$segment == 'leads-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('leads')); ?>"><i class="fa fa-user"></i> <span>Leads</span>
						  </a>
						  </li>
                <?php  $segment = Request::segment(1);?>
						  <li class="<?php if($segment == 'sources'||$segment == 'add-sources'||$segment == 'sources-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('sources')); ?>"><i class="fa fa-user"></i> <span>Lead Sources</span>
						  </a>
						  </li>

              <li class="<?php if($segment == 'expense-category'||$segment == 'add-expense-category'||$segment == 'expense-category-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('expense-category')); ?>"><i class="fa fa-list-alt"></i> <span>Expense Category</span>
						  </a>
						  </li>
                 <?php if(session('user_type')==1): ?>
               <li class="<?php if($segment == 'expense'||$segment == 'add-expense'||$segment == 'expense-edit'){ echo 'active';} ?>">
						  <a href="<?php echo e(url('expense')); ?>"><i class="fa fa-list-alt"></i> <span>Expense</span>
						  </a>
						  </li>
                <?php endif; ?>

      


    </ul>
   
   </div>