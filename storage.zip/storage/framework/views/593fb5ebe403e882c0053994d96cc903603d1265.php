<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/contacts')); ?>"><i class="fa fa-user-secret"></i> Contact List</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-8">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
           <form action="<?php echo e(url('Admin/addcontact')); ?>" method="POST" id="formData1">
		    <?php echo e(csrf_field()); ?>	<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>

              <div class="box-body">
			  <div class="form-group">
                        <label class="exampleInputEmail1"><?php echo e('Contact Type'); ?>&nbsp; :</label>
                        <!--<div class="form-control" >   -->                  
                            <select  id="contype"  class="form-control select2"style="width: 100%;" name="contype" onchange ="contacttype(this.value)">
                                <option value="">Select Contact type</option>
                                <?php foreach($contacttype as $val): ?>
                                 <option value="<?php echo e($val->contact_type_id); ?>"><?php echo e($val->contact_type_name); ?></option>
                                <?php endforeach; ?>
                            </select>    
                       <span class="contypeErr error" style="color: red;"></span>							
                        <!--</div>-->
                    </div>
                <div class="form-group" style='display:none;' id="title">
                  <label for="exampleInputEmail1">Address Title</label>
                  <input type="text" class="form-control" id="title1" name="title" placeholder="Enter title">
				  <span class="titleErr error" style="color: red;"></span>
                </div>
                <div class="form-group" style='display:none;' id="pickup_address_div">
                  <label for="exampleInputEmail1">Contact Address(English)</label>
                  <input type="text" class="form-control"  id="pickup_address" name="pickup_address" placeholder="Enter contact">
				  <span class="textErr error" style="color: red;"></span>
                </div>
				<div class="form-group" style='display:none;' id="pickup_address_arabic">
                  <label for="exampleInputEmail1">Contact Address(Arabic)</label>
                  <input type="text" class="form-control"  id="pickup_address_ara" name="pickup_address_ara" placeholder="Enter contact">
				  <span class="textarabicErr error" style="color: red;"></span>
                </div>
				<input type="hidden"   id="pickup_latitude" name="pickup_latitude" >
				<input type="hidden"   id="pickup_longitude" name="pickup_longitude" >
				<div class="form-group" style='display:none;' id="email">
                  <label for="exampleInputEmail1">Email Id</label>
                  <input type="text" class="form-control" id="email1"name="email" placeholder="Enter email">
				  <span class="emailErr error" style="color: red;"></span>
                </div>
					<div class="form-group" style='display:none;' id="phone">
                  <label for="exampleInputEmail1">Phone No</label>
                  <input type="number" class="form-control" id="phone1" name="phone" placeholder="Enter phone no">
				  <span class="phoneErr error" style="color: red;"></span>
                </div>
               
               
               
                
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  onclick="return formValidationAdd();"class="btn btn-primary">Submit</button>
				<button type="reset"  class="btn btn-primary">Reset</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
          </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('google_api_key')); ?>&libraries=places"></script>
<script type="text/javascript">
	$(document).ready(function(){
		using_autocomplete();
	});
	function contacttype(val){
		var hid = val;
		if(hid =='1'){
			$("#title").show();
			$("#pickup_address_div").show();
			$("#pickup_address_arabic").show();
			$("#email").hide();
			$("#phone").hide();
			
			return false;
		}
		if(hid =='2'){
			$("#email").show();
			$("#title").hide();
			$("#pickup_address_div").hide();
			$("#pickup_address_arabic").hide();
			$("#phone").hide();
			return false;
		}
		if(hid =='3'){
			$("#phone").show();
			$("#title").hide();
			$("#pickup_address_div").hide();
			$("#pickup_address_arabic").hide();
			$("#email").hide();
			return false;
		}
	}

	function formValidationAdd(){			
		var data = new FormData($('#formData1')[0]);
		var contype = $("#contype").val();
		var title = $("#title1").val();
		var address = $("#pickup_address").val();
		var addressarabic = $("#pickup_address_ara").val();
		var email = $("#email1").val();
		var emailRegexStr = /^[a-zA-Z0-9/+._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
		var isvalid = emailRegexStr.test(email); 
		var arabic = /[\u0600-\u06FF]/;
		var phone = $("#phone1").val();
		$(".contypeErr").html("");
		//$(".contypeErr").hide("");
		$(".titleErr").html("");
	//$(".titleErr").hide("");
		$(".textErr").html("");
		//$(".textErr").hide("");
		$(".textarabicErr").html("");
	//	$(".textarabicErr").hide("");
		$(".emailErr").html("");
		//$(".emailErr").hide("");
		$(".phoneErr").html("");
		//$(".phoneErr").hide("");

		if(contype==0){
			//$(".contypeErr").slideDown('slow');
			$(".contypeErr").html("Select Contact Type.").show();
			$("#contype").focus();
			return false;
		}
		if(contype==1 && title==''){
		//	$(".titleErr").slideDown('slow');
			$(".titleErr").html("Title field required.").show();
			$(".textErr").html("Address field required.").show();
			$(".textarabicErr").html("Arabic Address field required.").show();
			$("#title1").focus();
			return false;
		}
		if(contype==1 && address==''){
			//$(".textErr").slideDown('slow');
			$(".textErr").html("Address field required.").show();
			$(".textarabicErr").html("Arabic Address field required.").show();
			$("#pickup_address").focus();
			return false;
		}
		if(contype==1 && addressarabic==''){
		//	$(".textarabicErr").slideDown('slow');
			$(".textarabicErr").html("Arabic Address field required.");
			$("#pickup_address_ara").focus();
			return false;
		}
		if(contype==1 && arabic.test(addressarabic)==false){
		//	$(".textarabicErr").slideDown('slow');
			$(".textarabicErr").html("Please Write only arabic language.").show();
			$("#pickup_address_ara").focus();
			return false;
		}
		if( contype==2 &&!isvalid){
             		//$(".emailErr").slideDown('slow');
             		$(".emailErr").html("Please enter valid Email address.").show();
             		$("#email1").focus();
             		return false;
             	}
		 if( contype==3 && phone.length != 8){
       // $(".phoneErr").slideDown('slow');
        $(".phoneErr").html("Please enter 8 digit phone number.").show();
        $("#phone1").focus();
        return false;
             	}
	}
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>