<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <?php if(session('user_type') == 1): ?>
        <li class="treeview" sublink="edit-subadmin">
          <a href="javascript:void(0);">
            <i class="fa fa-user-secret"></i>
            <span>Sub Admin </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/sub-admins/2')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add-subadmin')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li> 
        <?php endif; ?>
        
      <?php if(session('user_type') == 1 || session('user_type') == 2): ?>   

        <li class="treeview" sublink="edit-manager">
          <a href="javascript:void(0);">
            <i class="fa fa-user-secret"></i>
            <span>Managers</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/managers')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add-manager')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li>
		<li class="treeview" sublink="driver-list">
          <a href="javascript:void(0);">
            <i class="fa fa-user-secret"></i>
            <span>Drivers</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/all-driver')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
          </ul>
        </li>

        <?php endif; ?> 
        <?php if(session('user_type') == 3): ?>    
        <li class="treeview" sublink="driver-list">
          <a href="javascript:void(0);">
            <i class="fa fa-user-secret"></i>
            <span>Drivers</span>
          </a>
          <ul class="treeview-menu">
          <?php $user_id = Crypt::encrypt(session('user_id'));?>
            <li><a href="<?php echo e(url('Admin/driver-list').'/'.$user_id); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add-driver')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li>

        <?php endif; ?>
        <?php if(session('user_type') != 3): ?>  <li><a href="<?php echo e(url('Admin/customers/5')); ?>"><i class="fa fa-user"></i> <span>Customers</span></a></li> <?php endif; ?>
        <li class="treeview" sublink="consignments">
          <a href="javascript:void(0);">
            <i class="fa fa-tty"></i>
            <span>consignments</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/consignments')); ?>"><i class="fa fa-circle-o"></i>All List</a></li>
            <li><a href="<?php echo e(url('Admin/refund-consignments')); ?>"><i class="fa fa-circle-o"></i>Refund List</a></li>
          </ul>
        </li>
        <?php if(session('user_type') != 3): ?>
        <li><a href="<?php echo e(url('Admin/editsetting')); ?>"><i class="fa fa-cog"></i> <span>Setting Module</span></a></li>
        <li><a href="<?php echo e(url('Admin/payment-master')); ?>"><i class="fa fa-dollar"></i> <span>Payment </span></a></li>
        <li class="treeview"  sublink="editarea">
        <a href="javascript:void(0);">
        <i class="fa fa-user-secret"></i>
        <span>Available Area</span>
        </a>
        <ul class="treeview-menu">
        <li><a href="<?php echo e(url('Admin/availble-area')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
        <li><a href="<?php echo e(url('Admin/add-availble-area')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
        </ul>
        </li>
        <li class="treeview" sublink="editfaq" >
          <a href="javascript:void(0);">
            <i class="fa fa-truck"></i>
            <span>Vehicle </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/vehicles')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add-vehicles')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li>
        <li class="treeview" sublink="building-list" >
          <a href="javascript:void(0);">
            <i class="fa fa-user-secret"></i>
            <span>Building Type</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/building')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add-building')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li>
        <li class="treeview" sublink="building-list" >
          <a href="javascript:void(0);">
            <i class="fa fa-tag fa-lg"></i>
            <span>Promocode</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/promocode')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add-promocode')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li>
        <li class="treeview" sublink="editfaq" >
          <a href="javascript:void(0);">
            <i class="fa fa-user-secret"></i>
            <span>FAQ's</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/faqs')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add_faq')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li>

        <li class="treeview"  sublink="terms">
          <a href="javascript:void(0);">
            <i class="fa fa-user-secret"></i>
            <span>Terms & Conditions</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/terms')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add_terms')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li>
		 <li class="treeview" sublink="contacts">
          <a href="javascript:void(0);">
            <i class="fa fa-user-secret"></i>
            <span>Contact Us</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/contacts')); ?>"><i class="fa fa-circle-o"></i> List</a></li>
            <li><a href="<?php echo e(url('Admin/add_contacts')); ?>"><i class="fa fa-circle-o"></i> Add</a></li>
          </ul>
        </li>
    <?php endif; ?>
        <!--<li><a href="<?php echo e(url('Admin/contacts')); ?>"><i class="fa fa-tty"></i> <span>Contact Us</span></a></li>-->
      
      <?php if(session('user_type') == 1): ?>
        <li class="treeview" sublink="reports">
          <a href="javascript:void(0);">
            <i class="fa fa-table"></i>
            <span>Report</span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('Admin/monthly-report')); ?>"><i class="fa fa-circle-o"></i>Monthly</a></li>
            <li><a href="<?php echo e(url('Admin/refund-report')); ?>"><i class="fa fa-circle-o"></i>Refunds</a></li>
          </ul>
        </li>
      <?php endif; ?>

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
