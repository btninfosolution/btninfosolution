<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!-- right column -->
        <div class="col-md-12">
        <?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<h4><?php echo e($errors->first()); ?></h4>
<?php endif; ?>
          <!-- Horizontal Form -->
        <!--  <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Horizontal Form</h3>
            </div> -->
            <!-- /.box-header -->
            <!-- form start -->
        <?php if(count($consignment_data) > 0): ?>
        <?php $i = 0;?>
       
        <?php foreach($consignment_data as $consign): ?>
        <?php if($i < 1): ?>
        <!-- right column -->
        <div class="col-md-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <!-- /.box-header -->
            <!-- form start -->
            <form class="form-horizontal">
              <div class="box-body">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Customer Name:</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->cust_name); ?>"  readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Customer Phone No.</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->cust_phn); ?>" readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Driver Name:</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->drv_name); ?>" readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Driver Phone No.</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->drv_phn); ?>" readonly>
                  </div>
                </div>
				 <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Manager Name</label>
					<div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->mng_name); ?>" readonly>
                  </div>
                </div>
				 <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Manager Phone No.</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->mng_phn); ?>" readonly>
                  </div>
                </div>

				 <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Consignment Status</label>
					<div class="col-sm-10">
                    <?php $status = ($consign->consignment_status == 1 ) ? 'Asigned' : 'Not asigned'?>
                    <input type="text" class="form-control" value="<?php echo e($status); ?>" readonly>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Pickup Date Time</label>
					<div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->pickup_date_time); ?>" readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Number Of Delivery</label>
					<div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->number_of_delivery); ?>" readonly>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Consignment Cost</label>
					<div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->consignment_cost); ?>" readonly>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Coupon Code</label>
					<div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->coupon_code); ?>" readonly>
                  </div>
                </div>

                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Coupon Amount</label>
					<div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->coupon_amount); ?>" readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Payable Cost</label>
					<div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->payable_cost); ?>" readonly>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Pickup Address</label>
					      <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->pickup_address); ?>" readonly>
                  </div>
                </div>
                <?php  $i++; ?>
                <?php endif; ?>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Delivery Address</label>
					      <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?php echo e($consign->drop_off_address); ?>" readonly>
                  </div>
                </div>

                <?php endforeach; ?>
              </div>
              <!-- /.box-body -->
            </form>
          </div>

            <?php else: ?>
            No Data Found
            <?php endif; ?>
          </div>
          <!-- /.box -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>