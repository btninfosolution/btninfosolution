<?php $__env->startSection('page-css'); ?>
<style>
label.error {
  color:red;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <?php if(count($users)>0): ?>
        --<b>
            <?php echo e($users[0]->company_name); ?>

        </b>
        <?php endif; ?>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $login_user_id = session('user_id');
    $encry_id =  Crypt::encrypt($login_user_id);
?>
<div class="box">
    <form action="<?php echo e(url('Admin/driver-list/').'/'.$encry_id); ?>" method="POST"  id="user_filter" >
    <?php echo e(csrf_field()); ?>

    <div class="box-body">
        <div class="form-group col-md-4">
                        <label >Phone or Email <span class="text-danger">*</span></label>
                        <input type="text" name="keyword" id="keyword" class="form-control"  placeholder="Enter Phone Number Or Email" value="<?php if(isset($keyword)): ?><?php echo e($keyword); ?><?php endif; ?>">

        </div>
        </div>
        <div class="box-footer">
                            <button type="submit"   class="btn btn-primary">Filter</button>
                            <button type="button" id="reset_btn"  class="btn btn-primary">Reset</button>
        </div>


    </form>
</div>
    <div class="row">
        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Phone Number</th>
                        <th>Email</th>
                        <th>Vehical Type</th>
                        <th>Licence</th>
                        <th>Rating</th>
                        <th>Register at</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    <?php $no = ($users->currentpage()-1)* $users->perpage() + 1; ?>
                    <?php foreach($users as $user): ?>
                    
                    <tr>
                        <th style="width: 10px"><?php echo e($no); ?></th>
                        <th><img src="<?php echo e(url('public/uploads/profile').'/'.$user->img_path); ?>" style="width:50px;height:30px;" alt="Image" /> </th>
                        <th><?php echo e(ucfirst($user->full_name)); ?></th>
                        <th><?php echo e($user->phone_no); ?></th>
                        <th><?php echo e($user->email); ?></th>
                        <th><?php echo e($user->type); ?></th>
                        <th><?php echo e($user->licence_no); ?></th>
                        <th><?php echo e($user->avg_rating); ?></th>
                        <th><?php echo e(date("d-m-Y H:i:s",strtotime($user->created_at))); ?></th>
                        <th><?php if($user->is_blocked == 1): ?> Blocked <?php else: ?> Unblocked <?php endif; ?></th>
                        <?php $driver_id = Crypt::encrypt($user->user_id);
                        $login_user_id = session('user_id');
                        ?>
                       
                            <th>
                            <?php if($user->parent_user_id == $login_user_id): ?>
                                <a href="<?php echo e(url('Admin/driver-payment-detail').'/'.$driver_id); ?>" data-toggle="tooltip" title="Payment details">
                                    <span class="glyphicon glyphicon-th-list"></span>
                                </a>
                                <a href="<?php echo e(url('Admin/edit-user').'/'.$driver_id); ?>" data-toggle="tooltip" title="Edit">
                                    <span class="glyphicon glyphicon-pencil"></span>
                                </a>

                                <a href="<?php echo e(url('Admin/delete-user').'/'.$driver_id.'/'.$user->user_type); ?>" data-toggle="tooltip" title="Delete" onclick="return confirm('Are you sure you want to delete this user ?');">
                                    <span class="glyphicon glyphicon-trash"></span>  
                                </a>
                            <?php endif; ?>
                            <?php if($user->is_blocked == 1): ?>
                                <a href="<?php echo e(url('Admin/block-user').'/'.$driver_id.'/'.$user->user_type.'/0'); ?>" data-toggle="tooltip" title="Unblocked" onclick="return confirm('Are you sure you want to Unblocked this user ?');">
                                <span class="glyphicon glyphicon-ban-circle"></span>
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(url('Admin/block-user').'/'.$driver_id.'/'.$user->user_type.'/1'); ?>" data-toggle="tooltip" title="Blocked" onclick="return confirm('Are you sure you want to blocked this user ?');">
                                <span class="glyphicon glyphicon-check"></span></a>


                            <?php endif; ?>
                        

                            </th>
                       
                    </tr>  
                    <?php $no++; ?>
                    <?php endforeach; ?>
                </table>
            </div>
            <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$users->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
$("#user_filter").validate({
    rules: {
        keyword: "required",
    }
});

$("#reset_btn").click(function(){
    //$("#user_filter")[0].reset();
    $("#keyword").val("");
    window.location.href = "<?php echo e(url('Admin/driver-list/').'/'.$manager_id); ?>";
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>