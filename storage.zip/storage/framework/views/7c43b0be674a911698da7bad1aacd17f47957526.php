<?php $__env->startSection('content'); ?>
<div class="alert alert-danger" role="alert">This url not found. <a href="<?php echo e(url('Admin/login')); ?>">Go To Home</a></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_one', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>