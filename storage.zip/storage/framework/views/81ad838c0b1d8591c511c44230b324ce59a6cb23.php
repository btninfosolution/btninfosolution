<?php $__env->startSection('page-css'); ?>
<style>
    .ui-datepicker-calendar {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panle</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header"></div>
        <form action="<?php echo e(url('Admin/refund-report')); ?>" method="POST" autocomplete="off">
            <div class="box-body">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-3" >
                    <label>Month</label>
                    <input type="text" class="form-control" value="<?php echo e($month_of); ?>" name="month_of" id="month_of">
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="filter" value="1">Filter</button>
                <button type="submit" class="btn btn-info" name="filter" value="2" >Reset</button>
                <button type="submit" class="btn btn-warning" name="filter" value="3" >Download</button>
            </div>
        </form>    
    </div>

    <div class="box">
        <div class="box-body">
            <div style="width:100%; overflow-y:auto;">
            <table class="table table-bordered">
                <tr>
                    <th>Consignment Id</th>
                    <th>Consignment Date</th>
                    <th>Consignment Cost</th>
                    <th>Customer Name</th>
                    <th>Trunsaction Number</th>
                    <th>Trunsaction Date</th>
                    <th>Trunsaction Amount</th>
                </tr>
                <?php foreach($consignments as $consign): ?>
                <tr>
                    <td><?php echo e($consign->consignment_id); ?></td>
                    <td><?php echo e(date("d-m-Y H:i:s",strtotime($consign->pickup_date_time))); ?></td>
                    <td><?php echo e(round($consign->payable_cost,2)); ?></td>
                    <td><?php echo e(ucfirst($consign->cust_name)); ?></td>
                    <td><?php echo e($consign->refund_transaction_number); ?></td>
                    <td><?php echo e(date("d-m-Y",strtotime($consign->refund_date_time))); ?></td>
                    <td><?php echo e($consign->refund_amount); ?></td>
                </tr>  
                
                <?php endforeach; ?>
            </table>
            </div>
        </div>
        <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$consignments->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
    $(function() {
        $( "#month_of" ).datepicker({
            changeMonth: true,
            changeYear: true,
            //dateFormat: 'yy-mm',
            maxDate:0,
            showButtonPanel: true,
            dateFormat: 'M yy',
            onClose: function(dateText, inst) {
                $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>