<?php $__env->startSection('page-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="box">
        <div class="box-header">
            <?php if($errors->any()): ?>
            <h4><?php echo e($errors->first()); ?></h4>
            <?php endif; ?>  
        </div>
        <form action="<?php echo e(url('Admin/refund-consignments')); ?>" method="POST" id="formData1">
            <div class="box-body">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-4" >
                    <label>Refund Status</label>
                        <select name="refund_status" class="form-control">
                            <option value="" selected>Select status</option>
                            <?php if(!empty($refund_status_values)): ?>
                            <?php foreach($refund_status_values as $ky=>$vl): ?>
                                <?php if($ky==$refund_status): ?>
                                    <option value="<?php echo e($ky); ?>" selected><?php echo e($vl); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($ky); ?>"><?php echo e($vl); ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </select>                
                </div>
                
                <div class="form-group col-md-4" >
                    <label>Refund Date</label>
                    <input type="text" class="form-control"   value="<?php echo e($refund_date); ?>" id="date" name="refund_date" placeholder="Enter Date">
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="filter" value="1">Filter</button>
                <button type="submit" class="btn btn-info" name="filter" value="2">Reset</button>
            </div>
        </form>    
    </div>

    <div class="box">
        <div class="box-body">
            <table class="table table-bordered">
                <tr>
                    <th>Consignment Id</th>
                    <th>Consignment Date</th>
                    <th>Consignment Cost</th>
                    <th>Customer Name</th>
                    <th>Refund Amount</th>
                    <th>Refund Status</th>
                    <th>Refund Details</th>
                    <th>Action</th>
                </tr>
                <?php foreach($consignments as $consign): ?>
                <tr>
                    <td><?php echo e($consign->consignment_id); ?></td>
                    <td><?php echo e(date("d-m-Y H:i:s",strtotime($consign->pickup_date_time))); ?></td>
                    <td><?php echo e(round($consign->payable_cost,2)); ?></td>
                    <td><?php echo e(ucfirst($consign->cust_name)); ?></td>
                    <td><?php echo e($consign->refund_amount); ?></td>
                    <td><?php if($consign->refund_status > 0): ?>
                        <?php echo e(@$refund_status_values[$consign->refund_status]); ?>

                    <?php endif; ?></td>
                    <td><?php if($consign->refund_status > 1): ?>
                        <?php echo e('Ref: '.$consign->refund_transaction_number); ?>

                        </br>
                        <?php echo e('On '.date("d-m-Y H:i:s",strtotime($consign->refund_date_time))); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($consign->refund_status == 1): ?>
                            <a href="javascript:void(0);" title="Refund of Amount <?php echo e($consign->refund_amount); ?>" class="refundamount" data-id="<?php echo e($consign->consignment_id); ?>">
                            <span class="glyphicon glyphicon-repeat"></span></a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$consignments->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<!-- modal section --> 
<div class="modal fade" id="modal-payment">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Update refund details of <span id="consId"></span></h4>
            </div>
            <form method="POST" id="consignemntpayment" action="<?php echo e(url('Admin/consingment-refund-update')); ?>">
            <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <div class="form-group">
                        <label >Transaction Number<span class="text-danger">*</span></label>
                        <input type="text" name="transaction_number" class="form-control"  placeholder="Enter Transaction Number">
                        <span id="err-transaction_number" class="msg_err"></span>
                    </div>
                    <div class="form-group">
                        <label >Transaction Date<span class="text-danger">*</span></label>
                        <input type="text" name="transaction_date" id="transaction_date" class="form-control"  placeholder="Enter Transaction Date">
                        <span id="err-transaction_date" class="msg_err"></span>
                    </div>
                    <input type="hidden" name="consignment_id" id="consignment_id" class="form-control">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- end modal --> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script>
$(function() {
    $( "#date" ).datepicker({
	   changeMonth: true,
	   changeYear: true,
	   dateFormat: 'yy-mm-dd',
       maxDate:0,
	});
});

$(document).ready(function(){
    $("#transaction_date").datepicker({
	   changeMonth: true,
	   changeYear: true,
	   dateFormat: 'yy-mm-dd',
       maxDate:0,
	});

    $(".refundamount").bind('click',function(e){
        e.preventDefault();
        $("#consignment_id").val('');
        $("#consId").val('');
        let cId = $(e.currentTarget).data("id");
        if(cId > 0){
            $("#consignment_id").val(cId);
            $("#consId").html(cId);
            $("#modal-payment").modal('show');
        }
    });
    $("#consignemntpayment").validate({
        rules:{
            transaction_number:{
                required:true,
                maxlength:20,
            },
            transaction_date:{
                required:true,
            }
        }
    });
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>