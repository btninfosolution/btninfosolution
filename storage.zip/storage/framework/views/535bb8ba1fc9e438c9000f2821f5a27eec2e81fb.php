<?php $__env->startSection('page-css'); ?>
<style rel="stylesheet/text">
.msg_err {
  color:red;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small> Of <?php echo e($manager->full_name); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/managers')); ?>"><i class="fa fa-user-secret"></i> Managers</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $manager_id = Crypt::encrypt($manager->user_id);?>
    <div class="box">
        <div class="box-header"></div>
        <form action="<?php echo e(url('Admin/manager-payment-list/'.$manager_id)); ?>" method="POST" autocomplete="off">
            <div class="box-body">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-4" >
                    <label>Date From</label>
                    <input type="text" class="form-control" value="<?php echo e($date_from); ?>" id="date_from" name="date_from" placeholder="Enter From Date">
                    <span class="addressErr error" style="color: red;"></span>
                </div>
                <div class="form-group col-md-4" >
                    <label>Date To</label>
                    <input type="text" class="form-control" value="<?php echo e($date_to); ?>" id="date_to" name="date_to" placeholder="Enter To Date">
                    <span class="addressErr error" style="color: red;"></span>
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="filter" value="1">Filter</button>
                <button type="submit" class="btn btn-info" name="filter" value="2" >Reset</button>
            </div>
        </form>    
    </div>

    <div class="box">
        <div class="box-body">
            <table class="table table-bordered">
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Transaction Number</th>
                    <th>Payment Date</th>
                    <th>Total Consignment</th>
                </tr>
                <?php $no = ($consignments->currentpage()-1)* $consignments->perpage() + 1; ?>
                <?php foreach($consignments as $consign): ?>
                <tr>
                    <td><?php echo e($no); ?></td>
                    <td><?php echo e($consign->transaction_number); ?></td>
                    <td><?php echo e(date("d-m-Y",strtotime($consign->transaction_date))); ?></td>
                    <td><?php echo e($consign->total_consignment); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$consignments->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
    $(function() {
        $( "#date_from" ).datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'yy-mm-dd',
            maxDate:0,
        });
        $( "#date_to" ).datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'yy-mm-dd',
            maxDate:0,
        });
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>