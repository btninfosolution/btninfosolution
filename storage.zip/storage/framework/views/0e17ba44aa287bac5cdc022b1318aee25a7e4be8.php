<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/terms')); ?>"><i class="fa fa-user-secret"></i> Terms & condition</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
           <form action="<?php echo e(url('Admin/addterms')); ?>" method="POST" id="formData1">
		    <?php echo e(csrf_field()); ?>

			<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
              <div class="box-body">
			  
                   
              <?php foreach($faqlanguage as $val): ?>
              
			<div class="form-group" >
                  <label for="exampleInputEmail1">Language</label>
                 <input type="text" id="language"name="language_name[]"  value="<?php echo e($val->language_name); ?>" placeholder="Enter title" class="form-control" readonly />
				 </div>
 
				
       <input type="hidden" id="language"name="language[]"  value="<?php echo e($val->language_id); ?>" placeholder="Enter title" class="form-control" readonly />	
							
							
                  <div class="form-group" >
                  <label for="exampleInputEmail1">Title</label>
                <input type="text" id="title"name="title[]" placeholder="Enter title" class="form-control title_cls" />
				<span class="titleErr error" style="color: red;"></span>
				</div>
           <div class="form-group" >
                  <label for="exampleInputEmail1">Description</label>
                 <textarea id="content" name="content[]" placeholder="Enter Description" class="form-control content_cls"></textarea>
							<span class="contentErr error" style="color: red;"></span>
							</div>
							
							

               
             
			 <?php endforeach; ?>

      

              </div>
	
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  onclick="return formValidationAdd();"class="btn btn-primary">Submit</button>
                <button type="reset"  class="btn btn-primary">Reset</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
          </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script type="text/javascript">

   

    var i = 0;

       

    $("#add").click(function(i){

   

        ++i;

   

        $("#dynamicTable").append('<tr><td><input type="text" name="title[]" placeholder="Enter title" class="form-control" /></td><td><textarea name="content[]" placeholder="Enter Description" class="form-control" ></textarea></td>/<td><button type="button" class="btn btn-danger remove-tr">Remove</button></td></tr>');
    });

   

    $(document).on('click', '.remove-tr', function(){  

         $(this).parents('tr').remove();

    });  

   

</script>
<script>
				function formValidationAdd(){
					
				 var data = new FormData($('#formData1')[0]);
				 //var hid = $("#id").val();
			//	 var title = $("#title").val();
				// var content = $("#content").val();
         $(".titleErr").html("");
				  $(".contentErr").html("");
          var check = true;
         $(".title_cls").each(function(){ 
           //yourArray.push($(this).val()); 
           var title = $(this).val();
           if(title==""){
            check = false;
          	$(".titleErr").html(" English and Arabic Both Title is required.").show();
          	$(".contentErr").html("English and Arabic Both Content is required.").show();
               	//	$("#title").focus();
                  
           }
          
          
           });
           if (check==false) {
    return false;
}
               		
           $(".content_cls").each(function(){ 
           //yourArray.push($(this).val()); 
           var content = $(this).val();
           if(content==""){
            check = false;
          //	$(".titleErr").html(" Title is required.").show();
            $(".contentErr").html("English and Arabic Both Content is required.").show();
               	//	$("#content").focus();		
           }

           });
           if (check==false) {
    return false;
}
                
              	// $(".contentErr").hide("");
             	
            /* 	 if(title==""){
               	//	$(".titleErr").slideDown('slow');
               		$(".titleErr").html(" Title is required.").show();
               		$(".contentErr").html(" Content is required.").show();

               		$("#title").focus();
               		return false;
               	}
				 if(content==""){
               	//	$(".contentErr").slideDown('slow');
               		$(".contentErr").html(" Content is required.");
               		$("#content").focus();
               		return false;
         }*/
        
             	
				
        
				}</script>	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>