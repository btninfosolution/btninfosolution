<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small> Of <?php echo e($customer->full_name); ?></small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/customers/5')); ?>"><i class="fa fa-user"></i> Customers</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $customer_id = Crypt::encrypt($customer->user_id);?>
    <div class="box">
        <div class="box-header"></div>
        <form action="<?php echo e(url('Admin/customer-wallet-history/'.$customer_id)); ?>" method="POST" autocomplete="off">
            <div class="box-body">
                <?php echo e(csrf_field()); ?>

                <div class="form-group col-md-3" >
                    <label>Wallet Type</label>
                    <select name="wallet_type" id="wallet_type" class="form-control">
                        <option value="" selected>Select type</option>
                        <?php if(!empty($wallet_types)): ?>
                        <?php foreach($wallet_types as $ky=>$vl): ?>
                            <?php if($ky==$wallet_type): ?>
                                <option value="<?php echo e($ky); ?>" selected><?php echo e($vl); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($ky); ?>"><?php echo e($vl); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group col-md-4" >
                    <label>Date From</label>
                    <input type="text" class="form-control" value="<?php echo e($date_from); ?>" name="date_from" placeholder="Enter From Date">
                    <span class="addressErr error" style="color: red;"></span>
                </div>
                <div class="form-group col-md-4" >
                    <label>Date To</label>
                    <input type="text" class="form-control" value="<?php echo e($date_to); ?>" name="date_to" placeholder="Enter To Date">
                    <span class="addressErr error" style="color: red;"></span>
                </div>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="filter" value="1">Filter</button>
                <button type="submit" class="btn btn-info" name="filter" value="2" >Reset</button>
            </div>
        </form>    
    </div>

    <div class="box">
        <div class="box-body">
            <table class="table table-bordered">
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Details</th>
                </tr>
                <?php $no = ($wallets->currentpage()-1)* $wallets->perpage() + 1; ?>
                <?php foreach($wallets as $wallet): ?>
                <tr>
                    <td><?php echo e($no); ?></td>
                    <td><?php echo e($wallet->transaction_amount); ?></td>
                    <td><?php echo e(date("d-m-Y",strtotime($wallet->transaction_date))); ?></td>
                    <td><?php echo e(@$wallet_types[$wallet->transaction_type]); ?></td>
                    <td><?php if($wallet->consignment_id>0): ?>
                        <?php echo e('Consignment id :: '.$wallet->consignment_id); ?>

                        <?php else: ?>
                        <?php echo e('Knet Referece id :: '.$wallet->reference_id); ?>

                    <?php endif; ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$wallets->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
    $(function() {
        $( "#date_from" ).datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'yy-mm-dd',
            maxDate:0,
        });
        $( "#date_to" ).datepicker({
            changeMonth: true,
            changeYear: true,
            dateFormat: 'yy-mm-dd',
            maxDate:0,
        });
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>