<!doctype html>
<html class="no-js" lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Chnage Password</h4>
                     </div>
                  </div>
                   <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               </div>
            </div>
            <!-- page title area end -->
			 <?php echo $__env->make('admin/admin_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
            <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Change password</a>
                           
                        </div>
                     </nav>
                     <form action="<?php echo e(url('update-adminpassword')); ?>" class="form-material" id="formData" name="create_customer" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
						<input type="hidden"   id="id" value="<?php echo e($Editdata->staff_id); ?>" name="id" >
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">New password</label>
                                    <input type="password" class="form-control" id="newpassword" placeholder="New password" name="newpassword">
                                    
                                 </div>
								
                              </div>
							  <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Confirm  password</label>
                                    <input type="password" class="form-control" id="conpassword" placeholder="Confirm Password" name="conpassword">
                                    
                                 </div>
								
                              </div>
                           </div>
                           
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
         $("#formData").validate({
           rules: {
         newpassword: {
                required:true,
                maxlength:16,
                minlength: 6
             },
             conpassword: {
                required:true,
             },
             conpassword: {
                equalTo:newpassword,
             },
            
            
          
           },
         messages: {
           newpassword:{
               required:"<?php echo e(trans('messages.316')); ?>",
               minlength:"<?php echo e(trans('messages.317')); ?>",
               maxlength:"<?php echo e(trans('messages.318')); ?>",
             } ,
             conpassword:{
               required:"<?php echo e(trans('messages.319')); ?>",
             } ,
             conpassword:{
               equalTo:"<?php echo e(trans('messages.320')); ?>",
             } ,
            
            
           
           }
         });
      </script>
   </body>
</html>