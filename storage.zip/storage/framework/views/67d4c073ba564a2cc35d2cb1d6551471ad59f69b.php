<?php $__env->startSection('content'); ?>
<div class="login-box-body">
    
    <form action="<?php echo e(url('Admin/update-password')); ?>" method="post" id="forget_pwd" >
        <?php echo e(csrf_field()); ?>

        <?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
      <div class="form-group has-feedback">
        <input type="number" class="form-control" name="phone_no" id="phone_no" placeholder="Phone Number">
        <span class="glyphicon glyphicon-phone form-control-feedback"></span>
      </div>

      <div class="row">
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit"  onclick="return formValidationAdd();" class="btn btn-primary btn-block btn-flat">Submit</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cus-js'); ?>
<script>
$("#forget_pwd").validate({
  rules: {
    phone_no: {
      required:true,
      digits: true
    }
  },
 messages: {
    phone_no:{
      required:"Please specify Phone no",
      digits: "Enter digits only"
    } 
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_one', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>