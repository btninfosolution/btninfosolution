<?php $__env->startSection('page-css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

        <div class="box">
            <div class="box-header">
                
            </div>
            <form action="<?php echo e(url('Admin/consignments')); ?>" method="POST" id="formData1">
                <div class="box-body">
                    <?php echo e(csrf_field()); ?>

                   <div class="form-group col-md-4" >
                        <label>Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">Select status</option>
                                <option value="1" <?php if(isset($status)): ?> <?php echo e($status  == '1' ? 'selected' : ''); ?> <?php endif; ?>>Driver asign</option>
                                <option value="0" <?php if(isset($status)): ?> <?php echo e($status  == '0' ? 'selected' : ''); ?> <?php endif; ?>>Driver not asign</option>
                            </select>     
                            <span class="paytypeErr error" style="color: red;"></span>                
                    </div>
                    <div class="form-group col-md-4" >
                        <label >Pick Up Address</label>
                        <input type="text" class="form-control"  value="<?php if(isset($address)): ?><?php echo e($address); ?><?php endif; ?>"id="address" name="address" placeholder="Enter Address">
                        <span class="addressErr error" style="color: red;"></span>
                    </div>
                    <div class="form-group col-md-4" >
                        <label >Date</label>
                        <input type="text" class="form-control"   value="<?php if(isset($date)): ?><?php echo e($date); ?><?php endif; ?>" id="date" name="date" placeholder="Enter Date">
                        <span class="addressErr error" style="color: red;"></span>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="submit"   class="btn btn-primary">Filter</button>
                    <button type="button" id="reset_btn"  class="btn btn-primary">Reset</button>
                </div>
            </form>    
        </div>

        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>User</th>
                        <th>Manager</th>
                        <th>Driver</th>
                        <th>Pick Up Address</th>
                        <th>Pickup Date</th>
                       
                        <th>Cost</th>
                        <th>Coupon Amount</th>
                        <th>Payable Cost</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    <?php $no = ($consignments->currentpage()-1)* $consignments->perpage() + 1; ?>
                    <?php foreach($consignments as $consign): ?>
                    <tr>
                        <th style="width: 10px"><?php echo e($no); ?></th>
                        <th><?php echo e(ucfirst($consign->cust_name)); ?></th>
                        <th><?php echo e(ucfirst($consign->mng_name)); ?></th>
                        <th><?php echo e(ucfirst($consign->drv_name)); ?></th>
                        <th><?php echo e($consign->pickup_address); ?></th>
                        <th><?php echo e(date("d-m-Y H:i:s",strtotime($consign->pickup_date_time))); ?></th>                        
                        <th><?php echo e($consign->consignment_cost); ?></th>
                        <th><?php echo e($consign->coupon_amount); ?></th>
                        <th><?php echo e($consign->payable_cost); ?></th>
                        <?php //$status = ($consign->consignment_status == 1 ) ? 'Asigned' : 'Not asigned'
                            if($consign->consignment_status == 0){
                                $status ="Driver not asigned";
                            }
                            else if($consign->consignment_status == 1 ){
                                $status ="Driver Asigned";
                            }
                            else if($consign->consignment_status == 2){
                                $status ="Driver arriving";
                            }
                            else if($consign->consignment_status == 3){
                                $status ="Driver arrived";
                            } 
                            else if($consign->consignment_status == 4){
                                $status ="Driver picked up";
                            }
                            else if($consign->consignment_status == 5){
                                $status ="Delivered";
                            }
                            else if($consign->consignment_status == 6){
                                $status ="Not Delivered";
                            }
                            else{
                                $status ="Driver assigning failed";
                            }
                            
                        ?>
                        <th><?php echo e($status); ?></th>
                        <?php $consignment_id = Crypt::encrypt($consign->consignment_id);?>
                        <th>
                        <a href="<?php echo e(url('Admin/consignment-detail').'/'.$consignment_id); ?>" data-toggle="tooltip" title="View">
                            <span class="glyphicon glyphicon-list-alt"></span>
                        </a>
                        <a href="<?php echo e(url('Admin/map-view').'/'.$consign->consignment_id); ?>" data-toggle="tooltip" title="Map View">
                            <span class="glyphicon glyphicon-map-marker"></span>
                        </a>
                        </th>
                        
                    </tr>  
                    <?php $no++; ?>
                    <?php endforeach; ?>
                </table>
            </div>
            <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$consignments->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-js'); ?>
<script>
$(function() {
    $( "#date" ).datepicker({
	   changeMonth: true,
	   changeYear: true,
	   dateFormat: 'yy-mm-dd'
	});
});

$("#reset_btn").click(function(){
    //$("#user_filter")[0].reset();
    $("#address").val("");
    $("#date").val("");
    $("#status").val("");
    window.location.href = "<?php echo e(url('Admin/consignments')); ?>";
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>