<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>

<section class="content-header">
    <h1>
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/payment-master')); ?>"><i class="fa fa-user-secret"></i> Payment List</a></li>
        <li class="active"></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

 
    <div class="row">
        <div class="box">
        <?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<h4><?php echo e($errors->first()); ?></h4>
<?php endif; ?>
            <div class="box-body">

                <table class="table table-bordered">
				
                    <tr>
                        <th >Sl No</th>
                        <th>Consignment Id</th>
                        <th>Customer Name </th>
                        <th>Consignment Cost </th>
                        <th>No Of Delivery </th>
                        <th>Pick Up Address </th>
                        
                    </tr>
					<tbody id="tabledata">
                    <?php $i = 1; ?>
                    <?php foreach($Editdata as $detail): ?> 

                    <tr>
					<td class="center"><?php echo e($i); ?> </td>
                        <td class="center" name="title" id="title"><?php echo e($detail->consignment_id); ?> </td>
						<td class="center" name="content" id="content"><?php echo e($detail->full_name); ?> </td>
                        <td class="center" name="content" id="content"><?php echo e($detail->consignment_cost); ?> </td>
                        <td class="center" name="content" id="content"><?php echo e($detail->number_of_delivery); ?> </td>
                        <td class="center" name="content" id="content"><?php echo e($detail->pickup_address); ?> </td>
                        
					
                  
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>