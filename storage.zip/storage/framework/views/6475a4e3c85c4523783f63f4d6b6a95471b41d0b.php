<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>

<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
				
                    <tr>
                        <th >Sl No</th>
                        <th >Governerartes</th>
                        <th>Area Name</th>
                        <th>Area Radius</th>
                        <th>Latitude</th>
                        <th>Longitude</th>
                        <th>Status</th>
					    <th>Action</th>
                        
                    </tr>
					<tbody id="tabledata">
                    
                    <?php $i = ($arealist->currentpage()-1)* $arealist->perpage() + 1; ?>
                    <?php foreach($arealist as $area): ?> 
					 <?php   $id= Crypt::encrypt($area->service_area_id);?>	

                    <tr>
					<td class="center"><?php echo e($i); ?> </td>
                    <td class="center"><?php echo e($area->governerartes_name); ?> </td>
         <td class="center"><?php echo e($area->area_name); ?> </td>
					<td class="center"><?php echo e($area->area_radius); ?> </td>
          <td class="center" ><?php echo e($area->area_lat); ?> </td>
          <td class="center" ><?php echo e($area->area_lon); ?> </td>
          <?php if($area->is_blocked==1): ?> 
          <td class="center" ><?php echo e('Blocked '); ?> </td>
          <?php else: ?> 
          <td class="center" ><?php echo e('UnBlocked'); ?> </td>
          <?php endif; ?>
					<td class="center"> <a href="<?php echo e(url('Admin/deletearea').'/'.$area->service_area_id); ?>"  data-toggle="tooltip"  onclick="return confirm('Are you sure you want to delete this Area ?');"title="Delete" >
                    <span class="glyphicon glyphicon-trash"></span> 
                    </a>
				<a href="<?php echo e(url('Admin/editarea').'/'.$id); ?>" data-toggle="tooltip" title="Edit">
                <span class="glyphicon glyphicon-pencil"></span>
                </a>
				
						 <?php if($area->is_blocked==1): ?>  
                            <a  href="<?php echo e(url('Admin/inactive_active_area').'/'.$area->service_area_id); ?>"data-toggle="tooltip" title="Blocked" id="status"onclick="return confirm('Are you sure you want to Unblock this area ?');"  >
                            <span class="glyphicon glyphicon-ban-circle"></span>  
                            </a>
                            <?php else: ?> 
                            <a href="<?php echo e(url('Admin/inactive_active_area').'/'.$area->service_area_id); ?>" data-toggle="tooltip" title="Unblocked" id="status" onclick="return confirm('Are you sure you want to Block this area ?');" >
                            <span class="glyphicon glyphicon-check"></span>     
                            </a>
                            <?php endif; ?>    
						</td>
                  
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
            <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$arealist), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script>
	function inactive(id){
		var res = confirm("Are you sure you want to change this Area status");
		    if(res == true) {
		    	url = "<?php echo e(url('Admin/inactive_active_area')); ?>";
				//alert(url);
		        $.ajax({
		          type:"POST",
		          url: url,
				  data: { "_token": "<?php echo e(csrf_token()); ?>", "id": id },
		          //data: {"id":id}, 
		          success: function(data) { 
			          //alert(data);
			          if(data == 1)
			          { 
				          alert("Status has been changed successfully");
		         			 location.reload();
			          }
		    	}
		 	});
		 }  
		  
	}
	</script>
	<script type="text/javascript">
function deletearea(id) {
	//alert(id);
	var res = confirm("Are you sure you want to delete this Area ?");
     if(res == true) {
		    	url = "<?php echo e(url('Admin/deletearea')); ?>";
				//alert(url);
		        $.ajax({
		          type:"POST",
		          url: url,
				  data: { "_token": "<?php echo e(csrf_token()); ?>", "id": id },
		          //data: {"id":id}, 
		          success: function(data) { 
			          //alert(data);
			          if(data == 1)
			          { 
				          alert("Data has been deleted successfully");
		         			 location.reload();
			          }
		    	}
		 	});
		 }  
}
</script>
<script>
function language122(val){
            var url="<?php echo e(url('Admin/changefaqlanguage')); ?>";
            //var redirectUrl
               $.ajax({
                type: "POST",
                url: url, 
                data: { "_token": "<?php echo e(csrf_token()); ?>", "id": val },
                
                cache: false,
                success: function(data)
                { alert(data);
                 
                    $("#title").html(data).show();
					$("#content").html(data).show();
					  $("#tabledata").html(data).show();
					  
                }
           });
          }
 </script>
 <script>
function language(val){
	//alert(val);
           window.location.href = "<?php echo e(url('Admin/changefaqlanguage')); ?>" + '/' + val;
          }
 </script>
  




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>