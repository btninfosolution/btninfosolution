<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>

<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--<div class="box">
            <div class="box-header">
                
            </div>
            <form action="<?php echo e(url('Admin/building')); ?>" method="POST" id="formData1">
                <div class="box-body">
                    <?php echo e(csrf_field()); ?>

                   <div class="form-group col-md-8" >
                        <label><?php echo e('Language'); ?></label>
						<select name="language" id="language" class="form-control select2"style="width: 50%;">
                                <option value="">Select Language</option>
                                <?php foreach($termslanguage as $val): ?>
                               <!--  <option value="<?php echo e($val->language_id); ?>"><?php echo e($val->language_name); ?></option
                                 <option value="<?php echo e($val->language_id); ?>" <?php echo e($val->language_id == $languagedata->language_id ? 'selected' : ''); ?>><?php echo e($val->language_name); ?></option>                       
                                 
                                <?php endforeach; ?>
                            </select>     
                            <span class="paytypeErr error" style="color: red;"></span>                
                    </div>
                   
                </div>
                <div class="box-footer">
                    <button type="submit"   class="btn btn-primary">Filter</button>
					</div>
                
            </form>    
        </div>-->
 
    <!--<div class="row">-->
        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
				
                    <tr>
                        <th >Sl No</th>
                        <th>Promocode</th>
                        <th>Amount Type</th>
                        <th>Amount</th>
                        <th>Start Date</th>
                        <th>Expiry Date</th>
                        <th>Frequency  Use</th>
                        <th>Status</th>
						 <th>Action</th>
                        
                    </tr>
					<tbody id="tabledata">
                    <?php $i = 1; ?>
                    <?php foreach($promolist as $promo): ?> 
					 <?php   $id= Crypt::encrypt($promo->promocode_id );?>	

                    <tr>
					<td class="center"><?php echo e($i); ?> </td>
                        <td class="center" name="title" id="title"><?php echo e($promo->name); ?> </td>
                        <?php if($promo->amount_type==1): ?> 
                        <td class="center" name="title" id="title"><?php echo e('Flat amount'); ?> </td>
                        <?php else: ?> 
                        <td class="center" name="title" id="title"><?php echo e('Percentage'); ?> </td>
                        <?php endif; ?> 
                        <td class="center" name="title" id="title"><?php echo e($promo->amount); ?> </td>
                        <td class="center" name="title" id="title"><?php echo e($promo->start_date); ?> </td>
                        <td class="center" name="title" id="title"><?php echo e($promo->expiry_date); ?> </td>
                        <td class="center" name="title" id="title"><?php echo e($promo->frequency_use); ?> </td>
                        <?php if($promo->is_active==1): ?> 
                        <td class="center" name="title" id="title"><?php echo e('Blocked'); ?> </td>
                        <?php else: ?> 
                        <td class="center" name="title" id="title"><?php echo e('Unblocked'); ?> </td>
                        <?php endif; ?>  
                        
						<td class="center" id="action"> <a href="<?php echo e(url('Admin/deletepromocode').'/'.$promo->promocode_id); ?>" data-toggle="tooltip" title="Delete"onclick="return confirm('Are you sure you want to delete this promocode  ?');">
                        <span class="glyphicon glyphicon-trash"></span>  
                        </a>
						 <a href="<?php echo e(url('Admin/edit-promocode').'/'.$id); ?>" data-toggle="tooltip" title="Edit">
                         <span class="glyphicon glyphicon-pencil"></span>
                         </a>
				
						 <?php if($promo->is_active==1): ?>  
                            <a href="<?php echo e(url('Admin/inactive_active_promocode').'/'.$promo->promocode_id); ?>" id="status"data-toggle="tooltip" title="Blocked" onclick="return confirm('Are you sure you want to Unblock this promocode ?');" >
                            <span class="glyphicon glyphicon-ban-circle"></span>  
                            </a>
                            <?php else: ?> 
                            <a href="<?php echo e(url('Admin/inactive_active_promocode').'/'.$promo->promocode_id); ?>" id="status"data-toggle="tooltip" title="Unblocked"onclick="return confirm('Are you sure you want to Block this promocode ?');" >
                            <span class="glyphicon glyphicon-check"></span>    
                            </a>
                            <?php endif; ?>    
						</td>
                  
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
            <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$promolist), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script>
	function inactive(id){
		var res = confirm("Are you sure you want to change this Vehicle status");
		    if(res == true) {
		    	url = "<?php echo e(url('Admin/inactive_active_vehicle')); ?>";
				//alert(url);
		        $.ajax({
		          type:"POST",
		          url: url,
				  data: { "_token": "<?php echo e(csrf_token()); ?>", "id": id },
		          //data: {"id":id}, 
		          success: function(data) { 
			          //alert(data);
			          if(data == 1)
			          { 
				          alert("Status has been changed successfully");
		         			 location.reload();
			          }
		    	}
		 	});
		 }  
		  
	}
	</script>
	<script type="text/javascript">
function deletefaq(id) {
	//alert(id);
	var res = confirm("Are you sure you want to delete this Vehicle ?");
     if(res == true) {
		    	url = "<?php echo e(url('Admin/deletevehicle')); ?>";
				//alert(url);
		        $.ajax({
		          type:"POST",
		          url: url,
				  data: { "_token": "<?php echo e(csrf_token()); ?>", "id": id },
		          //data: {"id":id}, 
		          success: function(data) { 
			         // alert(data);
			          if(data == 1)
			          { 
				          alert("Data has been deleted successfully");
		         			 location.reload();
			          }
		    	}
		 	});
		 }  
}
</script>
<script>
function language122(val){
            var url="<?php echo e(url('Admin/changefaqlanguage')); ?>" + '/' + val;
            //alert(url);
            //var redirectUrl
               $.ajax({
                type: "GET",
                url: url, 
                data: { "_token": "<?php echo e(csrf_token()); ?>", "id": val },
                cache: false,
                success: function(data)
                { alert(data);
                    location.reload();
                    //$("#title").html(data).show();
					//$("#content").html(data).show();
                    //$("#action").html(data).show();
                    
					  //$("#tabledata").html(data).show();
					  
                }
           });
          }
 </script>
 <script>
function language(val){
	//alert(val);
           window.location.href = "<?php echo e(url('Admin/changefaqlanguage')); ?>" + '/' + val;
          }
 </script>
  




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>