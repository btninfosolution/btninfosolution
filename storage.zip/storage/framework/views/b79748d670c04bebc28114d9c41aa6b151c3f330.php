<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>CRM Admin</title>
  <!-- loader-->
  <link href="<?php echo e(asset('public/assets/css/pace.min.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('public/assets/plugins/fullcalendar/css/fullcalendar.min.css')); ?>" rel='stylesheet'/>
  <script src="<?php echo e(asset('public/assets/js/pace.min.js')); ?>"></script>
  <!--favicon-->
  <link rel="icon" href="<?php echo e(asset('public/assets/images/favicon.ico')); ?>" type="image/x-icon">
  <!-- Vector CSS -->
  <link href="<?php echo e(asset('public/assets/plugins/vectormap/jquery-jvectormap-2.0.2.css')); ?>" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="<?php echo e(asset('public/assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="<?php echo e(asset('public/assets/css/animate.css')); ?>" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="<?php echo e(asset('public/assets/css/icons.css')); ?>" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="<?php echo e(asset('public/assets/css/sidebar-menu.css')); ?>" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="<?php echo e(asset('public/assets/css/app-style.css')); ?>" rel="stylesheet"/>
  <style>
  label.error {
  color:red;
  }
  .btn { background-color: rgba(255,255,255,.125);
            margin-bottom: 25px;
            color: #fff;
            }
    .pagination {
  display: inline-block;
  margin-left: 610px;
  margin-top: -20px;
}

.pagination a {
  color: white;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
}

.pagination a.active {
  background-color: rgba(255,255,255,.125);
  color: white;
}

.pagination a:hover:not(.active) {background-color: #ddd;
color: black;}
  </style>
  <script>

function test(pageNumber)
{

  var page="#page-id-"+pageNumber;
  $('.select').hide()
  $(page).show()

}

</script>
  
</head>