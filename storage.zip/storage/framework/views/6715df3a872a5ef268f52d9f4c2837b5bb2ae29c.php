<!DOCTYPE html>
<html lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <body class="bg-theme bg-theme1">
      <!-- start loader -->
      <div id="pageloader-overlay" class="visible incoming">
         <div class="loader-wrapper-outer">
            <div class="loader-wrapper-inner" >
               <div class="loader"></div>
            </div>
         </div>
      </div>
      <!-- end loader -->
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
      <div class="container-fluid">
      <div class="row mt-3">
      <h4 class="page-title pull-left">Staff Summary</h4>
      <div class="col-md-12">
         <div class="row" style="padding-top:20px;">
            <!--<button type="button" class="btn btn-primary mb-3">New Customer</button>-->
            <?php if(!empty($addpermission)): ?>
                   
                   <?php else: ?>
                     <a class="btn btn-primary mb-3" href="<?php echo e(url('add-staff')); ?>"></i> New Staff</a>
                     <?php endif; ?>
         </div>
         <?php echo $__env->make('admin/admin_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      </div>
      
      <div class="card">
      <div class="card-body">
         <h5 class="card-title">Staff</h5>
         <div class="table-responsive">
            <table class="table footable" data-page-size="6" data-first-text="FIRST" data-next-text="NEXT" data-previous-text="PREVIOUS" data-last-text="LAST">
                  


                <thead class="bg-light text-capitalize">
                                    <tr>
                                    <th>Image</th>
                                       <th>Staff Name</th>
                                       <th>Phone</th>
                                       <th>Email</th>
                                      
                                       <th>Date Created</th>
                                       <th>Status</th>
                                       <th>Action</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                 <?php $i = 1; ?>
                                    <?php if(!empty($stafflist)): ?>
                                    <?php foreach($stafflist as $staff): ?> 
                                    <?php   $id= Crypt::encrypt($staff->staff_id );?> 
                                    <tr>
                                    <td>
                                                <?php if($staff->profile_image !=''): ?>
                                                <a href="#" >  <span class="thumb-small avatar inline"><img src="<?php echo e(asset('public/uploads/contact_image/'.$staff->profile_image)); ?>" style="height: 40px; width: 30px;" class="img-circle"></span> </a>
                                                <?php else: ?>
                                                <a href="#" >  <span class="thumb-small avatar inline"><img src="<?php echo e(asset('public/uploads/'.'noimg.png')); ?>" style="height: 40px; width: 30px;" class="img-circle"></span> </a>
                                                <?php endif; ?>
                                                </td>
                                      
                                       <td><?php echo e($staff->first_name); ?> <?php echo e($staff->last_name); ?></td>
                                       <td><?php echo e($staff->phone); ?></td>
                                       <td><?php echo e($staff->email); ?></td>
                                       
									            <td><?php echo e($staff->created_at); ?></td>
                                       <td>
                                       <?php if($staff->is_blocked==0): ?>  
                                       <a data-id="<?php echo e($staff->is_blocked); ?>" class="" href="<?php echo e(url('change-status')); ?>?status_data=<?php echo e(Crypt::encrypt('id='.$staff->staff_id.'&tbl=tbl_staff&field=staff_id&is_blocked='.$staff->is_blocked.'&request_url=staff')); ?>" title="" data-original-title="Active"onclick="return confirm('Are you sure you want to change this status  ?');"><i class="fa fa-check fa-lg text-success"></i></a>
                                       <?php else: ?>
                                         <a data-id="<?php echo e($staff->is_blocked); ?>" class="" href="<?php echo e(url('change-status')); ?>?status_data=<?php echo e(Crypt::encrypt('id='.$staff->staff_id.'&tbl=tbl_staff&field=staff_id&is_blocked='.$staff->is_blocked.'&request_url=staff')); ?>"  title="" data-original-title="Inactive"onclick="return confirm('Are you sure you want to change this status  ?');"><i class="fa fa-ban fa-lg text-danger"></i></a>
                                       <?php endif; ?>
                                       </td>
                           
                                       <td> 
                                       <?php if(!empty($editpermission)): ?>
                                       <?php else: ?>
                                       <a href="<?php echo e(url('staff-edit').'/'.$id); ?>" title="Edit" data-toggle="tooltip"><span class="badge badge-pill badge-primary">Edit</span></a>
                                       <?php endif; ?>
                                       <?php if(session('user_type') ==1): ?>
									  <!--  <a data-id="<?php echo e($staff->is_deleted); ?>"href="<?php echo e(url('delete-record')); ?>?status_data=<?php echo e(Crypt::encrypt($staff->staff_id.'&tbl_staff&staff_id&'.$staff->is_deleted.'&staff'.'&0')); ?>" title="Delete" onclick="return confirm('Are you sure you want to delete this staff ?');" data-toggle="tooltip"><span class="badge badge-pill badge-danger">Delete</span></a>-->
                            
                                        <a href="<?php echo e(url('staff-detail').'/'.$id); ?>" title="View" data-toggle="tooltip"><span class="badge badge-pill badge-primary">View</span></a>	
                                        <?php endif; ?>									
									   </td>
                                    </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; ?>
                                    <?php endif; ?> 
                                 </tbody>
                              </table>
                              <div class="pagination">
            <!--start overlay-->
            <div class="overlay toggle-menu"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
        <div class="overlay"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
   </body>
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>

