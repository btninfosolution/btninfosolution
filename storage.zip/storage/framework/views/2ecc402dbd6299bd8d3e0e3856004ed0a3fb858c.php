<!doctype html>
<html class="no-js" lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Expense</h4>
                     </div>
                  </div>
                  <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Add New Expense</a>
                           <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Advance Option</a>
                        </div>
                     </nav>
                     <form action="<?php echo e(url('save-expense')); ?>" class="form-material" id="formData" name="create_expense" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Name</label>
                                    <input type="text" class="form-control" id="name" placeholder="Name" name="name">
                                  </div>
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Note<span class="text-danger">*</span></label>
                                    <textarea type="text" class="form-control" id="note" placeholder="Note" name="note"></textarea>
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Expense Category</label>
                                    <select id="expense_catogory_id" name="expense_catogory_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($expense_catogorylist as $group): ?> 
                                       <option value="<?php echo e($group->expense_catogory_id); ?>"><?php echo e($group->expense_catogory_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Expense Date <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="expence_date" placeholder="Expense Date" name="expence_date">
                                   
                                 </div>
                                
              
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Amount</label>
                                    <input type="text" class="form-control" id="amount" name="amount" placeholder="Amount">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Customer</label>
                                    <select id="customer_id" name="customer_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($customerlist as $group): ?> 
                                       <option value="<?php echo e($group->id); ?>"><?php echo e($group->client_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                              <div class="form-row">
                                 
                                 
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Currency</label>
                                    <input type="text" class="form-control" id="currency" name="currency" placeholder="Currency" value="INR" readonly="">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Tax 1</label>
                                    <input type="text" class="form-control" id="tax1" name="tax1" placeholder="Tax 1" >
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Tax 2</label>
                                    <input type="text" class="form-control" id="tax2" name="tax2" placeholder="Tax 2" >
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Payment Mode</label>
                                    <select id="payment_mode" name="payment_mode"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <option value="Bank">Bank</option>
                                       <option value="Google Pay">Google Pay</option>
                                    </select>
                                    <!-- <input type="text" class="form-control" id="payment_mode" name="payment_mode" placeholder="Payment Mode" > -->
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Reference</label>
                                    <input type="text" class="form-control" id="reference" name="reference" placeholder="Reference" >
                                    
                                 </div>
                                
                              </div>
                           </div>
                        </div>
                        <button type="submit" class="btn btn-primary next" id="expense_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
  $("#formData").validate({
    rules: {
        name: {
          required:true,
      },
      amount: {
          required:true,
          digits:true,
           
      },
     
     
    
    },
  messages: {
      name:{
        required:"<?php echo e(trans('messages.355')); ?>",
      } ,
      amount:{
        required:"<?php echo e(trans('messages.356')); ?>",
        digits:"<?php echo e(trans('messages.357')); ?>",
      } ,
     
      
   
    
    }
  });
</script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/css/bootstrap-datepicker.min.css" />
	  
	  <script>
  $(document).ready(function() {
  var date = new Date();
  var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  //var end = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  $('#expence_date').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });
 

  $('#expence_date').datepicker('setDate', today);
});
</script>
   </body>
</html>