<?php $__env->startSection('content'); ?>
<?php if(!empty($consignments)): ?>
<table>
    <thead>
        <tr>
            <th>Id</th>
            <th>Date</th>
            <th>Cost</th>
            <th>Status</th>
            <th>Customer Name</th>
            <th>Driver Name</th>
            <th>Manager Earn</th>
        </tr>
    </thead>
    <tbody>
    <?php  
    $i=0;
     ?>
    <?php foreach($consignments as $consign): ?>
    <tr>
        <td><?php echo e($consign->consignment_id); ?></td>
        <td><?php echo e(date("M d, Y",strtotime($consign->pickup_date_time))); ?></td>
        <td><?php echo e(round($consign->payable_cost,2)); ?></td>
        <td><?php echo e(@$status_values[$consign->consignment_status]); ?></td>
        <td><?php echo e($consign->cust_name); ?></td>
        <td><?php echo e($consign->drv_name); ?></td>
        <td><?php if($consign->manager_id>0): ?>
            <?php echo e(round($consign->manager_payment_cost,2).' ('.@$manager_paid_status[$consign->is_manager_paid].')'); ?>

            <?php endif; ?>
        </td>
    </tr>
    <?php if(++$i%45 == 0): ?>
    </tbody>
    </table>
    <div class="page-break"></div>
    <table>
        <tr>
            <th>Id</th>
            <th>Date</th>
            <th>Cost</th>
            <th>Status</th>
            <th>Customer Name</th>
            <th>Driver Name</th>
            <th>Manager Earn</th>
        </tr>
    <tbody>
    <?php endif; ?>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_pdf', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>