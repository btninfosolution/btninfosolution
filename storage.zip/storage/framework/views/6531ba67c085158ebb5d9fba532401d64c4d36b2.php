<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1>Edit Promocode
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/promocode')); ?>"><i class="fa fa-user-secret"></i> Promocode</a></li>
        <li class="active">Edit Promocode </li>
    </ol>
</section>

 

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
           <form action="<?php echo e(url('Admin/update-promocode')); ?>" method="POST" id="formData1">
		    <?php echo e(csrf_field()); ?>

			<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<h4><?php echo e($errors->first()); ?></h4>
<?php endif; ?>
              <div class="box-body">
              <div class="form-group"  id="pickup_address_div">
                  <label for="exampleInputEmail1">Name<span class="text-danger">*</span></label>
                  <input type="text" class="form-control"  id="name" value="<?php echo e($Editdata->name); ?>" name="name" placeholder=" Name">
				  <span class="nameErr error" style="color: red;"></span>
                </div>
                <input type="hidden"   id="id" value="<?php echo e($Editdata->promocode_id); ?>" name="id" >
              <div class="form-group">
                        <label class="exampleInputEmail1"><?php echo e('Amount Type'); ?><span class="text-danger">*</span>&nbsp; :</label>
                       <!-- <div class="form-control" >  -->                   
                            <select  id="type" name="type" class="form-control select2"style="width: 100%;" >
                                <option value="">Select Amount Type</option>
                                <option value="1"  <?php echo e(1 == $Editdata->amount_type ? 'selected' : ''); ?>><?php echo e('Flat amount'); ?></option>
                                 <option value="2" <?php echo e(2 == $Editdata->amount_type ? 'selected' : ''); ?>><?php echo e('Percentage'); ?></option>
                               
                            </select>    
                       <span class="typeErr error" style="color: red;"></span>							
                        <!--</div>-->
                    </div>
              <div class="form-group"  id="pickup_address_div">
                  <label for="exampleInputEmail1">Amount<span class="text-danger">*</span></label>
                  <input type="text" class="form-control"  id="amount" value="<?php echo e($Editdata->amount); ?>" name="amount" placeholder="Amount">
				  <span class="amountErr error" style="color: red;"></span>
                </div>
               
                <div class="form-group" >
                  <label >Start From<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" id="start"value="<?php echo e($Editdata->start_date); ?>" name="start" placeholder="Enter start Date">
				  <span class="startErr error" style="color: red;"></span>
                </div>
                <div class="form-group" >
                  <label >Expiry Date<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" id="expiry"value="<?php echo e($Editdata->expiry_date); ?>" name="expiry" placeholder="Enter start Date">
				  <span class="expiryErr error" style="color: red;"></span>
                </div>
				  <div class="form-group"  id="pickup_address_div">
                  <label > Frequency usage<span class="text-danger">*</span></label>
                  <input type="text" class="form-control"  id="frequency" name="frequency"value="<?php echo e($Editdata->frequency_use); ?>" placeholder="frequency use">
				  <span class="frequencyErr error" style="color: red;"></span>
                </div>
				
                
				
			
               
               
               
                
              </div>
	
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  onclick="return formValidationAdd();"class="btn btn-primary">Submit</button>
                <a href="<?php echo e(url('Admin/promocode')); ?>" class="btn btn-danger"> Cancel</a>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
          </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('google_api_key')); ?>&libraries=places"></script>
<script type="text/javascript">
	$(document).ready(function(){
		using_autocomplete();
	});
	

	function formValidationAdd(){			
		var data = new FormData($('#formData1')[0]);
		var name = $("#name").val();
		var type = $("#type").val();
    var amount = $("#amount").val();
		var start = $("#start").val();

        var expiry = $("#expiry").val();
		  var frequency = $("#frequency").val();
    if(name==""){
			$(".nameErr").html("Enter name.").show();
			//$(".radiusErr").html("Enter Availble Area Radius.").show();
			$("#name").focus();
			return false;
		}
	

		if(amount==""){
			//$(".addressErr").slideDown('slow');
			$(".amountErr").html("Enter Amount.").show();
			$("#amount").focus();
			return false;
		}
    
    if(isNaN(amount)){
			//$(".radiusErr").slideDown('slow');
			$(".amountErr").html("Plesae enter valid amount.").show();
			$("#amount").focus();
			return false;
		}
        if(start==""){
			//$(".addressErr").slideDown('slow');
			$(".startErr").html("Enter Start Date.").show();
			$("#start").focus();
			return false;
		}
        if(expiry==""){
			//$(".addressErr").slideDown('slow');
			$(".expiryErr").html("Enter Expiry Date.").show();
			$("#expiry").focus();
			return false;
		}
        if(start > expiry){
			//$(".addressErr").slideDown('slow');
			$(".expiryErr").html("Select any date after start date.").show();
			$("#expiry").focus();
			return false;
		}
    if(frequency==""){
			//$(".addressErr").slideDown('slow');
			$(".frequencyErr").html("Enter useage frequency.").show();
			$("#frequency").focus();
			return false;
		}
    if(isNaN(frequency)){
			//$(".radiusErr").slideDown('slow');
			$(".frequencyErr").html("Plesae enter valid no.").show();
			$("#frequency").focus();
			return false;
		}
  
		
		
	
		
	}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/css/bootstrap-datepicker.min.css" />
      
  <script>
  $(document).ready(function() {
  var date = new Date();
  var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  //var end = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  $('#start').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });
  $('#expiry').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });

  //$('#start,#expiry').datepicker('setDate', today);
});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>