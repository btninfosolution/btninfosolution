<!doctype html>
<html class="no-js" lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Task</h4>
                     </div>
                  </div>
                  <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Task Details</a>
                         
                        </div>
                     </nav>
                     <form action="<?php echo e(url('save-task')); ?>" class="form-material" id="formData" name="create_task" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                
                          <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Subject <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="subject" placeholder="Subject" name="subject" value="<?php echo e(old('subject')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Hourly Rate </label>
                                    <input type="text" class="form-control" id="hourly_rate" placeholder="Hourly Rate" name="hourly_rate" value="<?php echo e(old('hourly_rate')); ?>">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Start Date <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="start_date" placeholder="Start Date"  name="start_date" value="<?php echo e(old('start_date')); ?>">
                                    
                                 </div>

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Due Date </label>
                                    <input type="date" class="form-control" id="due_date" placeholder="Due Date" name="due_date" value="<?php echo e(old('due_date')); ?>">
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Priority</label>
                                 
                                    <select id="priority" name="priority"class=""style="width:100%" >
                                       <option value='Low'> Low</option>
                                       <option value="Medium" selected='true'>Medium</option>
                                       <option value="High">High</option>
                                       <option value="Urgent">Urgent</option>
                                       
                                    </select>
                                    
                                 </div>
                                
                                 
                                                                 
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Repeat Every</label>
                                    <select id="repeat_every" name="repeat_every"class=""style="width:100%" >
                                       <option value=''></option>
                                       <option value="Week">Week</option>
                                       <option value="2 Weeks">2 Weeks</option>
                                       <option value="1 Month">1 Month</option>
                                       <option value="2 Months">2 Months</option>
                                       <option value="3 Months">3 Months</option>
                                       <option value="6 Months">6 Months</option>
                                       <option value="1 Year">1 Year</option>
                                    </select>
                                    
                                    
                                 </div>

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Related To </label>
                                    <select id="related_to" name="related_to"class=""style="width:100%" >
                                       <option value='Project'>Project</option>
                                       <option value="Invoice">Invoice</option>
                                       <option value="Customer">Customer</option>
                                       <option value="Estimate">Estimate</option>
                                       <option value="Contract">Contract</option>
                                       <option value="Ticket">Ticket</option>
                                       <option value="Expense">Expense</option>
                                       <option value="Lead">Lead</option>
                                       <option value="Proposal">Proposal</option>
                                    </select>
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Staff <span class="text-danger">*</span></label>
                                   
                                    <select id="staff_id" name="staff_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($stafflist as $group): ?> 
                                       <option value="<?php echo e($group->staff_id); ?>"><?php echo e($group->first_name); ?> <?php echo e($group->last_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Tags </label>
                                    <select id="tag_id" name="tag_id"class=""style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($taglist as $group): ?> 
                                       <option value="<?php echo e($group->tag_id); ?>"><?php echo e($group->tag_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Status</label>
                                    <select id="status" name="status"class=""style="width:100%" >
                                       <option value=''>Please select</option>
                                       <option value="1">Not Started</option>
                                       <option value="2">In Progress</option>
                                       <option value="4">Testing</option>
                                       <option value="3">Completed</option>
                                    </select>
                                    
                                    
                                 </div>
                                 
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Description </label>
                                    <textarea type="text" class="form-control" id="description" placeholder="Description" name="description" value="<?php echo e(old('description')); ?>"></textarea>
                                    
                                   
                                 </div>
                              </div>
                           </div>
                          
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        
        <script type="text/javascript">

        $("#formData").validate({
          rules: {
            subject: {
              required:true,
            },
            start_date: {
              required:true,
            },
            staff_id: {
              required:true,
            },
           

    },
  messages: {
      subject:{
        required:"<?php echo e(trans('messages.700')); ?>",
      } ,
      start_date:{
        required:"<?php echo e(trans('messages.701')); ?>",
      } ,
      staff_id:{
        required:"please select staff",
      } ,
      due_date:{
        required:"<?php echo e(trans('messages.702')); ?>",
      }       
    }
  });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/css/bootstrap-datepicker.min.css" />
	  
	  <script>
  $(document).ready(function() {
  var date = new Date();
  var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  //var end = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  $('#start_date').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });
 

  $('#start_date').datepicker('setDate', today);
});
</script>
   </body>
</html>