<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>

<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 
					
			<div class="box">
            <div class="box-header">
                
            </div>
            <form action="<?php echo e(url('Admin/terms')); ?>" method="POST" id="formData1">
                <div class="box-body">
                    <?php echo e(csrf_field()); ?>

                   <div class="form-group col-md-8" >
                        <label><?php echo e('Language'); ?></label>
						<select name="language" id="language" class="form-control select2"style="width: 50%;">
                                
                                <?php foreach($termslanguage as $val): ?>
                               <!--  <option value="<?php echo e($val->language_id); ?>"><?php echo e($val->language_name); ?></option>-->
							   <option value="<?php echo e($val->language_id); ?>" <?php echo e($val->language_id == $languagedata->language_id ? 'selected' : ''); ?>><?php echo e($val->language_name); ?></option>  
                                <?php endforeach; ?>
                            </select>     
                            <span class="paytypeErr error" style="color: red;"></span>                
                    </div>
                   
                </div>
                <div class="box-footer">
                    <button type="submit"   class="btn btn-primary">Filter</button>
					</div>
                
            </form>    
        </div>
    <!--<div class="row">-->
        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
				
                    <tr>
                        <th >Sl No</th>
                        <th>Title</th>
                        <th>Description</th>
						 <th>Action</th>
                        
                    </tr>
					<tbody>
                    <?php $i = 1; ?>
                    <?php foreach($termslist as $terms): ?> 
					<?php   $parameter= Crypt::encrypt($terms->term_condition_id);?> 
                    <tr>
					<td class="center"><?php echo e($i); ?> </td>
                        <td class="center"><?php echo e($terms->term_title); ?> </td>
						<td class="center"><?php echo e($terms->term_content); ?> </td>
						<td class="center"> <a href="<?php echo e(url('Admin/deleteterms').'/'.$terms->term_condition_id); ?>"  data-toggle="tooltip" title="Delete"onclick="return confirm('Are you sure you want to delete this Terms & Condition ?');">
						<span class="glyphicon glyphicon-trash"></span> 
						</a>
						 <a href="<?php echo e(url('Admin/editterms').'/'.$parameter); ?>" data-toggle="tooltip" title="Edit">
						 <span class="glyphicon glyphicon-pencil"></span>
						 </a>
				
						 <?php if($terms->is_blocked==1): ?>  
                            <a  href="<?php echo e(url('Admin/inactive_active_terms').'/'.$terms->term_condition_id); ?>"data-toggle="tooltip" title="Blocked" onclick="return confirm('Are you sure you want to Unblock this Terms & Condition ?');" >
							<span class="glyphicon glyphicon-ban-circle"></span>     
                            </a>
                            <?php else: ?> 
                            <a href="<?php echo e(url('Admin/inactive_active_terms').'/'.$terms->term_condition_id); ?>" data-toggle="tooltip" title="Unblocked"  onclick="return confirm('Are you sure you want to block this Terms & Condition ?');" >
							<span class="glyphicon glyphicon-check"></span>       
                            </a>
                            <?php endif; ?>    
						</td>
                  
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
			<?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$termslist->appends($next_query)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
			
        </div>
    </div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>
<script>
	function inactive(id){
		var res = confirm("Are you sure you want to change this terms & condition status");
		    if(res == true) {
		    	url = "<?php echo e(url('Admin/inactive_active_terms')); ?>";
				//alert(url);
		        $.ajax({
		          type:"POST",
		          url: url,
				  data: { "_token": "<?php echo e(csrf_token()); ?>", "id": id },
		          //data: {"id":id}, 
		          success: function(data) { 
			          //alert(data);
			          if(data == 1)
			          { 
				          alert("Status has been changed successfully");
		         			 location.reload();
			          }
		    	}
		 	});
		 }  
		  
	}
	</script>
	<script type="text/javascript">
function deleteterms(id) {
	//alert(id);
	var res = confirm("Are you sure you want to delete this terms ?");
     if(res == true) {
		    	url = "<?php echo e(url('Admin/deleteterms')); ?>";
				//alert(url);
		        $.ajax({
		          type:"POST",
		          url: url,
				  data: { "_token": "<?php echo e(csrf_token()); ?>", "id": id },
		          //data: {"id":id}, 
		          success: function(data) { 
			          //alert(data);
			          if(data == 1)
			          { 
				          alert("Data has been deleted successfully");
		         			 location.reload();
			          }
		    	}
		 	});
		 }  
}
</script>
<script>
function language(val){
	//alert(val);
           window.location.href = "<?php echo e(url('Admin/changetermslanguage')); ?>" + '/' + val;
          }
 </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>