<?php $__env->startSection('content'); ?>
<div class="login-box-body">
    <p class="login-box-msg text-danger">
    <?php if(session('failed')): ?>
      <?php echo e(session('failed')); ?>

    <?php endif; ?>
    </p>
    <form action="" method="post" id="admin_login">
        <?php echo e(csrf_field()); ?>

        <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php foreach($errors->all() as $error): ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; ?>
              </ul>
          </div>
        <?php endif; ?>
      <div class="form-group has-feedback">
        <input type="number" class="form-control" name="phone_no" id="phone_no" placeholder="Phone Number">
        <span class="glyphicon glyphicon-phone form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" name="password" id="password" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
    <a href="<?php echo e(url('Admin/forgot-password')); ?>">I forgot my password</a>
  </div>
  <!-- /.login-box-body -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cus-js'); ?>
<script>
  $("#admin_login").validate({
    rules: {
      password: "required",
      phone_no: {
        required:true,
        digits: true
      }
    },
  messages: {
    password: "Password is required",
      phone_no:{
        required:"Please specify Phone no",
        digits: "Enter digits only"
      } 
    
    }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_one', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>