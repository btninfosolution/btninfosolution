<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>
<section class="content-header">
    <h1>Price Setting
        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="<?php echo e(url('Admin/editsetting')); ?>"><i class="fa fa-user-secret"></i> Setting</a></li>
        <li class="active">Price Setting </li>
    </ol>
</section>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-8">
          <!-- general form elements -->
          <div class="box box-primary">

            <!-- /.box-header -->
            <!-- form start -->
           <form action="<?php echo e(url('Admin/updatesetting')); ?>" method="POST" id="formData1">
		    <?php echo e(csrf_field()); ?>

			<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
<ul>
<?php foreach($errors->all() as $error): ?>
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>
              <div class="box-body">
                <div class="form-group" >
                  <label for="exampleInputEmail1">Base Distance(Km)</label>
                  <input type="number" class="form-control" id="distance" value="<?php echo e($Editdata->base_distance); ?>" name="distance" placeholder="Enter Distance">
				  <span class="distanceErr error" style="color: red;"></span>
                </div>
				  <input type="hidden" class="form-control" name="id" id="id" value="<?php echo e($Editdata->setting_id); ?>" >
				<div class="form-group" >
                  <label >Base Price(kwd)</label>
                  <input type="text" class="form-control" id="base_price"value="<?php echo e($Editdata->base_price); ?>" name="base_price" placeholder="Enter base price">
				  <span class="base_priceErr error" style="color: red;"></span>
                </div>
				<div class="form-group" >
                  <label >Same area base Price(kwd)</label>
                  <input type="text" class="form-control" id="same_base_price"value="<?php echo e($Editdata->same_area_base_price); ?>" name="same_base_price" placeholder="Enter same area base price">
				  <span class="same_base_priceErr error" style="color: red;"></span>
                </div>
				<div class="form-group" >
                  <label >Each additional delivery Price(kwd)</label>
                  <input type="text" class="form-control" id="addtion_delivery"value="<?php echo e($Editdata->each_addition_delivery); ?>" name="addtion_delivery" placeholder="Enter same area base price">
				  <span class="each_addition_priceErr error" style="color: red;"></span>
                </div>
				<div class="form-group">
                  <label >Minimum Price(kwd)</label>
                  <input type="text" class="form-control" id="price"value="<?php echo e($Editdata->minimum_price); ?>" name="price" placeholder="Enter minimum price">
				  <span class="priceErr error" style="color: red;"></span>
                </div>
				<div class="form-group">
                  <label >Price (per km)</label>
                  <input type="text" class="form-control" id="km" value="<?php echo e($Editdata->per_km); ?>"name="km" placeholder="Enter Per Km">
				    <span class="kmErr error" style="color: red;"></span>
                </div>
					<div class="form-group" >
                  <label >Commision(%)</label>
                  <input type="text" class="form-control" id="commision" value="<?php echo e($Editdata->commision); ?>" name="commision" placeholder="Enter Commision">
				   <span class="commisionErr error" style="color: red;"></span>
                </div>
				<div class="form-group" >
                  <label >Service Fee(kwd)</label>
                  <input type="text" class="form-control" id="service"  value="<?php echo e($Editdata->service_tax); ?>"name="service" placeholder="Enter serviec tax">
				  <span class="serviceErr error" style="color: red;"></span>
                </div>
               
               
               
                
              </div>
	
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit"  onclick="return formValidationAdd();"class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
          </div>
          </div>
          </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-js'); ?>

<script>
				function formValidationAdd(){
					
				 var data = new FormData($('#formData1')[0]);
				 var hid = $("#id").val();
				   var distance = $("#distance").val();
				   var base_price = $("#base_price").val();
				   var same_base_price = $("#same_base_price").val();
				     var each_addition_price = $("#addtion_delivery").val();
				 var price = $("#price").val();
				  var perkm = $("#km").val();
				   var commision = $("#commision").val();
				   var stax = $("#service").val();
                
             	  $(".distanceErr").html("");
              //	 $(".distanceErr").hide("");
				  $(".priceErr").html("");
              //	 $(".priceErr").hide("");
				  $(".kmErr").html("");
              //	 $(".kmErr").hide("");
				  $(".commisionErr").html("");
              //	 $(".commisionErr").hide("");
				  $(".serviceErr").html("");
				  $(".base_priceErr").html("");
              //	 $(".serviceErr").hide("");
             	
             	 if(distance==""){
               	//	$(".distanceErr").slideDown('slow');
               		$(".distanceErr").html(" Distance is required.").show();
               		$("#distance").focus();
               		return false;
               	}
				 if(price==""){
               		//$(".priceErr").slideDown('slow');
               		$(".priceErr").html(" Price is required.").show();
               		$("#price").focus();
               		return false;
				   }

				   if(isNaN(price)){
		         //  $(".priceErr").slideDown('slow');
			       $(".priceErr").html("Plesae enter valid no.").show();
			       $("#price").focus();
			       return false;
		          }	 
				  if(base_price==""){
               		//$(".priceErr").slideDown('slow');
               		$(".base_priceErr").html(" Base Price is required.").show();
               		$("#base_price").focus();
               		return false;
				   }

				   if(isNaN(base_price)){
		         //  $(".priceErr").slideDown('slow');
			       $(".base_priceErr").html("Plesae enter valid no.").show();
			       $("#base_price").focus();
			       return false;
		          }
				  if(same_base_price==""){
               		//$(".priceErr").slideDown('slow');
               		$(".same_base_priceErr").html(" same area base Price is required.").show();
               		$("#same_base_price").focus();
               		return false;
				   }
				   if(isNaN(same_base_price)){
		         //  $(".priceErr").slideDown('slow');
			       $(".same_base_priceErr").html("Plesae enter valid no.").show();
			       $("#same_base_price").focus();
			       return false;
		          }
				   if(each_addition_price==""){
               		//$(".priceErr").slideDown('slow');
               		$(".each_addition_priceErr").html(" Each addition delivery Price is required.").show();
               		$("#addtion_delivery").focus();
               		return false;
				   }
				   if(isNaN(each_addition_price)){
		         //  $(".priceErr").slideDown('slow');
			       $(".each_addition_priceErr").html("Plesae enter valid no.").show();
			       $("#addtion_delivery").focus();
			       return false;
		          }
				 if(perkm==""){
               		//$(".kmErr").slideDown('slow');
               		$(".kmErr").html(" Per Km is required.").show();
               		$("#km").focus();
               		return false;
				   }
				   if(isNaN(perkm)){
		          // $(".kmErr").slideDown('slow');
			       $(".kmErr").html("Plesae enter valid no.").show();
			       $("#km").focus();
			       return false;
		          }	
				 if(commision==""){
               	//	$(".commisionErr").slideDown('slow');
               		$(".commisionErr").html(" Commision is required.").show();
               		$("#commsion").focus();
               		return false;
				   }
			 if(isNaN(commision)){
			//$(".commisionErr").slideDown('slow');
			$(".commisionErr").html("Plesae enter valid no.").show();
			$("#commsion").focus();
			return false;
		}	
		 if(stax==""){
        // $(".serviceErr").slideDown('slow');
         $(".serviceErr").html(" Service Tax is required.").show();
         $("#service").focus();
         return false;
		 }
		 if(isNaN(stax)){
		// $(".serviceErr").slideDown('slow');
		 $(".serviceErr").html("Plesae enter valid no.").show();
		 $("#service").focus();
		 return false;
		}	
             		
		  }</script>	


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>