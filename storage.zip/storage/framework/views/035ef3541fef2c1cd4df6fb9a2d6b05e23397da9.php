<!doctype html>
<html class="no-js" lang="en">
    <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>
   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
					 <?php   $id= Crypt::encrypt($Editdata->id);?> 
                        <h4 class="page-title pull-left"><?php echo e($Editdata->client_name); ?></h4>
                     </div>
                  </div>
                   <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
			 <form action="<?php echo e(url('save-customer-invoice')); ?>" class="form-material" id="formData" name="create_customer" method="post" enctype="multipart/form-data" >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
				  
						 <input type="hidden" id="id" name="id" value="<?php echo e($Editdata->id); ?>">
						 <input type="hidden" id="enc_type" name="enc_type" value="<?php echo e($enc_type); ?>">
                     <div class="tab-content mt-3" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                           <div class="form-row">
                              <div class="col-md-6">
                                 <label for="validationCustom05">Customer</label>
                                <input type="text" class="form-control" value="<?php echo e($Editdata->client_name); ?>" name="first_name" id="first_name" readonly >
                                 <div class="invalid-feedback">
                                    Please provide a valid zip.
                                 </div>
                                 <div class="clearfix"></div>
                                 <div class="row mt-3">
                                    <div class="col-md-6 mt-3">
                                       <p class="bold">Bill To</p>
                                       <address>
                                          <span class="billing_street"><?php echo e($Editdata->billing_address); ?></span><br>
                                          <span class="billing_city"><?php echo e($Editdata->billing_city); ?></span>,
                                          <span class="billing_state"><?php echo e($Editdata->billing_state); ?></span>
                                          <br>
                                  
                                          <span class="billing_zip"><?php echo e($Editdata->billing_zip); ?></span>
                                       </address>
                                    </div>
                                    <div class="col-md-6 mt-3">
									 <a href="javascript:void(0);" class="action-icon text-info update" "><i class="fa fa-pencil-square-o"></i></a>
                                       <p class="bold">Ship To</p>
									   
                                       <address>
                                         <span class="billing_street"><?php echo e($Editdata->billing_address); ?></span><br>
                                          <span class="billing_city"><?php echo e($Editdata->billing_city); ?></span>,
                                          <span class="billing_state"><?php echo e($Editdata->billing_state); ?></span>
                                          <br>
                                  
                                          <span class="billing_zip"><?php echo e($Editdata->billing_zip); ?></span>
                                       </address>
                                    </div>
                                 </div>
                                 <div class="clearfix"></div>
                                 <label for="validationCustomUsername">Invoice Number</label>
                                 <div class="input-group">
                                    <div class="input-group-prepend">
                                       <span class="input-group-text" id="inputGroupPrepend">inv</span>
                                    </div>
                                    <input type="text" class="form-control" id="validationCustomUsername" placeholder="" readonly aria-describedby="inputGroupPrepend" >
                                    
                                 </div>
                                 <div class="clearfix"></div>
                                 <div class="row mb-3">
                                    <div class="col-md-6 mb-3">
                                       <div class="form-group">
                                          <label for="example-month-input" class="col-form-label">Invoice Date</label>
                                          <input class="form-control" type="text"   id="start" name="start">
                                       </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                       <div class="form-group">
                                          <label for="example-month-input" class="col-form-label">Due Date</label>
                                          <input class="form-control" type="text" id="expiry" name="expiry">
                                       </div>
                                    </div>
                                    <div class="form-group col-md-12">
                                     <!--  <div class="checkbox checkbox-danger">
                                          <input type="checkbox" id="cancel_overdue_reminders" name="cancel_overdue_reminders">
                                          <label for="cancel_overdue_reminders">Prevent sending overdue reminders for this invoice</label>
                                       </div>-->
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <label for="validationCustom05">Tag</label>
                                 <select class="custom-select" id="tag" name="tag">
								    <?php if(!empty($taglist)): ?>
                                     <?php foreach($taglist as $tag): ?> 
                                       <option value="<?php echo e($tag->tag_id); ?>"><?php echo e($tag->tag_name); ?></option>
                                       <?php endforeach; ?>
									   <?php endif; ?>
									   
                                 </select>
                                 <div class="clearfix"></div>
                                 <label for="validationCustom05" class="mt-3 mb-3">Allowed payment modes for this invoice</label>
                                 <select class="custom-select" name="payment">
                                    <option  value=""> select menu</option>
                                    <option value="Bank">Bank</option>
                                    <option value="Google pay">Google pay</option>
                                   
                                 </select>
                                 
                                 <div class="clearfix"></div>
                                 <div class="row mb-3 mt-3">
                                    <div class="col-md-6 mb-3">
                                       <label for="validationCustom05">Currency</label>
                                       <input type="text" class="form-control" value="<?php echo e('INR'); ?>"  readonly >
                                    </div>
                                    <div class="col-md-6 mb-3">
                                       <label for="validationCustom05">Sale Agent</label>
                                       <select class="custom-select" name="agent">
									        <?php if(!empty($stafflist)): ?>
                                          <?php foreach($stafflist as $staff): ?> 
                                       <option value="<?php echo e($staff->staff_id); ?>"><?php echo e($staff->first_name); ?> <?php echo e($staff->last_name); ?></option>
                                       <?php endforeach; ?>
									    <?php endif; ?>
									  
                                       </select>
                                       <div class="invalid-feedback">
                                          Please provide a valid zip.
                                       </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-md-6 mb-3">
                                       <label for="validationCustom05">Recurring Invoice?</label>
                                       <select class="custom-select" name="recruit">
                                          <option  value="NO"selected="selected">No</option>
                                          <option value="Every 1 month">Every 1 month</option>
                                          <option value="Every 2 month">Every 2 month</option>
                                          <option value="Every 3 month">Every 3 month</option>
										   <option value="Every 4 month">Every 4 month</option>
										   <option value="Every 5 month">Every 5 month</option>
											<option value="Every 6 month">Every 6 month</option>
										 <option value="Every 7 month">Every 7 month</option>
										  <option value="Every 8 month">Every 8 month</option>
										   <option value="Every 9 month">Every 9 month</option>
										    <option value="Every 10 month">Every 10 month</option>
											  <option value="Every 11 month">Every 11 month</option>
											    <option value="Every 12 month">Every 12 month</option>
                                       </select>
                                       <div class="invalid-feedback">
                                          Please provide a valid zip.
                                       </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                       <label for="validationCustom05">Discount Type</label>
                                       <select class="custom-select" name="dis_type">
                                 
                                          <option value="Before Tax">Before Tax</option>
                                          <option value="After Tax">After Tax</option>
                                       </select>
                                       
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-md-12 mb-3">
                                       <div class="form-group" app-field-wrapper="adminnote">
                                          <label for="adminnote" class="control-label">Admin Note</label>
                                          <textarea id="adminnote" name="adminnote" class="form-control" rows="4"></textarea>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        
                     </div>
                  </div>
               </div>
               <div class="card mt-3">
                  <div class="card-body">
                     <div class="tab-content mt-3" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                           <div class="form-row">
                              <div class="col-md-3">
                                 <div class="input-group">
                                    <select class="custom-select" name="item" id="item"onchange="itemtype()">
									 <option value="">Select item</option>
                                       <?php foreach($itemlist as $item): ?> 
									   
                                       <option value="<?php echo e($item->item_id); ?>"><?php echo e($item->item_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                    
                                 </div>
                              </div>
                            
                              <div class="col-md-6">
                                 <div class="row">
                                    <div class="col-md-4"  style="text-align:right;">              
                                       <span>Show quantity as:</span>
                                    </div>
                                    <div class="radio radio-primary radio-inline col-md-2">
                                       <input type="radio" value="1" id="sq_1" name="show_quantity_as" data-text="Qty" checked="">
                                       <label for="sq_1">Qty</label>
                                    </div>
                                   <!-- <div class="radio radio-primary radio-inline col-md-2">
                                       <input type="radio" value="2" id="sq_2" name="show_quantity_as" data-text="Hours">
                                       <label for="sq_2">Hours</label>
                                    </div>
                                    <div class="radio radio-primary radio-inline col-md-4">
                                       <input type="radio" value="3" id="sq_3" name="show_quantity_as" data-text="Qty/Hours">
                                       <label for="sq_3">Qty/Hours</label>
                                    </div>-->
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="table-responsive s_table">
                           <table class="table invoice-items-table items table-main-invoice-edit has-calculations no-mtop" id="bob">
                              <thead>
                                 <tr>
                                    <th></th>
                                    <th width="20%" align="left"><i class="fa fa-exclamation-circle" aria-hidden="true" data-toggle="tooltip" data-title="New lines are not supported for item description. Use the item long description instead."></i> Item</th>
                                    <th width="25%" align="left">Description</th>
                                    <th width="10%" align="right" class="qty">Qty</th>
                                    <th width="15%" align="right">Rate</th>
                                  
                                    <th width="10%" align="right">Amount</th>
                                    <th align="center"><i class="fa fa-cog"></i></th>
                                 </tr>
                              </thead>
							  
                              <tbody class="ui-sortable" >
							   <tbody  id="featureadd">
							  
                                 <tr class="main" >
								 
								  
                                    <td></td>
                                    <td>
                                       <textarea name="item_name[]" id="item_name" class="form-control" rows="4" placeholder="Name"></textarea>
                                    </td>
                                    <td>
                                       <textarea name="long_description[]" id="item_description" rows="4" class="form-control" placeholder="Long description"></textarea>
                                    </td>
                                    <td>
                                       <input type="number" name="quantity[]" min="1" onchange="calculation()"  class="form-control qty1" id="quan" placeholder="">
                                
                                    </td>
                                    <td>
                                       <input type="number" name="item_rate[]" id="item_rate" class="form-control" placeholder="Rate">
                                    </td>
                                   
                                    <td id="prototatl" class="total1"></td>
                                    <td>
                                       <button type="button" name="add" id="add" class="btn pull-right btn-info"><i class="fa fa-check"></i></button>
									   
                                    </td>
									 
									</tr>
									
                                
                              </tbody>
							  </tbody>
                           </table>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-md-8 offset-md-4">
                           <table class="table text-right">
                              <tbody>
                                 <tr id="subtotal">
                                    <td>Sub Total: <span id="subtotal1"class="bold" > 0.00</span>
                                    </td>
									<input type="hidden" name="sub_total" id="subtotal2"/>
									<td>
                                       <button type="button" name="add" id="add" class="btn pull-right btn-info cal">Calculate</button>
									   
                                    </td>
                                    
                                 </tr>
                                 <tr id="discount_area">
                                    <td>
                                       <div class="row">
                                          <div class="col-md-7">
                                             <span class="bold">
                                             Discount                         </span>
                                          </div>
                                          <div class="col-md-5">
                                             <div class="input-group">
                                                 <input type="number" name="discount" id="discount" class="form-control" onkeyup="discounttype()">
                                                <div class="input-group-append">
                                                   <span class="input-group-text">%</span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </td>
                                    <td class="discount-total" id="discount_total">-0.00</td>
                                 </tr>
								 <input type="hidden" name="discount_total" id="discount_total1"/>
                                <!-- <tr>
                                    <td>
                                       <div class="row">
                                          <div class="col-md-7">
                                             <span class="bold">Adjustment</span>
                                          </div>
                                          <div class="col-md-5">
                                             <input type="number" data-toggle="tooltip" data-title="The number in the input field is not formatted while edit/add item and should remain not formatted do not try to format it manually in here." value="0" class="form-control pull-left" name="adjustment" data-original-title="" title="">
                                          </div>
                                       </div>
                                    </td>
                                    <td class="adjustment">0.00</td>
                                 </tr>-->
                                 <tr>
                                    <td><span class="bold">Total :</span>
                                    </td>
                                    <td class="total" id="overall_discount">₹0.00<input type="hidden" name="total" value="0.00"></td>
									 <input type="hidden" name="overall_discount" id="overall_discount1"/>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="card mt-3">
                  <div class="card-body">
                     <div class="col-md-12">
                        <div class="form-group mtop15" app-field-wrapper="clientnote"><label for="clientnote" class="control-label">Client Note</label><textarea id="clientnote" name="clientnote" class="form-control" rows="4"></textarea></div>
                     </div>
                     <div class="col-md-12">
                        <div class="form-group mtop15" app-field-wrapper="clientnote"><label for="clientnote" class="control-label">Term & Condition</label><textarea id="terms" name="terms" class="form-control" rows="4"></textarea></div>
                     </div>
					  <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                  </div>
				  
               </div>
			   </form>
            </div>
			
         </div>
      </div>
      <!-- main content area end -->
      <!-- footer area start-->
      <footer>
         <div class="footer-area">
            <p>© Copyright 2018. All right reserved. Template by <a href="https://colorlib.com/wp/">Colorlib</a>.</p>
         </div>
      </footer>
      <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
      <div class="offset-area">
         <div class="offset-close"><i class="ti-close"></i></div>
         <ul class="nav offset-menu-tab">
            <li><a class="active" data-toggle="tab" href="#activity">Activity</a></li>
            <li><a data-toggle="tab" href="#settings">Settings</a></li>
         </ul>
         <div class="offset-content tab-content">
            <div id="activity" class="tab-pane fade in show active">
               <div class="recent-activity">
                  <div class="timeline-task">
                     <div class="icon bg1">
                        <i class="fa fa-envelope"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-check"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Added</h4>
                        <span class="time"><i class="ti-time"></i>7 Minutes Ago</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>You missed you Password!</h4>
                        <span class="time"><i class="ti-time"></i>09:20 Am</span>
                     </div>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="fa fa-bomb"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Member waiting for you Attention</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="ti-signal"></i>
                     </div>
                     <div class="tm-title">
                        <h4>You Added Kaji Patha few minutes ago</h4>
                        <span class="time"><i class="ti-time"></i>01 minutes ago</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg1">
                        <i class="fa fa-envelope"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Ratul Hamba sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Hello sir , where are you, i am egerly waiting for you.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg2">
                        <i class="fa fa-exclamation-triangle"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="fa fa-bomb"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
                  <div class="timeline-task">
                     <div class="icon bg3">
                        <i class="ti-signal"></i>
                     </div>
                     <div class="tm-title">
                        <h4>Rashed sent you an email</h4>
                        <span class="time"><i class="ti-time"></i>09:35</span>
                     </div>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse distinctio itaque at.
                     </p>
                  </div>
               </div>
            </div>
            <div id="settings" class="tab-pane fade">
               <div class="offset-settings">
                  <h4>General Settings</h4>
                  <div class="settings-list">
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Notifications</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch1" />
                              <label for="switch1">Toggle</label>
                           </div>
                        </div>
                        <p>Keep it 'On' When you want to get all the notification.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show recent activity</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch2" />
                              <label for="switch2">Toggle</label>
                           </div>
                        </div>
                        <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show your emails</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch3" />
                              <label for="switch3">Toggle</label>
                           </div>
                        </div>
                        <p>Show email so that easily find you.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Show Task statistics</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch4" />
                              <label for="switch4">Toggle</label>
                           </div>
                        </div>
                        <p>The for attribute is necessary to bind our custom checkbox with the input.</p>
                     </div>
                     <div class="s-settings">
                        <div class="s-sw-title">
                           <h5>Notifications</h5>
                           <div class="s-swtich">
                              <input type="checkbox" id="switch5" />
                              <label for="switch5">Toggle</label>
                           </div>
                        </div>
                        <p>Use checkboxes when looking for yes or no answers.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- offset area end -->
      <!-- jquery latest version -->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	  <script>
        $(document).ready(function(){
            var i = 1;
            $('#add').click(function(){
                i++;
                $('#featureadd').prepend('<tr class="main" ><tr id="row'+i+'"><td></td><td><textarea name="item_name[]" id="item_name" class="form-control" rows="4" placeholder="Name"></textarea></td><td><textarea name="long_description[]" id="item_description" class="form-control" rows="4" placeholder="Name"></textarea></td><td><input type="number" name="quantity[]" min="1" onchange="calculation()"  id="quan" class="form-control qty1" placeholder=""></td><td><input type="number" name="item_rate[]" min="1" id="item_rate" class="form-control" placeholder="Rate"></td><td id="prototatl" class="total1"></td><td><button name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></div></tr></tr>');
            });

            $(document).on('click','.btn_remove', function(){
                var button_id = $(this).attr("id");
                $("#row"+button_id+"").remove();
            });

            
        });
    </script>
	    <script type="text/javascript">
	    function itemtype(val){
	    	var hid = ($('#item').val());
			
        var url = "<?php echo e(url('get-item-detail')); ?>";
        $.ajax({
        type: "POST",
        url: url,
        data:({
          "_token": "<?php echo e(csrf_token()); ?>",
            hid : hid,
                }),
        cache: false,
		 dataType: "json",
         success : function(res){
			// alert(res);
              if(res){
                  $("#item_name").val(res.data.item_name);
				   $("#item_description").val(res.data.description);
				     $("#item_rate").val(res.data.rate);
              }

          }
	});
	}
   
    </script>
	 <script type="text/javascript">
	    function calculation(val){
	    	var quantity = ($('#quan').val());
			var price = ($('#item_rate').val());
        var url = "<?php echo e(url('get-item-calculation')); ?>";
        $.ajax({
        type: "POST",
        url: url,
        data:({
          "_token": "<?php echo e(csrf_token()); ?>",
            quantity : quantity,
			  price : price,
                }),
        cache: false,
		 dataType: "json",
         success : function(res){
			// alert(res);
              if(res){
				     $("#prototatl").html(res);
              }

          }
	});
	}
   
    </script>
	<script type="text/javascript">
	    function discounttype(val){
	    	var subtotal = ($('#subtotal1').text());
			var discount_percent=($('#discount').val());
	         discount = (discount_percent * subtotal) /100;
			 overall_discount = subtotal - discount ;
			 $("#discount_total").text(discount);
			 $("#discount_total1").val(discount);
			 $("#overall_discount").text(overall_discount);
			  $("#overall_discount1").val(overall_discount);
			 
			
	}
   
    </script>
	  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.1/css/bootstrap-datepicker.min.css" />
	   <script>
         $(function () {
           $("select").select2();
         });
      </script>
	  <script>
  $(document).ready(function() {
  var date = new Date();
  var today = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  //var end = new Date(date.getFullYear(), date.getMonth(), date.getDate());

  $('#start').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });
  $('#expiry').datepicker({
format: "yyyy-mm-dd",
todayHighlight: true,
startDate: today,
//endDate: end,
autoclose: true
  });

  $('#start,#expiry').datepicker('setDate', today);
});
</script>
<!--<script>
function CalculateItemsValue() {
	var tableId = "bob";
   var rows = document.getElementById(tableId).getElementsByTagName("tr").length;
   var rowsdata = $(this).attr("id");
    alert(rowsdata);
    var total = 0;
    for (i=1; i<=total_items; i++) {
         
        itemID = document.getElementById("qnt_"+i);
        if (typeof itemID === 'undefined' || itemID === null) {
            alert("No such item - " + "qnt_"+i);
        } else {
            total = total + parseInt(itemID.value) * parseInt(itemID.getAttribute("data-price"));
        }
         
    }
    document.getElementById("ItemsTotal").innerHTML = "$" + total;
     
}
</script>-->
<script>
$(document).on("click", ".cal", function() {
    var sum = 0;
	//var quantity1 = ($('#prototatl').text());
    //$(".qty1").each(function(){
       // sum += +$(this).val();
   // });
	$(".total1").each(function() {
   sum += +$(this).text();
});
	//alert(quantity1);
    $("#subtotal1").text(sum);
	$("#overall_discount").text(sum);
	  $("#overall_discount1").val(sum);
	$("#subtotal2").val(sum);
});
</script>
<!--<script>
function calc() 
{
  var price = document.getElementById("item_rate").value;
  var noTickets = document.getElementById("quan").value;
  var total = parseFloat(price) * noTickets;
  alert(total);
  if (!isNaN(total))
    document.getElementById("total").innerHTML = total
}
</script>-->
   </body>
</html>