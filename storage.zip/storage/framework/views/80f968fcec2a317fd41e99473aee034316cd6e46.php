<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <body class="bg-theme bg-theme1">
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
         <div class="container-fluid">
            <!-- Breadcrumb-->
            <div class="row pt-2 pb-2">
               <div class="col-sm-9">
                  <h4 class="page-title">Chnage Password</h4>
               </div>
               <div class="col-sm-3">
                  <div class="btn-group float-sm-right">
                     <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
                     <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
                     <span class="caret"></span>
                     </button>
                     <div class="dropdown-menu">
                        <a href="javaScript:void();" class="dropdown-item">Action</a>
                        <a href="javaScript:void();" class="dropdown-item">Another action</a>
                        <a href="javaScript:void();" class="dropdown-item">Something else here</a>
                        <div class="dropdown-divider"></div>
                        <a href="javaScript:void();" class="dropdown-item">Separated link</a>
                     </div>
                  </div>
               </div>
            </div>
            <!-- End Breadcrumb-->
            <?php echo $__env->make('admin/admin_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
            <hr>
            <div class="row">
               <div class="col-lg-12">
                  <div class="card">
                     <div class="card-body">
                        <ul class="nav nav-tabs nav-tabs-primary">
                           <li class="nav-item">
                              <a class="nav-link active" data-toggle="tab" href="#tabe-1"><i class="icon-home"></i> <span class="hidden-xs">Chnage Password</span></a>
                           </li>
                        </ul>

                        <form action="<?php echo e(url('update-adminpassword')); ?>" class="form-material" id="formData" name="create_customer" method="post" >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
                        <input type="hidden"   id="id" value="<?php echo e($Editdata->staff_id); ?>" name="id" >
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">New password</label>
                                    <input type="password" class="form-control" id="newpassword" placeholder="New password" name="newpassword">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Confirm  password</label>
                                    <input type="password" class="form-control" id="conpassword" placeholder="Confirm Password" name="conpassword">
                                    
                                 </div>
								
                              </div>
                           </div>
                           
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--End Row-->
            <!--End Row-->
            <div class="overlay"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
         $("#formData").validate({
           rules: {
         newpassword: {
                required:true,
                maxlength:16,
                minlength: 6
             },
             conpassword: {
                required:true,
             },
             conpassword: {
                equalTo:newpassword,
             },
            
            
          
           },
         messages: {
           newpassword:{
               required:"<?php echo e(trans('messages.316')); ?>",
               minlength:"<?php echo e(trans('messages.317')); ?>",
               maxlength:"<?php echo e(trans('messages.318')); ?>",
             } ,
             conpassword:{
               required:"<?php echo e(trans('messages.319')); ?>",
             } ,
             conpassword:{
               equalTo:"<?php echo e(trans('messages.320')); ?>",
             } ,
            
            
           
           }
         });
      </script>
   </body>
   <!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>




