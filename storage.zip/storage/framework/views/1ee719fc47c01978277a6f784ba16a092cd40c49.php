<header class="main-header">
    <!-- Logo -->
    <a href="<?php echo e(url('Admin/dashboard')); ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>C</b>C</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b><?php echo e(env('SITE_NAME')); ?></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo e(asset('dist/img/avatar.png')); ?>" class="user-image" alt="User Image">
              <span class="hidden-xs">   
               <?php if(session('full_name')): ?>
                <?php echo e(session('full_name')); ?>

              <?php endif; ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo e(asset('dist/img/avatar.png')); ?>" class="img-circle" alt="User Image">
                <p>
                <?php echo e(session('full_name')); ?> -
                <?php if( session('user_type') == 1): ?>
                   Admin 
                   <?php elseif(session('user_type') == 2): ?>
                    Sub Admin
                    <?php elseif(session('user_type') == 3): ?>
                    Manager
                   <?php else: ?>
                    Unknown
                <?php endif; ?>
                  <small>Member since <?php echo e(date('M',strtotime(session('created_at')))); ?>. <?php echo e(date('Y',strtotime(session('created_at')))); ?></small>
                </p>
              </li>
              
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                <a href="<?php echo e(url('Admin/password-change')); ?>" class="btn btn-default btn-flat">Change Password</a>
                </div>
                <div class="pull-right">
                  <a href="<?php echo e(url('Admin/logout')); ?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>