<!DOCTYPE html>
<html lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <body class="bg-theme bg-theme1">
      <!-- start loader -->
      <div id="pageloader-overlay" class="visible incoming">
         <div class="loader-wrapper-outer">
            <div class="loader-wrapper-inner" >
               <div class="loader"></div>
            </div>
         </div>
      </div>
      <!-- end loader -->
      <!-- Start wrapper-->
      <div id="wrapper">
      <!--Start sidebar-wrapper-->
      <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End sidebar-wrapper-->
      <!--Start topbar header-->
      <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!--End topbar header-->
      <div class="clearfix"></div>
      <div class="content-wrapper">
      <div class="container-fluid">
      <div class="row mt-3">
      <h4 class="page-title pull-left">Task Summary</h4>
      <div class="col-md-12">
         <div class="row" style="padding-top:20px;">
            <!--<button type="button" class="btn btn-primary mb-3">New Customer</button>-->
            <?php if(!empty($addpermission)): ?>
                   
                   <?php else: ?>
                     <a class="btn btn-primary mb-3" href="<?php echo e(url('add-task')); ?>"></i> New Task</a>
                     <?php endif; ?>
         </div>
         <?php echo $__env->make('admin/admin_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      </div>
      <?php if(session('user_type') ==1): ?>
      <div class="row" style="padding-top:20px;">
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd"><?php echo e($not_started); ?></h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">Not Started</span></h4>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd"><?php echo e($in_progress); ?></h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">IN Progress</span></h4>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd"><?php echo e($testing); ?></h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">Testing</span></h4>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-2">
                     <div class="single-report">
                        <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                           <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                           </div>
                           <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                              <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                           </div>
                        </div>
                        <div class="s-sale-inner pt--30 mb-3">
                           <div class="s-report-title d-flex justify-content-between">
                              <h4 class="header-title mb-0 hd"><?php echo e($complete); ?></h4>
                           </div>
                           <h4 class="header-title mb-0 hd"><span class="org">Completed</span></h4>
                        </div>
                     </div>
                  </div>
                  
                  
               </div>
               <?php endif; ?>
               <?php if(session('user_type') ==1): ?>
                     <div class="card">
                        <div class="card-body">
                           <h4 class="header-title">Search</h4>
                           <form class="form-horizontal"  action="" method="get">
                           <div class="row">
                                <div class="form-group col-md-3">
                                            <label class="col-form-label">Staff</label>
                                            <select id="staff_name" name="staff_name"class="custom-select">
                                            <option value='' selected='true'>Please Select </option>
                                       <?php foreach($stafflist as $group): ?> 
                                       <option value="<?php echo e($group->staff_id); ?>" <?=isset($_REQUEST['staff_name']) && $_REQUEST['staff_name']==$group->staff_id ? 'selected=""' : '';?>><?php echo e($group->first_name); ?> <?php echo e($group->last_name); ?></option>
                                       <?php endforeach; ?>
                                            </select>
                                            <label for="example-date-input" class="col-form-label"></label>
                                            <div class="clearfix"></div>
                                            <button type="submit" class="btn btn-primary next" id="customer_info_save">Filter </button> 
                                        </div>
                                        
                                        <div class="form-group col-md-3">
                                            <label for="example-date-input" class="col-form-label">Start Date</label>
                                            <input class="form-control" type="date" name="to_date"value="<?=isset($_REQUEST['to_date']) && $_REQUEST['to_date'] ? $_REQUEST['to_date'] : '' ?>" id="example-date-input">
                                            
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label for="example-date-input" class="col-form-label">Due Date</label>
                                            <input class="form-control" type="date" name="due_date"value="<?=isset($_REQUEST['due_date']) && $_REQUEST['due_date'] ? $_REQUEST['due_date'] : '' ?>" id="example-date-input">
                                            
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label class="col-form-label">Status</label>
                                            <select class="custom-select" id="status" name="status">
                                                <option value="">Please select</option>
                                                <option value="1" <?=isset($_REQUEST['status']) && $_REQUEST['status']==1 ? 'selected=""' : '';?>>Not Started</option>
                                                <option value="2" <?=isset($_REQUEST['status']) && $_REQUEST['status']==2 ? 'selected=""' : '';?>>In Progress</option>
                                                <option value="3" <?=isset($_REQUEST['status']) && $_REQUEST['status']==3 ? 'selected=""' : '';?>>Completed</option>
                                                <option value="4" <?=isset($_REQUEST['status']) && $_REQUEST['status']==4 ? 'selected=""' : '';?>>Testing</option>
                                            </select>
                                          
                                        </div>
                                       
                                           
                                           
                                        </div>
                                        </form>
                                        <?php endif; ?>
      
      <div class="card">
      <div class="card-body">
         <h5 class="card-title">Task</h5>
         <div class="table-responsive">
            <table class="table footable"  id="dataTable" class="text-center" >
               <thead>
                  <tr>
                     <th scope="col">#</th>
                    
                                       <th scope="col">Name</th>
                                       <th scope="col">Status</th>
                                       <th scope="col">Start Date</th>
                                       <th scope="col">Due Date</th>
                                       <th scope="col">Assign to</th>
                                       <th scope="col">Tags</th>
                                       <th scope="col">Priority</th>
                                       <th scope="col">Action</th>
                  </tr>
               </thead>
               <tbody>
               <?php $i = 1; ?>
                                    <?php if(!empty($tasklist)): ?>
                                    <?php foreach($tasklist as $cus): ?> 
                                    <?php   $id= Crypt::encrypt($cus->task_id );?> 
                                    <tr>
                                       <td><?php echo e($i); ?></td>
                                       <td><?php echo e($cus->subject); ?></td>
                                       <td>
                                       <?php if($cus->task_status ==1): ?>
                                       <?php echo e('Not Started'); ?> 
                                       <?php elseif($cus->task_status ==2): ?>
                                       <?php echo e('In Progress'); ?> 
                                       <?php elseif($cus->task_status ==3): ?>
                                       <?php echo e('Completed'); ?> 
                                       <?php elseif($cus->task_status ==4): ?>
                                       <?php echo e('Testing'); ?> 
                                     
                                       <?php endif; ?>
                                       </td>
                                       <td><?php echo e($cus->start_date); ?></td>
                                       <td><?php echo e($cus->due_date); ?></td>
                                       <td><?php echo e($cus->first_name); ?> <?php echo e($cus->last_name); ?></td>
                                       <td><?php echo e($cus->tag_name); ?></td>
                                       <td><?php echo e($cus->priority); ?></td>
                                       <td> 
                                       <?php if(!empty($editpermission)): ?>
                                       <?php else: ?>
                                       <a href="<?php echo e(url('task-edit').'/'.$id); ?>" title="Details" data-toggle="tooltip"><span class="badge badge-pill badge-primary">Edit</span></a>
                                       <?php endif; ?>
                                       <?php if(session('user_type') ==1): ?>
                               <a data-id="<?php echo e($cus->is_deleted); ?>"href="<?php echo e(url('delete-record')); ?>?status_data=<?php echo e(Crypt::encrypt($cus->task_id.'&tbl_task&task_id&'.$cus->is_deleted.'&task'.'&0')); ?>" title="Delete" onclick="return confirm('Are you sure you want to delete this Task ?');" data-toggle="tooltip"><span class="badge badge-pill badge-danger">Delete</span></a> </td>
                                   <?php endif; ?>
                                    </tr>
                                    <?php $i++; ?>
                                    <?php endforeach; ?>
                                    <?php endif; ?> 
               </tbody>
               <tfoot class="hide-if-no-paging">
                  <td colspan="5">
                     <div class="pagination"></div>
                  </td>
               </tfoot>
            </table>
            <!--start overlay-->
            <div class="overlay toggle-menu"></div>
            <!--end overlay-->
         </div>
         <!-- End container-fluid-->
      </div>
      <!--End content-wrapper-->
      <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
      <!--End Back To Top Button-->
      <!--Start footer-->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
</html>
</body>