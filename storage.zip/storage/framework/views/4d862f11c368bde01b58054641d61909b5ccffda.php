<?php $__env->startSection('page-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-header'); ?>

<section class="content-header">
    <h1><?php echo e($page_title); ?>

        <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('Admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo e($page_title); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
<form action="<?php echo e(url('Admin/payment-master')); ?>" method="POST"  id="user_filter" >
<?php echo e(csrf_field()); ?>

<div class="box-body">
    <div class="form-group col-md-4">
                    <label >Phone or Email or Name <span class="text-danger">*</span></label>
                    <input type="text" name="keyword" id="keyword"  class="form-control"  placeholder="Enter Phone Number Or Email or Name" value="<?php if(isset($keyword)): ?><?php echo e($keyword); ?><?php endif; ?>">

    </div>
</div>
    <div class="box-footer">
                    <button type="submit"   class="btn btn-primary">Filter</button>
                    <button type="button" id="reset_btn"  class="btn btn-primary">Reset</button>
    </div>

</form>
</div>
 
    <div class="row">
        <div class="box">
            <div class="box-body">
                <table class="table table-bordered">
				
                    <tr>
                        <th >Sl No</th>
                        <th>Manager Name</th>
                        <th>Total Consignment Price</th>
						 <th>Action</th>
                        
                    </tr>
					<tbody id="tabledata">
                     <?php $i = ($Paymentdata->currentpage()-1)* $Paymentdata->perpage() + 1; ?>
                    <?php foreach($Paymentdata as $payment): ?> 
					 <?php   $id= Crypt::encrypt($payment->user_id);?>	

                    <tr>
					<td class="center"><?php echo e($i); ?> </td>
                        <td class="center" name="title" id="title"><?php echo e($payment->full_name); ?> </td>
						<?php if($payment->sum ==""): ?> 
						<td class="center" name="content" id="content">0 </td>
						<?php else: ?> 
						<td class="center" name="content" id="content"><?php echo e($payment->sum); ?> </td>
						<?php endif; ?> 
						<td class="center">
						 <a href="<?php echo e(url('Admin/paymentdetail').'/'.$id); ?>" data-toggle="tooltip" title="Detail">
                         <span class="glyphicon glyphicon-th-list"></span>
                         </a>
						  <a href="<?php echo e(url('Admin/manager-consignment-list').'/'.$id); ?>" data-toggle="tooltip" title="Consignment List"><span class="glyphicon glyphicon-list-alt"></span></a>
                            <a href="<?php echo e(url('Admin/manager-payment-list').'/'.$id); ?>" data-toggle="tooltip" title="Payment History"><span class="glyphicon glyphicon-usd"></span></a>
						  
				
						</td>
                  
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
			 <?php echo $__env->make('helpers.admin_pagination',array('paginator'=>$Paymentdata), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
	<?php $__env->startSection('page-js'); ?>
	<script>
$("#user_filter").validate({
    rules: {
        keyword: "required",
    }
});

$("#reset_btn").click(function(){
    //$("#user_filter")[0].reset();
    $("#keyword").val("");
    window.location.href = "<?php echo e(url('Admin/payment-master')); ?>";
});
</script>
<?php $__env->stopSection(); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/template_two', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>