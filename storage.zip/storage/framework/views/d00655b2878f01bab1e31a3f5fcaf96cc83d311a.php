<!doctype html>
<html class="no-js" lang="en">
   <?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Staff</h4>
                     </div>
                  </div>
                  <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Staff Details</a>
                         
                        </div>
                     </nav>
                     <form action="<?php echo e(url('update-staff')); ?>" class="form-material" id="formData" name="create_customer" method="post"enctype="multipart/form-data"  >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
                        <input type="hidden" id="id" name="id" value="<?php echo e($Editdata->staff_id); ?>">
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">First Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="first_name" placeholder="First Name" name="first_name"  value="<?php echo e($Editdata->first_name); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Last Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="last_name" placeholder="Last Name" name="last_name"  value="<?php echo e($Editdata->last_name); ?>">
                                    
                                 </div>

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Email <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="email" placeholder="Email" name="email"  value="<?php echo e($Editdata->email); ?>" >
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Phone <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone"  value="<?php echo e($Editdata->phone); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Birth date </label>
                                    <input type="date" class="form-control" id="birth_date" placeholder="Birth Date" name="birth_date" value="<?php echo e($Editdata->birth_date); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Anniversary date </label>
                                    <input type="date" class="form-control" id="anniversary" placeholder="Anniversary" name="anniversary" value="<?php echo e($Editdata->anniversary_date); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Date Of Joining</label>
                                    <input type="date" class="form-control"  placeholder="Date Of Joining" name="join_date" value="<?php echo e($Editdata->joining_date); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Date of Resignation </label>
                                    <input type="date" class="form-control"  placeholder="Date of Resignation" name="resign_date" value="<?php echo e($Editdata->resign_date); ?>">
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Hourly Rate </label>
                                    <input type="text" class="form-control" id="hourly_rate" placeholder="Hourly Rate" name="hourly_rate"  value="<?php echo e($Editdata->hourly_rate); ?>">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Password</label>
                                    <input type="password" class="form-control" id="password" placeholder="Password" name="password" >
                                    
                                 </div>
                                                                 
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Facebook </label>
                                    <input type="text" class="form-control" id="facebook" placeholder="facebook" name="facebook"  value="<?php echo e($Editdata->facebook); ?>">
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Linkedin </label>
                                    <input type="text" class="form-control" id="linkln" placeholder="Linkedin" name="linkln"  value="<?php echo e($Editdata->linkln); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Twitter </label>
                                    <input type="text" class="form-control" id="twitter" placeholder="Twitter " name="twitter" value="<?php echo e($Editdata->twitter); ?>">
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Skype </label>
                                    <input type="text" class="form-control" id="skype" placeholder="Skype" name="skype"  value="<?php echo e($Editdata->skype); ?>">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                 
                                    <label for="profile_image" class="profile-image">Profile image</label>
                                    <input type="file" name="profile_image" class="form-control" id="profile_image">
                                
                                 <?php if($Editdata->profile_image !=''): ?>
                                                <a href="#" >  <span class="thumb-small avatar inline"><img src="<?php echo e(asset('public/uploads/contact_image/'.$Editdata->profile_image)); ?>" style="height: 40px; width: 30px;" class="img-circle"></span> </a>
                                                <?php else: ?>
                                                <a href="#" >  <span class="thumb-small avatar inline"><img src="<?php echo e(asset('public/uploads/'.'noimg.png')); ?>" style="height: 40px; width: 30px;" class="img-circle"></span> </a>
                                                <?php endif; ?>
                             
                              </div>
                              <div class="col-md-6 mb-3">
                                 
                                 <label for="profile_image" class="profile-image">Upload CV</label>
                                 <input type="file" name="cv"onchange="fileValidation(this)" class="form-control" id="cv">
                                 <?php if($Editdata->cv !=''): ?>
                                                <a href="<?php echo e(url('cv-download').'/'.$Editdata->cv); ?>" >  <span class="thumb-small avatar inline"><img src="<?php echo e(asset('public/uploads/'.'cv.png')); ?>" style="height: 40px; width: 30px;" class="img-circle"></span> </a>
                                               
                                                <?php endif; ?>
                            
                          
                           </div>
                           </div>
                          
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
        $("#formData").validate({
          rules: {
            first_name: {
              required:true,
            },
            last_name: {
              required:true,
            },
            email: {
              required:true,
              email:true,
            },
            phone: {
             required:true,
             digits:true,
             minlength:10,
             maxlength:10, 
            },
            hourly_rate: {
              //	required:true,
                digits:true,
            },
            
     
     
	  
    },
  messages: {
      first_name:{
        required:"<?php echo e(trans('messages.500')); ?>",
      } ,
      last_name:{
        required:"<?php echo e(trans('messages.501')); ?>",
      } ,
      email:{
         required:"<?php echo e(trans('messages.301')); ?>",
          email:"<?php echo e(trans('messages.302')); ?>",
      } ,
      phone:{
        required:"<?php echo e(trans('messages.305')); ?>",
        digits:"<?php echo e(trans('messages.306')); ?>",
        minlength:"<?php echo e(trans('messages.306')); ?>",
        maxlength:"<?php echo e(trans('messages.306')); ?>",
      } ,
      
      
    }
  });
</script>
<script>
                    function fileValidation(e){
                      
        //var fileInput = document.getElementById('file');
        var fileInput = e;
      //  alert(filePath);
        var filePath = fileInput.value;
        console.log('e = ' + e.files[0].size)
        var allowedExtensions = /(\.pdf)$/i;
        if(!allowedExtensions.exec(filePath)){
          alert('Please upload file having extensions .pdf only.');
          fileInput.value = '';
          return false;
        } else if (e.files[0].size > 2000000) {
          alert('File size cannot be greater than 2 MB');
          fileInput.value = '';
          return false;
        } else {
          readURL(e);
          return true;
        }
      }
      </script>
   </body>
</html>