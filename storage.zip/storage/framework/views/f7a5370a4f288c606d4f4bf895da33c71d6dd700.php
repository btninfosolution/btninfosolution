<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>BTN CRM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/metisMenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/slicknav.min.css')); ?>">
    <!-- amcharts css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/typography.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/default-css.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/responsive.css')); ?>">
    <!-- modernizr css -->
    <script src="<?php echo e(asset('public/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/select2.css')); ?>">
    <style>
  label.error {
  color:red;
  }
  .btn_butt a{color: #415164;
    background-color: #f1f5f7;
    border-color: #e6e9eb;}
	.mtop30{margin-top:30px;}
	.payment-preview-wrapper {
    background: #84c529;
    padding: 15px;
    text-align: center;
    color: #fff;
    margin-top: 25px;
    font-size: 16px;
}
.clearfix{clear:both;}

</style>
</head>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

   <body>
      <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
      <!-- preloader area start -->
      <div id="preloader">
         <div class="loader"></div>
      </div>
      <!-- preloader area end -->
      <!-- page container area start -->
      <div class="page-container">
         <!-- sidebar menu area start -->
         <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
         <!-- sidebar menu area end -->
         <!-- main content area start -->
         <div class="main-content">
            <!-- header area start -->
            <?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
               <div class="row align-items-center">
                  <div class="col-sm-6">
                     <div class="breadcrumbs-area clearfix">
                        <h4 class="page-title pull-left">Staff</h4>
                     </div>
                  </div>
                  <?php echo $__env->make('admin/page_title', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
               </div>
            </div>
            <!-- page title area end -->
            <div class="main-content-inner">
               <div class="card" style="margin-top:20px;">
                  <div class="card-body">
                     <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                           <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Staff Details</a>
                         
                        </div>
                     </nav>
                     <form action="<?php echo e(url('save-staff')); ?>" class="form-material" id="formData" name="create_customer" method="post"enctype="multipart/form-data"  >
                        <?php echo e(csrf_field()); ?>

                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger"  style="color: #fff !important;">
                           <ul>
                              <?php foreach($errors->all() as $error): ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; ?>
                           </ul>
                        </div>
                        <?php endif; ?>
                        <div class="tab-content mt-3" id="nav-tabContent">
                           <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="form-row">
                                
								  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">First Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="first_name" placeholder="First Name" name="first_name" value="<?php echo e(old('first_name')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Last Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="last_name" placeholder="Last Name" name="last_name" value="<?php echo e(old('last_name')); ?>">
                                    
                                 </div>

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Email <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="email" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Phone <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" value="<?php echo e(old('phone')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Birth date </label>
                                    <input type="date" class="form-control" id="birth_date" placeholder="Birth Date" name="birth_date" value="<?php echo e(old('birth_date')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Anniversary date </label>
                                    <input type="date" class="form-control" id="anniversary" placeholder="Anniversary" name="anniversary" value="<?php echo e(old('anniversary')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Date Of Joining </label>
                                    <input type="date" class="form-control"  placeholder="Date Of Joining" name="join_date" value="<?php echo e(old('join_date')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Date of Resignation </label>
                                    <input type="date" class="form-control"  placeholder="Date of Resignation" name="resign_date" value="<?php echo e(old('resign_date')); ?>">
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Hourly Rate </label>
                                    <input type="text" class="form-control" id="hourly_rate" placeholder="Hourly Rate" name="hourly_rate" value="<?php echo e(old('hourly_rate')); ?>">
                                   
                                 </div>
                                                                 
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Password<span class="text-danger">*</span></label>
                                    <input type="password" class="form-control" id="password" placeholder="Password" name="password" value="<?php echo e(old('password')); ?>">
                                    
                                 </div>
                                 

                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Facebook </label>
                                    <input type="text" class="form-control" id="facebook" placeholder="facebook" name="facebook" value="<?php echo e(old('facebook')); ?>">
                                    
                                 </div>

                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Linkedin </label>
                                    <input type="text" class="form-control" id="linkln" placeholder="Linkedin" name="linkln" value="<?php echo e(old('linkln')); ?>">
                                    
                                 </div>
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Twitter </label>
                                    <input type="text" class="form-control" id="twitter" placeholder="Twitter " name="twitter" value="<?php echo e(old('twitter')); ?>">
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Skype </label>
                                    <input type="text" class="form-control" id="skype" placeholder="Skype" name="skype" value="<?php echo e(old('skype')); ?>">
                                   
                                 </div>
                                 <div class="col-md-6 mb-3">
                                
                                    <label for="profile_image" class="profile-image">Profile image</label>
                                    <input type="file" name="profile_image" class="form-control" id="profile_image">
                                 
                              </div>
                              <div class="col-md-6 mb-3">
                                
                                    <label for="profile_image" class="profile-image">Upload CV</label>
                                    <input type="file" name="cv"onchange="fileValidation(this)" class="form-control" id="cv">
                                 
                              </div>
                              </div>
                           </div>
                          
                        </div>
                        <button type="submit" class="btn btn-primary next" id="customer_info_save">Save </button> 
                     </form>
                  </div>
               </div>
                  
            </div>
         </div>
         <!-- main content area end -->
         <!-- footer area start-->
         <footer>
            <div class="footer-area">
               <p>© Copyright 2020. All right reserved. Template by <a href="https://btninfosolution.in/">Btn Infosolution</a>.</p>
            </div>
         </footer>
         <!-- footer area end-->
      </div>
      <!-- page container area end -->
      <!-- offset area start -->
     
      <!-- offset area end -->
      <!-- jquery latest version -->
      <?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       <script>
         $(function () {
           $("select").select2();
         });
      </script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
        
        <script type="text/javascript">
        $("#formData").validate({
          rules: {
            first_name: {
              required:true,
            },
            last_name: {
              required:true,
            },
            email: {
              required:true,
              email:true,
            },
            phone: {
             required:true,
             digits:true,
             minlength:10,
             maxlength:10, 
            },
            hourly_rate: {
              
                digits:true,
            },
            password: {
                required:true,
                minlength:6,
                maxlength:16, 
            },
     
     
	  
    },
  messages: {
      first_name:{
        required:"<?php echo e(trans('messages.500')); ?>",
      } ,
      last_name:{
        required:"<?php echo e(trans('messages.501')); ?>",
      } ,
      email:{
         required:"<?php echo e(trans('messages.301')); ?>",
          email:"<?php echo e(trans('messages.302')); ?>",
      } ,
      phone:{
        required:"<?php echo e(trans('messages.305')); ?>",
        digits:"<?php echo e(trans('messages.306')); ?>",
        minlength:"<?php echo e(trans('messages.306')); ?>",
        maxlength:"<?php echo e(trans('messages.306')); ?>",
      } ,
     
      password:{
        required:"<?php echo e(trans('messages.5')); ?>",
        minlength:"<?php echo e(trans('messages.317')); ?>",
        maxlength:"<?php echo e(trans('messages.318')); ?>",

      } ,
     
      
	 
    
    }
  });
</script>
<script>
                    function fileValidation(e){
                      
        //var fileInput = document.getElementById('file');
        var fileInput = e;
      //  alert(filePath);
        var filePath = fileInput.value;
        console.log('e = ' + e.files[0].size)
        var allowedExtensions = /(\.pdf)$/i;
        if(!allowedExtensions.exec(filePath)){
          alert('Please upload file having extensions .pdf only.');
          fileInput.value = '';
          return false;
        } else if (e.files[0].size > 2000000) {
          alert('File size cannot be greater than 2 MB');
          fileInput.value = '';
          return false;
        } else {
          readURL(e);
          return true;
        }
      }
      </script>
   </body>
</html>