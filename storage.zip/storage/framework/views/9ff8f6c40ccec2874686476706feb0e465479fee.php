<?php $__env->startSection('content'); ?>
<?php if(!empty($consignments)): ?>
<table>
    <thead>
        <tr>
            <th>Id</th>
            <th>Date</th>
            <th>Cost</th>
            <th>Customer Name</th>
            <th>Trunsaction Number</th>
            <th>Trunsaction Date</th>
            <th>Trunsaction Amount</th>
        </tr>
    </thead>
    <tbody>
    <?php  
    $i=0;
     ?>
    <?php foreach($consignments as $consign): ?>
    <tr>
        <td><?php echo e($consign->consignment_id); ?></td>
        <td><?php echo e(date("d-m-Y H:i:s",strtotime($consign->pickup_date_time))); ?></td>
        <td><?php echo e(round($consign->payable_cost,2)); ?></td>
        <td><?php echo e(ucfirst($consign->cust_name)); ?></td>
        <td><?php echo e($consign->refund_transaction_number); ?></td>
        <td><?php echo e(date("d-m-Y",strtotime($consign->refund_date_time))); ?></td>
        <td><?php echo e($consign->refund_amount); ?></td>
    </tr>
    <?php if(++$i%45 == 0): ?>
    </tbody>
    </table>
    <div class="page-break"></div>
    <table>
        <tr>
            <th>Id</th>
            <th>Date</th>
            <th>Cost</th>
            <th>Customer Name</th>
            <th>Trunsaction Number</th>
            <th>Trunsaction Date</th>
            <th>Trunsaction Amount</th>
        </tr>
    <tbody>
    <?php endif; ?>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/template_pdf', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>