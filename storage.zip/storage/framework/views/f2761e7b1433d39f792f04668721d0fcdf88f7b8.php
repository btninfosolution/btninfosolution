<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
<?php echo $__env->make('admin/admin_head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>

<body class="bg-theme bg-theme1">

<!-- Start wrapper-->
 <div id="wrapper">

  <!--Start sidebar-wrapper-->
  <?php echo $__env->make('admin/admin_leftpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <!--End sidebar-wrapper-->

<!--Start topbar header-->
<?php echo $__env->make('admin/admin_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--End topbar header-->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Profile</h4>
		   
	   </div>
	   <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->
     
     
    
     
 
    
      <div class="row">
      <?php   $id= Crypt::encrypt($Editdata->id);?> 
      
      <?php echo $__env->make('admin/customer/customer_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      
      
        <div class="col-lg-8">
           <div class="card">
              <div class="card-body"> 
                <ul class="nav nav-tabs nav-tabs-primary">
                  <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#tabe-1"><i class="icon-home"></i> <span class="hidden-xs">Customers Details</span></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#tabe-2"><i class="icon-user"></i> <span class="hidden-xs">Billing and Shipping</span></a>
                  </li>
                 
                  
                </ul>
                <?php echo $__env->make('admin/admin_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								<form action="<?php echo e(url('update-customer')); ?>" class="form-material" id="formData" name="create_customer" method="post" >
                             <?php echo e(csrf_field()); ?>

                              <?php if(count($errors) > 0): ?>
                             <div class="alert alert-danger"  style="color: #fff !important;">
                              <ul>
                                <?php foreach($errors->all() as $error): ?>
                                 <li><?php echo e($error); ?></li>
                                 <?php endforeach; ?>
                                 </ul>
                                  </div>
                                   <?php endif; ?>
								   <input type="hidden" id="id" name="id" value="<?php echo e($Editdata->id); ?>">
								    <input type="hidden" id="enc_type" name="enc_type" value="<?php echo e($enc_type); ?>">

                <!-- Tab panes -->
                <div class="tab-content">
                  <div id="tabe-1" class="container tab-pane active">
                    
                    <div class="tab-content mt-3" id="nav-tabContent">
                                    
                                <div class="tab-pane fade active show" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                <div class="form-row">
                                <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Company Name</label>
                                    <input type="text" class="form-control form-control-rounded" value="<?php echo e($Editdata->company_name); ?>" id="company_name" placeholder="company Name" name="company_name">
                                    
                                 </div>
                                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Client Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-rounded" value="<?php echo e($Editdata->client_name); ?>" id="client_name" placeholder="Client Name" name="client_name">
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">GST No</label>
                                    <input type="text" class="form-control form-control-rounded" id="gst" value="<?php echo e($Editdata->gst_no); ?>"name="gst" placeholder="GSTN" >
                                    
                                 </div>
                                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Phone <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-rounded" id="phone" value="<?php echo e($Editdata->phone); ?>"placeholder="Phone" name="phone">
                                   
                                 </div>
                                
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Group</label>
                                    <select id="group" name="group[]" class="custom-select form-control-rounded" yle="width:100%" multiple="">
                            <?php
                                             if($grouplist)
                                             {
                                                foreach ($grouplist as $key => $value)
                                                {
                                                    $select = '';
                                                    if($selected_category)
                                                    {
                                                        foreach ($selected_category as $skey => $svalue)
                                                        {
                                                          if($svalue->group_id==$value->group_id)
                                                          {
                                                              $select = 'selected=""';
                                                          }
                                                        }
                                                    }
                                                ?>
                                                  <option value="<?=$value->group_id?>" <?=$select?>><?=$value->group_name?></option>
                                                <?php
                                                }
                                             }
                                             ?>
                         </select>
                                    
                                 </div>
                                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Country</label>
                                    <select id="country" name="country"class="custom-select form-control-rounded"style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($countrylist as $country): ?> 
                                       <option value="<?php echo e($country->country_id); ?>" <?php echo e($Editdata->country_id == $country->country_id  ? 'selected' : ''); ?>><?php echo e($country->country_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                 </div>
                                   
                                   
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">State</label>
                                    <input type="text" class="form-control form-control-rounded" value="<?php echo e($Editdata->state); ?>" id="state" name="state" placeholder="state">
                                    
                                 </div>
                                                
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">City</label>
                                    <input type="text" class="form-control form-control-rounded" id="city"value="<?php echo e($Editdata->city); ?>" name="city"placeholder="city" >
                                    
                                 </div>
                                   
                                   
                                     <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Website</label>
                                    <input type="text" class="form-control form-control-rounded" id="website"value="<?php echo e($Editdata->website); ?>" name="website" placeholder="" >
                                    
                                 </div>
                                                
                                  <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Address</label>
                                    <textarea id="address" name="address" class="form-control form-control-rounded" rows="4"><?php echo e($Editdata->address); ?></textarea>
                                    
                                 </div>
                                   
                                   
                                   
                                   
                                   
                                   
                                 </div>      
                                </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                        <div class="form-row">
            <div class="col-md-6 mb-3">                                        
			<h5 class="no-mtop">Billing Address <a href="#" class="pull-right billing-same-as-customer"><small class="font-medium-xs">Same as Customer Info</small></a></h5>
            <hr>
            </div>
            
            <div class="col-md-6 mb-3">                                        
			<h5 class="no-mtop">Billing Address <a href="#" class="pull-right billing-same-as-customer"><small class="font-medium-xs">Same as Customer Info</small></a></h5>
            <hr>
            </div>
            
            <div class="clearfix"></div>
                                        
                                        
                 
                                                
                               
                                   
                                   
                                   
                                   
                                   
                                   
                                 </div>
                                    </div>
                                    
                                </div>
                    
                    
                  </div>
                  <div id="tabe-2" class="container tab-pane fade">
                   
                   
                   <div class="tab-pane fade active show" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                                        <div class="form-row">
           
            
            <div class="clearfix"></div>
                                        
                                        
            <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">City</label>
                                    <input type="text" class="form-control form-control-rounded"value="<?php echo e($Editdata->billing_city); ?>" id="billing_city" name="billing_city" placeholder="" >
                                   
                                 </div>
                                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">State</label>
                                    <input type="text" class="form-control form-control-rounded" value="<?php echo e($Editdata->billing_state); ?>"id="billing_state" name="billing_state" placeholder="" >
                                    
                                 </div>
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Country</label>
                                    <select id="bill_country" name="bill_country"class="form-control form-control-rounded"style="width:100%" >
                                       <option value='' selected='true'>Please Select </option>
                                       <?php foreach($countrylist as $country): ?> 
                                       <option value="<?php echo e($country->country_id); ?>" <?php echo e($Editdata->billing_country_id == $country->country_id  ? 'selected' : ''); ?>><?php echo e($country->country_name); ?></option>
                                       <?php endforeach; ?>
                                    </select>
                                 </div>
                                                
                                
                                
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom05">Zip</label>
                                    <input type="text" class="form-control form-control-rounded" id="bill_zip" value="<?php echo e($Editdata->billing_zip); ?>" name="bill_zip" placeholder="" >
                                    
                                 </div>
                                
                                
                                 <div class="col-md-6 mb-3">
                                    <label for="validationCustom03">Address</label>
                                    <textarea id="address" name="bill_address" class="form-control form-control-rounded" rows="4"><?php echo e($Editdata->billing_address); ?></textarea>
                                    
                                 </div>
                                   
                                   
                                   
                                 </div>
                                    </div>
                   
                   
                   
                  </div>
               
                </div>
              </div>
           </div>

        </div>

        
      </div><!--End Row-->
    
    
   
    

    
   
      <!--End Row-->
    
    
   
	  <div class="overlay"></div>
	<!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
   </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
	<!--Start footer-->
	<?php echo $__env->make('admin/admin_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
         $(function () {
           $("select").select2();
         });
      </script>
      <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
	   <script type="text/javascript">
  $("#formData").validate({
    rules: {
        client_name: {
        	required:true,
      },
      phone: {
        	required:true,
         digits:true,
         minlength:10,
         maxlength:10,  
      },
     
     
	  
    },
  messages: {
    client_name:{
        required:"<?php echo e(trans('messages.304')); ?>",
      } ,
      phone:{
        required:"<?php echo e(trans('messages.305')); ?>",
       digits:"<?php echo e(trans('messages.306')); ?>",
         minlength:"<?php echo e(trans('messages.306')); ?>",
        maxlength:"<?php echo e(trans('messages.306')); ?>",
      } ,
     
      
	 
    
    }
  });
</script>
	
</body>

<!-- Mirrored from codervent.com/dashtreme/demo/transparent-admin/vertical-layout/ui-nav-tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 09 Oct 2020 13:56:21 GMT -->
</html>
