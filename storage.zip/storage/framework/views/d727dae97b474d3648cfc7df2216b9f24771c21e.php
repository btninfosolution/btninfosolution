<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>BTN CRM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/metisMenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/slicknav.min.css')); ?>">
    <!-- amcharts css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/typography.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/default-css.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/responsive.css')); ?>">
    <!-- modernizr css -->
    <script src="<?php echo e(asset('public/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
	<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/select2.css')); ?>">
    <style>
  label.error {
  color:red;
  }
  .btn_butt a{color: #415164;
    background-color: #f1f5f7;
    border-color: #e6e9eb;}
	.mtop30{margin-top:30px;}
	.payment-preview-wrapper {
    background: #84c529;
    padding: 15px;
    text-align: center;
    color: #fff;
    margin-top: 25px;
    font-size: 16px;
}
.clearfix{clear:both;}
.panel_s .panel-body {
    background: #fff;
    border: 1px solid #dce1ef;
    border-radius: 4px;
    padding: 20px;
    position: relative;
}
    .btn-default-temp {
    color: #415164;
    background-color: #f1f5f7;
    border-color: #e6e9eb;
}
.panel_s .panel-body {
    background: #fff;
    border: 1px solid #dce1ef;
    border-radius: 4px;
    padding: 20px;
    position: relative;
}
.col-md-5ths{
	width: 20%; 
    float: left; 
	position: relative;
    min-height: 1px;
    padding-right: 15px;
    padding-left: 15px;
	}
	.nav-tabs {
    border-bottom: 1px solid #dee2e6;
    padding-bottom: 0;
    margin-bottom: 25px;
    background: 0 0;
    border-radius: 1px;
    padding: 12px 13px 12px 13px;
    font-weight: 400;
    padding-left: 0;
    padding-right: 0;
    border-top: 1px solid #f0f0f0;
    border-bottom: 1px solid #f0f0f0;
}

.nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover, .navbar-pills.nav-tabs>li>a:focus, .navbar-pills.nav-tabs>li>a:hover{
    border: 0;
    border-radius: 0;
    border-bottom: 1px solid #02a9f4;
    background: 0 0;
    color: #008ece;
    margin-bottom: 1px;
    padding: 12px 13px 12px 13px;
    font-weight: 400;
    border-bottom: 1px solid #02a9f4;
}
.app_dt_empty .dataTables_length, .app_dt_empty .dt-buttons, .app_dt_empty table thead {
    opacity: .5;
}
.dataTables_length {
    float: left;
    margin-right: 5px;
}
div.dataTables_wrapper div.dataTables_length select {
    width: auto;
    color: #4e75ad;
}
div.dataTables_wrapper div.dataTables_filter {
    text-align: right;
}
table.dataTable thead>tr>th {
    color: #4e75ad;
    background: #f6f8fa;
    vertical-align: middle;
    border-bottom: 1px solid;
    border-color: #ebf5ff!important;
    font-size: 13px;
    padding-top: 9px;
    padding-bottom: 8px;
}
.btn.btn-default-dt-options {
    color: #333;
    background-color: #fff!important;
    border: 1px solid #bfcbd9!important;
}
.dt-buttons.btn-group .btn {
    color: #4e75ad;
    border-radius: 3px;
    font-size: 11.5px;
    padding-bottom: 9px;
    padding-top: 10px;
}
div.dataTables_wrapper div.dataTables_length label {
    font-weight: 400;
    text-align: left;
    white-space: nowrap;
}
.dataTables_empty {
    padding-top: 25px!important;
    padding-bottom: 180px!important;
    text-align: left!important;
    color: #777;
    font-size: 15px;
    background:url(assets/images/table-no-data.png);
    background-repeat: no-repeat;
    background-position: center;
    background-size: auto 161px;
}
a.view:hover { cursor: pointer; }
</style>
</head>